#!/usr/bin/env bash
# Crea el icono "Gestor Documental UGEL" en el Escritorio y en el menú de
# aplicaciones, para abrirlo con doble clic (sin terminal).

cd "$(dirname "$(readlink -f "$0")")" || exit 1
DIR="$(pwd)"
chmod +x Iniciar_GestorUGEL.sh

DESKTOP_DIR="$(xdg-user-dir DESKTOP 2>/dev/null)"
[ -d "$DESKTOP_DIR" ] || DESKTOP_DIR="$HOME/Escritorio"
[ -d "$DESKTOP_DIR" ] || DESKTOP_DIR="$HOME/Desktop"
[ -d "$DESKTOP_DIR" ] || DESKTOP_DIR="$HOME"
MENU_DIR="$HOME/.local/share/applications"
mkdir -p "$MENU_DIR"

CONTENIDO="[Desktop Entry]
Type=Application
Name=Gestor Documental UGEL
Comment=Abrir Gestor Documental UGEL
Path=$DIR
Exec=\"$DIR/Iniciar_GestorUGEL.sh\"
Icon=x-office-document
Terminal=false
Categories=Office;"

for destino in "$DESKTOP_DIR/Gestor Documental UGEL.desktop" "$MENU_DIR/gestor-documental-ugel.desktop"; do
    printf '%s\n' "$CONTENIDO" > "$destino"
    chmod +x "$destino"
    command -v gio >/dev/null 2>&1 && gio set "$destino" metadata::trusted true 2>/dev/null
done

MSG="Listo. Se creó el icono \"Gestor Documental UGEL\" en tu Escritorio y en el menú de aplicaciones (categoría Oficina). Si al abrirlo por primera vez el sistema pregunta si confías en el lanzador, acepta."
if [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && command -v zenity >/dev/null 2>&1; then
    zenity --info --no-markup --title="Gestor Documental UGEL" --width=440 --text="$MSG" 2>/dev/null
else
    echo "$MSG"
fi
