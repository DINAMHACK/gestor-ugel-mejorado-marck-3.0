"""
reports_view.py
----------------
Pantalla de reportes: lista los reportes generados, permite crear una
copia de seguridad de tus Excel de control (no hay base de datos que
respaldar: todo vive en tus .xlsx) y muestra el registro de actividad
reciente.
"""

import os
import subprocess
import sys
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import backup_service, report_tdr_service, excel_service
from config.config_manager import obtener_ruta
from utils.helpers import tamano_legible
from utils.logger import registrar, leer_actividad


class ReportsView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        titulo = ctk.CTkLabel(self, text="📋 Reportes", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        pestañas = ctk.CTkTabview(self)
        pestañas.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        pestañas.add("Reportes generados")
        pestañas.add("Copias de seguridad")
        pestañas.add("Actividad")

        self._construir_reportes(pestañas.tab("Reportes generados"))
        self._construir_backups(pestañas.tab("Copias de seguridad"))
        self._construir_actividad(pestañas.tab("Actividad"))

    def _abrir_carpeta(self, ruta):
        os.makedirs(ruta, exist_ok=True)
        if sys.platform == "win32":
            os.startfile(ruta)  # noqa: disponible solo en Windows, plataforma objetivo de la app
        elif sys.platform == "darwin":
            subprocess.Popen(["open", ruta])
        else:
            subprocess.Popen(["xdg-open", ruta])

    # ---------- Reportes generados ----------
    def _construir_reportes(self, tab):
        fila = ctk.CTkFrame(tab, fg_color="transparent")
        fila.pack(fill="x", pady=10)
        ctk.CTkButton(fila, text="Actualizar lista", command=self._actualizar_reportes).pack(side="left", padx=(0, 10))
        ctk.CTkButton(fila, text="Abrir carpeta de reportes",
                      command=lambda: self._abrir_carpeta(obtener_ruta(self.config_app, "carpeta_reportes", "reports"))
                      ).pack(side="left", padx=(0, 10))
        ctk.CTkButton(fila, text="📋 Generar TDR desde un Excel...", command=self._generar_tdr_desde_excel).pack(side="left")

        self.caja_reportes = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_reportes.pack(fill="both", expand=True, padx=10, pady=10)
        self._actualizar_reportes()

    def _generar_tdr_desde_excel(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel de expedientes / plazos", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        try:
            hojas = excel_service.listar_hojas(ruta)
            hoja = hojas[0] if hojas else "Hoja1"
            filas_brutas = excel_service.cargar_filas(ruta, hoja)
            columnas = excel_service.detectar_columnas(ruta, hoja)
        except Exception as err:
            messagebox.showerror("Error", f"No se pudo abrir el Excel:\n{err}")
            return

        filas_dict = []
        for f in filas_brutas:
            def obtener(campo):
                idx = columnas.get(campo)
                if idx is None or idx >= len(f):
                    return None
                return f[idx]
            filas_dict.append({
                "expediente": obtener("expediente") or f[0] if len(f) > 0 else "—",
                "dni": obtener("dni"),
                "nombre": obtener("nombre"),
                "fecha_ingreso": obtener("fecha"),
                "estado": obtener("estado"),
                "observacion": "Atendido",
            })

        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        try:
            ruta_tdr = report_tdr_service.generar_reporte_mensual_tdr(filas_dict, carpeta)
        except Exception as err:
            messagebox.showerror("Error", f"No se pudo generar el reporte TDR:\n{err}")
            return

        registrar(f"Generó Reporte TDR desde {os.path.basename(ruta)} -> {ruta_tdr}")
        messagebox.showinfo("Reporte TDR Generado", f"Reporte de Entregables Atendidos guardado en:\n{ruta_tdr}")
        self._actualizar_reportes()


    def _actualizar_reportes(self):
        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        self.caja_reportes.delete("1.0", "end")
        if not os.path.isdir(carpeta):
            self.caja_reportes.insert("end", "(Todavía no se ha generado ningún reporte)")
            return
        archivos = sorted(os.listdir(carpeta), reverse=True)
        archivos = [a for a in archivos if not a.startswith(".")]
        if not archivos:
            self.caja_reportes.insert("end", "(Todavía no se ha generado ningún reporte)")
            return
        for nombre in archivos:
            ruta = os.path.join(carpeta, nombre)
            if os.path.isfile(ruta):
                self.caja_reportes.insert("end", f"{nombre}  ({tamano_legible(os.path.getsize(ruta))})\n")

    # ---------- Backups ----------
    def _construir_backups(self, tab):
        ctk.CTkLabel(
            tab,
            text="Copia todos tus Excel de control (.xlsx) a una carpeta con fecha, dentro de backups/.",
            justify="left",
        ).pack(padx=10, pady=(10, 5), anchor="w")

        fila_carpeta = ctk.CTkFrame(tab, fg_color="transparent")
        fila_carpeta.pack(fill="x", padx=10)
        ctk.CTkButton(fila_carpeta, text="Carpeta de Excel a respaldar...",
                      command=self._elegir_carpeta_excel).pack(side="left", padx=(0, 10))
        self.etiqueta_carpeta_excel = ctk.CTkLabel(
            fila_carpeta,
            text=self.config_app.get("carpeta_busqueda_excel") or self.config_app.get("carpeta_trabajo") or
                 "Ninguna carpeta seleccionada",
        )
        self.etiqueta_carpeta_excel.pack(side="left")

        fila = ctk.CTkFrame(tab, fg_color="transparent")
        fila.pack(fill="x", pady=10, padx=10)
        ctk.CTkButton(fila, text="Crear copia de seguridad ahora", command=self._crear_backup).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila, text="Abrir carpeta de backups",
                      command=lambda: self._abrir_carpeta(obtener_ruta(self.config_app, "carpeta_backups", "backups"))
                      ).pack(side="left")

        self.caja_backups = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_backups.pack(fill="both", expand=True, padx=10, pady=10)
        self._actualizar_backups()

    def _elegir_carpeta_excel(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta con tus Excel de control")
        if carpeta:
            self.etiqueta_carpeta_excel.configure(text=carpeta)

    def _crear_backup(self):
        carpeta_excel = self.etiqueta_carpeta_excel.cget("text")
        if not carpeta_excel or carpeta_excel == "Ninguna carpeta seleccionada":
            messagebox.showwarning("Aviso", "Primero selecciona la carpeta con tus Excel de control.")
            return

        carpeta_backups = obtener_ruta(self.config_app, "carpeta_backups", "backups")
        resultado = backup_service.crear_backup_excel(carpeta_excel, carpeta_backups)

        if "error" in resultado:
            messagebox.showerror("Error", resultado["error"])
            return

        if not resultado["archivos"]:
            messagebox.showwarning("Aviso", "No se encontró ningún archivo .xlsx en esa carpeta.")
            return

        registrar(f"Creó copia de seguridad de {len(resultado['archivos'])} Excel en: {resultado['destino']}")
        messagebox.showinfo(
            "Copia de seguridad creada",
            f"Se copiaron {len(resultado['archivos'])} archivo(s) a:\n{resultado['destino']}",
        )
        self._actualizar_backups()

    def _actualizar_backups(self):
        carpeta = obtener_ruta(self.config_app, "carpeta_backups", "backups")
        self.caja_backups.delete("1.0", "end")
        if not os.path.isdir(carpeta) or not os.listdir(carpeta):
            self.caja_backups.insert("end", "(Todavía no se ha creado ninguna copia de seguridad)")
            return
        for nombre in sorted(os.listdir(carpeta), reverse=True):
            ruta = os.path.join(carpeta, nombre)
            if os.path.isdir(ruta):
                cantidad = len(os.listdir(ruta))
                self.caja_backups.insert("end", f"{nombre}/  ({cantidad} archivo(s))\n")
            elif os.path.isfile(ruta) and not nombre.startswith("."):
                self.caja_backups.insert("end", f"{nombre}  ({tamano_legible(os.path.getsize(ruta))})\n")

    # ---------- Actividad ----------
    def _construir_actividad(self, tab):
        ctk.CTkButton(tab, text="Actualizar", command=self._actualizar_actividad).pack(pady=10)
        self.caja_actividad = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_actividad.pack(fill="both", expand=True, padx=10, pady=10)
        self._actualizar_actividad()

    def _actualizar_actividad(self):
        self.caja_actividad.delete("1.0", "end")
        self.caja_actividad.insert("end", leer_actividad())
