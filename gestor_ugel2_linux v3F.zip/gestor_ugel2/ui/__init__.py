"""
Ajuste global de la interfaz: una lista desplegable vacía mostraba el texto
interno "CTkComboBox". Ahora se muestra vacía hasta que se elige un archivo.
"""
import customtkinter as _ctk

_init_original = _ctk.CTkComboBox.__init__


def _init_sin_texto_interno(self, *args, **kwargs):
    _init_original(self, *args, **kwargs)
    if not kwargs.get("values"):
        self.set("")


_ctk.CTkComboBox.__init__ = _init_sin_texto_interno
