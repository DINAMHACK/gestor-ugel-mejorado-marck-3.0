"""
excel_view.py
-------------
Pantalla del módulo Excel: seleccionar archivo, elegir hoja y validar.
"""

import os
import threading
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import excel_service, report_service, sisgedo_export_service
from config.config_manager import obtener_ruta
from utils.logger import registrar


class ExcelView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config
        self.ruta_excel = None
        self.ultimo_resultado = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        titulo = ctk.CTkLabel(self, text="📊 Excel", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        fila_archivo = ctk.CTkFrame(self, fg_color="transparent")
        fila_archivo.grid(row=1, column=0, sticky="ew", padx=20)
        fila_archivo.columnconfigure(1, weight=1)

        ctk.CTkButton(fila_archivo, text="Seleccionar Excel", command=self.seleccionar_archivo).grid(
            row=0, column=0, padx=(0, 10)
        )
        self.etiqueta_archivo = ctk.CTkLabel(fila_archivo, text="Ningún archivo seleccionado", anchor="w")
        self.etiqueta_archivo.grid(row=0, column=1, sticky="ew")

        fila_hoja = ctk.CTkFrame(self, fg_color="transparent")
        fila_hoja.grid(row=2, column=0, sticky="ew", padx=20, pady=10)

        ctk.CTkLabel(fila_hoja, text="Hoja:").pack(side="left", padx=(0, 10))
        self.combo_hojas = ctk.CTkComboBox(fila_hoja, values=[], width=220)
        self.combo_hojas.pack(side="left")

        self.boton_validar = ctk.CTkButton(
            fila_hoja, text="✓ Validar", command=self.validar, state="disabled"
        )
        self.boton_validar.pack(side="left", padx=10)

        self.caja_resultado = ctk.CTkTextbox(self, font=ctk.CTkFont(family="Consolas", size=13))
        self.caja_resultado.grid(row=3, column=0, sticky="nsew", padx=20, pady=(0, 10))
        self.caja_resultado.configure(state="disabled")

        fila_reportes = ctk.CTkFrame(self, fg_color="transparent")
        fila_reportes.grid(row=4, column=0, sticky="ew", padx=20, pady=(0, 10))
        ctk.CTkButton(fila_reportes, text="Generar reporte Excel", command=lambda: self.generar_reporte("xlsx")).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila_reportes, text="Generar reporte CSV", command=lambda: self.generar_reporte("csv")).pack(
            side="left"
        )

        marco_sisgedo = ctk.CTkFrame(self)
        marco_sisgedo.grid(row=5, column=0, sticky="ew", padx=20, pady=(0, 20))
        ctk.CTkLabel(
            marco_sisgedo, text="Copiar fila limpia (para pegar en SISGEDO u otro sistema web)",
            font=ctk.CTkFont(weight="bold"),
        ).grid(row=0, column=0, columnspan=3, sticky="w", padx=10, pady=(10, 5))
        ctk.CTkLabel(marco_sisgedo, text="Número de fila:").grid(row=1, column=0, padx=(10, 5), pady=(0, 10))
        self.entrada_fila_sisgedo = ctk.CTkEntry(marco_sisgedo, width=80, placeholder_text="ej. 2")
        self.entrada_fila_sisgedo.grid(row=1, column=1, pady=(0, 10))
        ctk.CTkButton(marco_sisgedo, text="Copiar al portapapeles", command=self._copiar_fila_sisgedo).grid(
            row=1, column=2, padx=10, pady=(0, 10)
        )
        self.etiqueta_vista_previa_sisgedo = ctk.CTkLabel(
            marco_sisgedo, text="", text_color="gray", wraplength=700, justify="left"
        )
        self.etiqueta_vista_previa_sisgedo.grid(row=2, column=0, columnspan=3, sticky="w", padx=10, pady=(0, 10))

    def _copiar_fila_sisgedo(self):
        if not self.ruta_excel:
            messagebox.showwarning("Aviso", "Primero selecciona un Excel.")
            return
        texto_fila = self.entrada_fila_sisgedo.get().strip()
        try:
            numero_fila = int(texto_fila)
        except ValueError:
            messagebox.showwarning("Aviso", "Ingresa un número de fila válido (ejemplo: 2).")
            return

        try:
            fila_bruta = excel_service.leer_fila_bruta(self.ruta_excel, self.combo_hojas.get(), numero_fila)
        except ValueError as error:
            messagebox.showerror("Error", str(error))
            return
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo leer la fila:\n{error}")
            return

        if not fila_bruta:
            messagebox.showwarning("Aviso", "Esa fila no tiene columnas con encabezado reconocible.")
            return

        fila_limpia = sisgedo_export_service.limpiar_fila(fila_bruta)

        if not any(valor for valor in fila_limpia.values()):
            messagebox.showwarning("Aviso", f"La fila {numero_fila} está vacía. No se copió nada.")
            return

        texto_limpio = sisgedo_export_service.formatear_para_portapapeles(fila_bruta)

        self.clipboard_clear()
        self.clipboard_append(texto_limpio)

        vista_previa = "  |  ".join(f"{clave}: {valor}" for clave, valor in fila_limpia.items())
        self.etiqueta_vista_previa_sisgedo.configure(text=f"Copiado ✓  {vista_previa}")

        registrar(f"Copió fila {numero_fila} de {os.path.basename(self.ruta_excel)} para pegar en sistema externo")

    def seleccionar_archivo(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona un archivo Excel",
            filetypes=[("Archivos Excel", "*.xlsx *.xlsm")],
        )
        if not ruta:
            return
        self.ruta_excel = ruta
        self.etiqueta_archivo.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hojas.configure(values=hojas)
        if hojas:
            self.combo_hojas.set(hojas[0])
        self.boton_validar.configure(state="normal")

    def validar(self):
        if not self.ruta_excel:
            return
        hoja = self.combo_hojas.get()
        tipos_validos = self.config_app.get("tipos_documento_validos", [])
        estados_validos = self.config_app.get("estados_validos", [])

        self.boton_validar.configure(state="disabled", text="Validando...")

        def tarea():
            resultado = excel_service.validar_excel(self.ruta_excel, hoja, tipos_validos, estados_validos)
            self.after(0, lambda: self._mostrar_resultado(resultado))

        threading.Thread(target=tarea, daemon=True).start()

    def _mostrar_resultado(self, resultado):
        self.boton_validar.configure(state="normal", text="✓ Validar")
        self.ultimo_resultado = resultado

        self.caja_resultado.configure(state="normal")
        self.caja_resultado.delete("1.0", "end")

        if "error" in resultado:
            self.caja_resultado.insert("end", f"⚠ {resultado['error']}")
            self.caja_resultado.configure(state="disabled")
            return

        lineas = [
            "═" * 40,
            "       RESULTADO DE VALIDACIÓN",
            "═" * 40,
            "",
            f"Filas analizadas: {resultado['total']}",
            f"✓ Correctas:      {resultado['correctos']}",
            f"⚠ Observadas:     {resultado['observados']}",
            "",
        ]
        if resultado["problemas"]:
            lineas.append("Problemas encontrados:")
            for problema in resultado["problemas"]:
                lineas.append(f"  Fila {problema['fila']} (DNI {problema['dni']}): {', '.join(problema['errores'])}")
        else:
            lineas.append("Sin observaciones. Todo correcto.")

        if resultado.get("avisos"):
            lineas.append("")
            lineas.append("Avisos (no son errores, pero conviene revisarlos):")
            for aviso in resultado["avisos"]:
                lineas.append(f"  Fila {aviso['fila']} (DNI {aviso['dni']}): {aviso['aviso']}")

        self.caja_resultado.insert("end", "\n".join(lineas))
        self.caja_resultado.configure(state="disabled")

        registrar(f"Validó Excel: {os.path.basename(self.ruta_excel)} "
                  f"(correctos={resultado['correctos']}, observados={resultado['observados']})")

    def generar_reporte(self, formato):
        if not self.ultimo_resultado or "error" in self.ultimo_resultado:
            messagebox.showwarning("Aviso", "Primero valida un Excel para poder generar el reporte.")
            return

        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        try:
            if formato == "xlsx":
                ruta = report_service.generar_reporte_excel(self.ultimo_resultado, carpeta)
            else:
                ruta = report_service.generar_reporte_csv(self.ultimo_resultado, carpeta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el reporte:\n{error}")
            return

        registrar(f"Generó reporte {formato.upper()}: {ruta}")
        messagebox.showinfo("Reporte generado", f"Reporte guardado en:\n{ruta}")
