"""
excel_avanzado_view.py
------------------------
Herramientas Excel que SÍ escriben archivos (a diferencia del resto
del programa, que solo lee). Por eso viven en una pestaña aparte,
separada de "Excel" (que es de solo lectura), para que sea evidente
cuándo el programa va a generar un archivo nuevo.

Ambas funciones son seguras por diseño: NUNCA modifican el archivo
original que seleccionas. Siempre escriben el resultado en un archivo
nuevo. Por eso no hace falta un sistema de respaldo automático aparte:
si algo sale mal, tu archivo original sigue exactamente como estaba.
"""

import os
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import excel_service, dni_format_service, template_merge_service, nombre_separacion_service, patrimonio_service, catalogo_sbn_service
from utils.logger import registrar


class ExcelAvanzadoView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        titulo = ctk.CTkLabel(self, text="🛠 Herramientas Excel (generan un archivo nuevo)",
                               font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        pestañas = ctk.CTkTabview(self)
        pestañas.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))
        pestañas.add("Proteger DNI/RUC")
        pestañas.add("Separar Apellidos/Nombres")
        pestañas.add("Código Patrimonial")
        pestañas.add("Fusionar con plantilla")

        self._construir_proteger_dni(pestañas.tab("Proteger DNI/RUC"))
        self._construir_separar_nombres(pestañas.tab("Separar Apellidos/Nombres"))
        self._construir_codigo_patrimonial(pestañas.tab("Código Patrimonial"))
        self._construir_fusionar_plantilla(pestañas.tab("Fusionar con plantilla"))


    # ---------- Proteger DNI/RUC ----------
    def _construir_proteger_dni(self, tab):
        self.ruta_excel_dni = None

        ctk.CTkLabel(
            tab,
            text=(
                "Convierte una columna de DNI o RUC en texto protegido, para que Excel nunca más "
                "le borre el cero inicial (por ejemplo, \"01234567\" convertido a 1234567).\n"
                "El resultado se guarda en un archivo NUEVO — tu Excel original no se toca."
            ),
            justify="left", wraplength=750,
        ).pack(padx=10, pady=(15, 10), anchor="w")

        fila_archivo = ctk.CTkFrame(tab, fg_color="transparent")
        fila_archivo.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_archivo, text="Seleccionar Excel", command=self._seleccionar_excel_dni).pack(
            side="left", padx=(0, 10)
        )
        self.etiqueta_excel_dni = ctk.CTkLabel(fila_archivo, text="Ningún archivo seleccionado")
        self.etiqueta_excel_dni.pack(side="left", padx=(0, 10))
        self.combo_hoja_dni = ctk.CTkComboBox(fila_archivo, values=[], width=180)
        self.combo_hoja_dni.pack(side="left")

        fila_columna = ctk.CTkFrame(tab, fg_color="transparent")
        fila_columna.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(fila_columna, text="Nombre de la columna:").pack(side="left", padx=(0, 10))
        self.entrada_columna_dni = ctk.CTkEntry(fila_columna, width=150, placeholder_text="DNI")
        self.entrada_columna_dni.insert(0, "DNI")
        self.entrada_columna_dni.pack(side="left")
        ctk.CTkButton(fila_columna, text="Proteger columna", command=self._proteger_dni).pack(
            side="left", padx=15
        )

        self.caja_resultado_dni = ctk.CTkTextbox(tab, height=150)
        self.caja_resultado_dni.pack(fill="both", expand=True, padx=10, pady=10)

    def _seleccionar_excel_dni(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_excel_dni = ruta
        self.etiqueta_excel_dni.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hoja_dni.configure(values=hojas)
        if hojas:
            self.combo_hoja_dni.set(hojas[0])

    def _proteger_dni(self):
        if not self.ruta_excel_dni:
            messagebox.showwarning("Aviso", "Primero selecciona un Excel.")
            return
        nombre_columna = self.entrada_columna_dni.get().strip()
        if not nombre_columna:
            messagebox.showwarning("Aviso", "Escribe el nombre de la columna (ejemplo: DNI).")
            return

        resultado = dni_format_service.proteger_columna_como_texto(
            self.ruta_excel_dni, self.combo_hoja_dni.get(), nombre_columna
        )

        self.caja_resultado_dni.delete("1.0", "end")
        if "error" in resultado:
            self.caja_resultado_dni.insert("end", f"⚠ {resultado['error']}")
            return

        self.caja_resultado_dni.insert(
            "end",
            f"Columna \"{resultado['columna']}\" protegida como texto de {resultado['longitud_objetivo']} dígitos.\n"
            f"Celdas con dato: {resultado['celdas_con_dato']}\n"
            f"Celdas corregidas: {resultado['celdas_corregidas']}\n\n"
            f"Archivo nuevo guardado en:\n{resultado['ruta_salida']}\n\n"
            f"Tu archivo original NO fue modificado.",
        )
        registrar(f"Protegió columna {nombre_columna} en {os.path.basename(self.ruta_excel_dni)}: "
                  f"{resultado['celdas_corregidas']} celda(s) corregida(s)")

    # ---------- Separar Apellidos y Nombres ----------
    def _construir_separar_nombres(self, tab):
        self.ruta_excel_nombres = None

        ctk.CTkLabel(
            tab,
            text=(
                "Separa una columna de \"Apellidos y Nombres\" (formato \"APELLIDO PATERNO APELLIDO "
                "MATERNO, NOMBRES\") en tres columnas nuevas al final del archivo. Limpia espacios "
                "invisibles antes de separar, para que un espacio que no se ve no arruine el resultado.\n"
                "Si una fila no tiene coma, se deja tal cual en \"Nombres\" — el programa no adivina "
                "dónde cortar un formato que no reconoce.\n"
                "El resultado se guarda en un archivo NUEVO — tu Excel original no se toca."
            ),
            justify="left", wraplength=750,
        ).pack(padx=10, pady=(15, 10), anchor="w")

        fila_archivo = ctk.CTkFrame(tab, fg_color="transparent")
        fila_archivo.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_archivo, text="Seleccionar Excel", command=self._seleccionar_excel_nombres).pack(
            side="left", padx=(0, 10)
        )
        self.etiqueta_excel_nombres = ctk.CTkLabel(fila_archivo, text="Ningún archivo seleccionado")
        self.etiqueta_excel_nombres.pack(side="left", padx=(0, 10))
        self.combo_hoja_nombres = ctk.CTkComboBox(fila_archivo, values=[], width=180)
        self.combo_hoja_nombres.pack(side="left")

        fila_columna = ctk.CTkFrame(tab, fg_color="transparent")
        fila_columna.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(fila_columna, text="Nombre de la columna:").pack(side="left", padx=(0, 10))
        self.entrada_columna_nombres = ctk.CTkEntry(fila_columna, width=200, placeholder_text="Nombres Completos")
        self.entrada_columna_nombres.insert(0, "Nombres Completos")
        self.entrada_columna_nombres.pack(side="left")
        ctk.CTkButton(fila_columna, text="Separar", command=self._separar_nombres).pack(side="left", padx=15)

        self.caja_resultado_nombres = ctk.CTkTextbox(tab, height=150)
        self.caja_resultado_nombres.pack(fill="both", expand=True, padx=10, pady=10)

    def _seleccionar_excel_nombres(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_excel_nombres = ruta
        self.etiqueta_excel_nombres.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hoja_nombres.configure(values=hojas)
        if hojas:
            self.combo_hoja_nombres.set(hojas[0])

    def _separar_nombres(self):
        if not self.ruta_excel_nombres:
            messagebox.showwarning("Aviso", "Primero selecciona un Excel.")
            return
        nombre_columna = self.entrada_columna_nombres.get().strip()
        if not nombre_columna:
            messagebox.showwarning("Aviso", "Escribe el nombre de la columna (ejemplo: Nombres Completos).")
            return

        resultado = nombre_separacion_service.separar_apellidos_y_nombres(
            self.ruta_excel_nombres, self.combo_hoja_nombres.get(), nombre_columna
        )

        self.caja_resultado_nombres.delete("1.0", "end")
        if "error" in resultado:
            self.caja_resultado_nombres.insert("end", f"⚠ {resultado['error']}")
            return

        self.caja_resultado_nombres.insert(
            "end",
            f"Filas separadas correctamente (con coma): {resultado['filas_separadas']}\n"
            f"Filas sin coma (dejadas en \"Nombres\" como respaldo): {resultado['filas_sin_coma']}\n"
            f"Filas vacías: {resultado['filas_vacias']}\n\n"
            f"Archivo nuevo guardado en:\n{resultado['ruta_salida']}\n\n"
            f"Tu archivo original NO fue modificado.",
        )
        registrar(f"Separó apellidos/nombres en {os.path.basename(self.ruta_excel_nombres)}: "
                  f"{resultado['filas_separadas']} fila(s) separada(s)")

    # ---------- Código Patrimonial SBN/SIGA ----------
    def _construir_codigo_patrimonial(self, tab):
        self.ruta_excel_patrimonio = None

        ctk.CTkLabel(
            tab,
            text=(
                "Limpia y valida una columna de Código Patrimonial (SBN / SIGA / SINABIP) exigida a 12 dígitos.\n"
                "Remueve guiones, letras, espacios, 'N°' o '#' dejando únicamente los 12 números exactos.\n"
                "Además comprueba que los 8 primeros dígitos existan en el Catálogo Nacional de Bienes Muebles (SBN): "
                "los que no existen se marcan con ALERTA, porque SIGA los rechazaría.\n"
                "El resultado se guarda en un archivo NUEVO (*_patrimonial.xlsx) — tu Excel original no se toca."
            ),
            justify="left", wraplength=750,
        ).pack(padx=10, pady=(15, 10), anchor="w")

        fila_archivo = ctk.CTkFrame(tab, fg_color="transparent")
        fila_archivo.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_archivo, text="Seleccionar Excel", command=self._seleccionar_excel_patrimonio).pack(
            side="left", padx=(0, 10)
        )
        self.etiqueta_excel_patrimonio = ctk.CTkLabel(fila_archivo, text="Ningún archivo seleccionado")
        self.etiqueta_excel_patrimonio.pack(side="left", padx=(0, 10))
        self.combo_hoja_patrimonio = ctk.CTkComboBox(fila_archivo, values=[], width=180)
        self.combo_hoja_patrimonio.pack(side="left")

        fila_columna = ctk.CTkFrame(tab, fg_color="transparent")
        fila_columna.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(fila_columna, text="Nombre de la columna:").pack(side="left", padx=(0, 10))
        self.entrada_columna_patrimonio = ctk.CTkEntry(fila_columna, width=200, placeholder_text="CODIGO PATRIMONIAL")
        self.entrada_columna_patrimonio.insert(0, "CODIGO PATRIMONIAL")
        self.entrada_columna_patrimonio.pack(side="left")
        ctk.CTkButton(fila_columna, text="Limpiar y Proteger Patrimonial", command=self._proteger_patrimonio).pack(
            side="left", padx=15
        )

        fila_catalogo = ctk.CTkFrame(tab, fg_color="transparent")
        fila_catalogo.pack(fill="x", padx=10, pady=(0, 5))
        self.etiqueta_catalogo = ctk.CTkLabel(fila_catalogo, text="", anchor="w", justify="left", wraplength=520)
        self.etiqueta_catalogo.pack(side="left", padx=(0, 10))
        ctk.CTkButton(fila_catalogo, text="Importar catálogo SBN...", width=190,
                      command=self._importar_catalogo).pack(side="left")
        self._refrescar_estado_catalogo()

        self.caja_resultado_patrimonio = ctk.CTkTextbox(tab, height=150)
        self.caja_resultado_patrimonio.pack(fill="both", expand=True, padx=10, pady=10)

    def _refrescar_estado_catalogo(self):
        estado = catalogo_sbn_service.estado_catalogo()
        color = "#1E7A34" if (estado["cargado"] and not estado["parcial"]) else "#B8860B"
        self.etiqueta_catalogo.configure(text=estado["mensaje"], text_color=color)

    def _importar_catalogo(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona el catálogo SBN (Excel, CSV o PDF con texto)",
            filetypes=[("Catálogo", "*.xlsx *.xlsm *.csv *.txt *.pdf"), ("Todos", "*.*")],
        )
        if not ruta:
            return
        resultado = catalogo_sbn_service.importar_catalogo(ruta)
        if "error" in resultado:
            messagebox.showerror("No se pudo importar", resultado["error"])
            return
        self._refrescar_estado_catalogo()
        registrar(f"Importó catálogo SBN: {resultado['nuevos']} código(s) nuevo(s), total {resultado['total']}")
        messagebox.showinfo(
            "Catálogo importado",
            f"Códigos leídos: {resultado['leidos']}\nNuevos agregados: {resultado['nuevos']}\n"
            f"Total en el catálogo: {resultado['total']}\n\n"
            "Puedes importar más archivos (por ejemplo, cada fascículo): se van sumando.",
        )

    def _seleccionar_excel_patrimonio(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_excel_patrimonio = ruta
        self.etiqueta_excel_patrimonio.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hoja_patrimonio.configure(values=hojas)
        if hojas:
            self.combo_hoja_patrimonio.set(hojas[0])

    def _proteger_patrimonio(self):
        if not self.ruta_excel_patrimonio:
            messagebox.showwarning("Aviso", "Primero selecciona un Excel.")
            return
        nombre_columna = self.entrada_columna_patrimonio.get().strip()
        if not nombre_columna:
            messagebox.showwarning("Aviso", "Escribe el nombre de la columna (ejemplo: CODIGO PATRIMONIAL).")
            return

        resultado = patrimonio_service.proteger_codigo_patrimonial_excel(
            self.ruta_excel_patrimonio, self.combo_hoja_patrimonio.get(), nombre_columna
        )

        self.caja_resultado_patrimonio.delete("1.0", "end")
        if "error" in resultado:
            self.caja_resultado_patrimonio.insert("end", f"⚠ {resultado['error']}")
            return

        self.caja_resultado_patrimonio.insert(
            "end",
            f"Columna \"{resultado['columna']}\" procesada con formato SBN/SIGA de 12 dígitos.\n"
            f"Celdas con dato: {resultado['celdas_con_dato']}\n"
            f"Celdas corregidas/limpiadas: {resultado['celdas_corregidas']}\n"
            f"Celdas observadas (longitud != 12): {resultado['celdas_observadas']}\n\n"
            + self._texto_resultado_catalogo(resultado)
            + f"Archivo nuevo guardado en:\n{resultado['ruta_salida']}\n\n"
            f"Tu archivo original NO fue modificado.",
        )
        registrar(f"Procesó Código Patrimonial en {os.path.basename(self.ruta_excel_patrimonio)}: "
                  f"{resultado['celdas_corregidas']} corregida(s), {resultado['celdas_observadas']} observada(s)")


    @staticmethod
    def _texto_resultado_catalogo(resultado) -> str:
        cat = resultado["catalogo"]
        if not cat["cargado"]:
            return ("Catálogo SBN: NO cargado, así que solo se validó el largo (12 dígitos).\n"
                    "Usa \"Importar catálogo SBN...\" para detectar códigos que no existen.\n\n")
        texto = (f"Catálogo SBN: {resultado['catalogo_ok']} código(s) existen · "
                 f"{resultado['catalogo_no_encontrados']} ALERTA(S): no existen en el catálogo.\n")
        if resultado["catalogo_no_encontrados"]:
            texto += "Revisa la columna VALIDACION CATALOGO y la hoja \"Alertas catalogo\".\n"
        if cat["parcial"]:
            texto += "(Catálogo parcial: una alerta podría ser un código que está en la parte no importada.)\n"
        return texto + "\n"

    # ---------- Fusionar con plantilla ----------
    def _construir_fusionar_plantilla(self, tab):
        self.ruta_plantilla = None
        self.ruta_datos = None

        ctk.CTkLabel(
            tab,
            text=(
                "Toma los datos de un Excel (por ejemplo, un reporte que ya generaste) y los coloca "
                "dentro de una plantilla oficial tuya (con logo, colores y formato ya listos), a "
                "partir de la fila que indiques. Nunca inserta filas ni toca fórmulas o celdas "
                "combinadas: si los datos no caben antes de esos elementos, te avisa y solo llena "
                "lo que sí es seguro llenar."
            ),
            justify="left", wraplength=750,
        ).pack(padx=10, pady=(15, 10), anchor="w")

        fila_plantilla = ctk.CTkFrame(tab, fg_color="transparent")
        fila_plantilla.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_plantilla, text="Seleccionar plantilla oficial (.xlsx)",
                      command=self._seleccionar_plantilla).pack(side="left", padx=(0, 10))
        self.etiqueta_plantilla = ctk.CTkLabel(fila_plantilla, text="Ninguna plantilla seleccionada")
        self.etiqueta_plantilla.pack(side="left")

        fila_datos = ctk.CTkFrame(tab, fg_color="transparent")
        fila_datos.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_datos, text="Seleccionar Excel con los datos",
                      command=self._seleccionar_datos).pack(side="left", padx=(0, 10))
        self.etiqueta_datos = ctk.CTkLabel(fila_datos, text="Ningún archivo de datos seleccionado")
        self.etiqueta_datos.pack(side="left")
        self.combo_hoja_datos = ctk.CTkComboBox(fila_datos, values=[], width=160)
        self.combo_hoja_datos.pack(side="left", padx=10)

        fila_config = ctk.CTkFrame(tab, fg_color="transparent")
        fila_config.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(fila_config, text="Fila donde empiezan los datos en la plantilla:").pack(side="left", padx=(0, 10))
        self.entrada_fila_inicio = ctk.CTkEntry(fila_config, width=60, placeholder_text="ej. 4")
        self.entrada_fila_inicio.pack(side="left")
        ctk.CTkButton(fila_config, text="Fusionar", command=self._fusionar).pack(side="left", padx=15)

        self.caja_resultado_plantilla = ctk.CTkTextbox(tab, height=120)
        self.caja_resultado_plantilla.pack(fill="both", expand=True, padx=10, pady=10)

    def _seleccionar_plantilla(self):
        ruta = filedialog.askopenfilename(title="Selecciona la plantilla oficial", filetypes=[("Excel", "*.xlsx")])
        if ruta:
            self.ruta_plantilla = ruta
            self.etiqueta_plantilla.configure(text=os.path.basename(ruta))

    def _seleccionar_datos(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel con los datos", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_datos = ruta
        self.etiqueta_datos.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hoja_datos.configure(values=hojas)
        if hojas:
            self.combo_hoja_datos.set(hojas[0])

    def _fusionar(self):
        if not self.ruta_plantilla:
            messagebox.showwarning("Aviso", "Primero selecciona la plantilla oficial.")
            return
        if not self.ruta_datos:
            messagebox.showwarning("Aviso", "Primero selecciona el Excel con los datos.")
            return
        try:
            fila_inicio = int(self.entrada_fila_inicio.get().strip())
        except ValueError:
            messagebox.showwarning("Aviso", "Ingresa un número de fila válido (ejemplo: 4).")
            return

        try:
            filas_datos = excel_service.cargar_filas(self.ruta_datos, self.combo_hoja_datos.get())
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo leer el Excel de datos:\n{error}")
            return

        if not filas_datos:
            messagebox.showwarning("Aviso", "El Excel de datos no tiene filas para copiar.")
            return

        resultado = template_merge_service.fusionar_con_plantilla(
            self.ruta_plantilla, filas_datos, fila_inicio, ruta_salida=None
        )

        self.caja_resultado_plantilla.delete("1.0", "end")
        if "error" in resultado:
            self.caja_resultado_plantilla.insert("end", f"⚠ {resultado['error']}")
            return

        texto = (
            f"Filas escritas: {resultado['filas_escritas']} de {resultado['filas_pedidas']} pedidas.\n"
            f"Archivo generado en:\n{resultado['ruta_salida']}\n"
        )
        if resultado["aviso"]:
            texto += f"\n⚠ {resultado['aviso']}"
        self.caja_resultado_plantilla.insert("end", texto)

        registrar(f"Fusionó {resultado['filas_escritas']} fila(s) con plantilla "
                  f"{os.path.basename(self.ruta_plantilla)} -> {resultado['ruta_salida']}")
