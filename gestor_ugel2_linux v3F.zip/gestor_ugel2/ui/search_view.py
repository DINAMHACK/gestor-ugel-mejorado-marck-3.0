"""
search_view.py
--------------
Busqueda "Full Excel": busca un DNI o texto directamente dentro de los
archivos Excel de tu carpeta de control. No usa ninguna base de datos:
tu informacion sigue viviendo en los mismos .xlsx que usa el resto de
la oficina, pero la consultas en segundos.

Incluye un filtro opcional por rango de anios (llave compuesta:
texto/DNI + anio), y una alerta "en caliente": mientras escribes un
DNI (desde el 4to caracter), el programa busca solo en tu Excel de
control y te avisa si ese DNI ya tiene registros, ANTES de que
termines de escribirlo. Esto no se conecta a Excel ni a SISGEDO
directamente (eso requeriria enganchar el teclado de otras
aplicaciones, algo fragil e invasivo) - la alerta aparece aqui, en
esta misma pantalla, para que la revises antes de ir a digitar.
"""

import threading
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import excel_search_service
from utils.logger import registrar

LARGO_MINIMO_BUSQUEDA_AUTOMATICA = 4
RETRASO_BUSQUEDA_AUTOMATICA_MS = 500


class SearchView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config
        self.carpeta_busqueda = config.get("carpeta_busqueda_excel") or config.get("carpeta_trabajo") or ""
        self._id_busqueda_programada = None
        self._token_busqueda = 0

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        titulo = ctk.CTkLabel(self, text="🔎 Buscar (en tus Excel)", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 5))

        fila_carpeta = ctk.CTkFrame(self, fg_color="transparent")
        fila_carpeta.grid(row=1, column=0, sticky="ew", padx=20)
        fila_carpeta.columnconfigure(1, weight=1)
        ctk.CTkButton(fila_carpeta, text="Carpeta de Excel...", command=self._elegir_carpeta).grid(
            row=0, column=0, padx=(0, 10)
        )
        self.etiqueta_carpeta = ctk.CTkLabel(
            fila_carpeta, text=self.carpeta_busqueda or "Ninguna carpeta seleccionada", anchor="w"
        )
        self.etiqueta_carpeta.grid(row=0, column=1, sticky="ew")

        fila_busqueda = ctk.CTkFrame(self, fg_color="transparent")
        fila_busqueda.grid(row=2, column=0, sticky="ew", padx=20, pady=10)
        self.entrada_busqueda = ctk.CTkEntry(fila_busqueda, width=220, placeholder_text="DNI o nombre")
        self.entrada_busqueda.pack(side="left", padx=(0, 10))
        self.entrada_busqueda.bind("<Return>", lambda evento: self._buscar())
        self.entrada_busqueda.bind("<KeyRelease>", self._al_escribir)

        ctk.CTkLabel(fila_busqueda, text="Año desde:").pack(side="left", padx=(10, 5))
        self.entrada_anio_desde = ctk.CTkEntry(fila_busqueda, width=70, placeholder_text="ej. 2019")
        self.entrada_anio_desde.pack(side="left")
        self.entrada_anio_desde.bind("<Return>", lambda evento: self._buscar())

        ctk.CTkLabel(fila_busqueda, text="hasta:").pack(side="left", padx=(10, 5))
        self.entrada_anio_hasta = ctk.CTkEntry(fila_busqueda, width=70, placeholder_text="ej. 2023")
        self.entrada_anio_hasta.pack(side="left")
        self.entrada_anio_hasta.bind("<Return>", lambda evento: self._buscar())

        ctk.CTkButton(fila_busqueda, text="Buscar", command=self._buscar).pack(side="left", padx=(15, 0))

        self.etiqueta_estado_vivo = ctk.CTkLabel(self, text="", text_color="gray")
        self.etiqueta_estado_vivo.grid(row=2, column=0, sticky="sw", padx=20, pady=(45, 0))

        nota = ctk.CTkLabel(
            self,
            text="El rango de años es opcional. Desde el 4to carácter, el programa también busca "
                 "solo mientras escribes, para avisarte si ese DNI ya tiene registros.",
            text_color="gray",
        )
        nota.grid(row=2, column=0, sticky="sw", padx=20, pady=(65, 0))

        self.caja_resultado = ctk.CTkTextbox(self, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_resultado.grid(row=3, column=0, sticky="nsew", padx=20, pady=(15, 20))
        self.caja_resultado.insert(
            "end",
            "Selecciona la carpeta donde guardas tus Excel de control y escribe un DNI o nombre.\n"
            "El programa revisa todos los .xlsx de esa carpeta (todas las hojas) y no modifica nada."
        )
        self.caja_resultado.configure(state="disabled")

    def _elegir_carpeta(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta con tus Excel de control")
        if not carpeta:
            return
        self.carpeta_busqueda = carpeta
        self.etiqueta_carpeta.configure(text=carpeta)

    def _leer_anio(self, entrada):
        """Convierte el contenido de un campo de año a entero, o None si está vacío/inválido."""
        texto = entrada.get().strip()
        if not texto:
            return None, True
        try:
            return int(texto), True
        except ValueError:
            return None, False

    # ---------- Búsqueda manual (botón / Enter) ----------
    def _buscar(self):
        if self._id_busqueda_programada is not None:
            self.after_cancel(self._id_busqueda_programada)
            self._id_busqueda_programada = None

        if not self.carpeta_busqueda:
            messagebox.showwarning("Aviso", "Primero selecciona la carpeta donde estan tus Excel.")
            return
        texto = self.entrada_busqueda.get().strip()
        if not texto:
            return

        anio_desde, valido_desde = self._leer_anio(self.entrada_anio_desde)
        anio_hasta, valido_hasta = self._leer_anio(self.entrada_anio_hasta)
        if not valido_desde or not valido_hasta:
            messagebox.showwarning("Aviso", "El año debe ser un número (ejemplo: 2021).")
            return
        if anio_desde is not None and anio_hasta is not None and anio_desde > anio_hasta:
            anio_desde, anio_hasta = anio_hasta, anio_desde

        self.etiqueta_estado_vivo.configure(text="")
        self._ejecutar_busqueda(texto, anio_desde, anio_hasta, automatica=False)

    # ---------- Búsqueda "en caliente" mientras escribes ----------
    def _al_escribir(self, evento):
        if self._id_busqueda_programada is not None:
            self.after_cancel(self._id_busqueda_programada)
            self._id_busqueda_programada = None

        texto = self.entrada_busqueda.get().strip()
        if not self.carpeta_busqueda or len(texto) < LARGO_MINIMO_BUSQUEDA_AUTOMATICA:
            self.etiqueta_estado_vivo.configure(text="")
            return

        self.etiqueta_estado_vivo.configure(text="Revisando si ya existe...")
        self._id_busqueda_programada = self.after(RETRASO_BUSQUEDA_AUTOMATICA_MS, self._disparar_busqueda_automatica)

    def _disparar_busqueda_automatica(self):
        self._id_busqueda_programada = None
        texto = self.entrada_busqueda.get().strip()
        if not texto or len(texto) < LARGO_MINIMO_BUSQUEDA_AUTOMATICA:
            return
        self._ejecutar_busqueda(texto, None, None, automatica=True)

    # ---------- Motor compartido ----------
    def _ejecutar_busqueda(self, texto, anio_desde, anio_hasta, automatica):
        self._token_busqueda += 1
        token_de_esta_busqueda = self._token_busqueda

        def tarea():
            resultados = excel_search_service.buscar_en_carpeta(self.carpeta_busqueda, texto, anio_desde, anio_hasta)
            self.after(0, lambda: self._mostrar_resultados(token_de_esta_busqueda, texto, anio_desde, anio_hasta,
                                                            resultados, automatica))

        threading.Thread(target=tarea, daemon=True).start()

    def _mostrar_resultados(self, token, texto, anio_desde, anio_hasta, resultados, automatica):
        if token != self._token_busqueda:
            return  # ya se lanzó una búsqueda más nueva; esta quedó obsoleta

        if automatica:
            self.etiqueta_estado_vivo.configure(text="")

        self.caja_resultado.configure(state="normal")
        self.caja_resultado.delete("1.0", "end")

        if not resultados:
            mensaje = "Sin resultados en ningun Excel de esa carpeta."
            if anio_desde is not None or anio_hasta is not None:
                mensaje += " (revisa que el rango de años sea correcto, o que la columna FECHA tenga un formato reconocible)."
            self.caja_resultado.insert("end", mensaje)
        else:
            if automatica:
                self.caja_resultado.insert(
                    "end", f"⚠️ \"{texto}\" ya registra {len(resultados)} expediente(s) en tu Excel de control.\n\n"
                )
            elif anio_desde is not None or anio_hasta is not None:
                self.caja_resultado.insert("end", f"{len(resultados)} resultado(s) en el rango de años indicado.\n\n")

            for r in resultados:
                if "error" in r:
                    self.caja_resultado.insert("end", f"⚠ {r['archivo']}: {r['error']}\n\n")
                    continue
                self.caja_resultado.insert(
                    "end",
                    f"Archivo: {r['archivo']}  (hoja: {r['hoja']}, fila: {r['fila']})\n"
                    f"DNI: {r.get('dni') or '—'}\n"
                    f"Nombre: {r.get('nombre') or '—'}\n"
                    f"Documento: {r.get('documento') or '—'}\n"
                    f"Fecha: {r.get('fecha') or '—'}\n"
                    f"Estado: {r.get('estado') or '—'}\n"
                    + ("-" * 40) + "\n",
                )
        self.caja_resultado.configure(state="disabled")

        detalle_rango = ""
        if anio_desde is not None or anio_hasta is not None:
            detalle_rango = f" [años {anio_desde or '...'}-{anio_hasta or '...'}]"
        etiqueta_tipo = "automática" if automatica else "manual"
        registrar(f"Busqueda {etiqueta_tipo} \"{texto}\"{detalle_rango} en {self.carpeta_busqueda}: "
                  f"{len(resultados)} resultado(s)")
