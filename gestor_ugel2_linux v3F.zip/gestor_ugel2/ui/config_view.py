"""
config_view.py
---------------
Pantalla de configuración: solo carpetas de trabajo y apariencia.
No existe ningún campo de usuario ni contraseña: la aplicación es de
uso exclusivamente local y no tiene pantalla de acceso.
"""

from tkinter import filedialog, messagebox

import customtkinter as ctk

from config.config_manager import guardar_config, obtener_ruta


class ConfigView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config

        self.columnconfigure(0, weight=1)

        titulo = ctk.CTkLabel(self, text="⚙ Configuración", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 20))

        marco = ctk.CTkFrame(self)
        marco.grid(row=1, column=0, sticky="ew", padx=20)
        marco.columnconfigure(1, weight=1)

        self._campos_carpeta = {}
        self._fila_carpeta(marco, 0, "carpeta_trabajo", "Carpeta de trabajo",
                            self.config_app.get("carpeta_trabajo", ""))
        self._fila_carpeta(marco, 1, "carpeta_busqueda_excel", "Carpeta de tus Excel de control (para Buscar)",
                            self.config_app.get("carpeta_busqueda_excel", ""))
        self._fila_carpeta(marco, 2, "carpeta_reportes", "Carpeta de reportes",
                            obtener_ruta(self.config_app, "carpeta_reportes", "reports"))
        self._fila_carpeta(marco, 3, "carpeta_backups", "Carpeta de copias de seguridad",
                            obtener_ruta(self.config_app, "carpeta_backups", "backups"))

        ctk.CTkLabel(marco, text="Apariencia").grid(row=4, column=0, sticky="w", padx=10, pady=(20, 5))
        self.combo_tema = ctk.CTkComboBox(marco, values=["system", "light", "dark"], command=self._cambiar_tema)
        self.combo_tema.set(self.config_app.get("tema", "system"))
        self.combo_tema.grid(row=4, column=1, sticky="w", padx=10, pady=(20, 5))

        ctk.CTkButton(self, text="Guardar configuración", command=self._guardar).grid(
            row=2, column=0, sticky="w", padx=20, pady=20
        )

        nota = ctk.CTkLabel(
            self,
            text=(
                "Esta aplicación no tiene usuario ni contraseña: se usa localmente,\n"
                "en un equipo de uso personal, sin pantalla de acceso."
            ),
            text_color="gray",
            justify="left",
        )
        nota.grid(row=3, column=0, sticky="w", padx=20, pady=(0, 20))

    def _fila_carpeta(self, marco, fila, clave, etiqueta, valor_inicial):
        ctk.CTkLabel(marco, text=etiqueta).grid(row=fila, column=0, sticky="w", padx=10, pady=10)
        entrada = ctk.CTkEntry(marco)
        entrada.insert(0, valor_inicial)
        entrada.grid(row=fila, column=1, sticky="ew", padx=10, pady=10)
        ctk.CTkButton(marco, text="Elegir...", width=90,
                      command=lambda: self._elegir_carpeta(entrada)).grid(row=fila, column=2, padx=10, pady=10)
        self._campos_carpeta[clave] = entrada

    def _elegir_carpeta(self, entrada):
        carpeta = filedialog.askdirectory()
        if carpeta:
            entrada.delete(0, "end")
            entrada.insert(0, carpeta)

    def _cambiar_tema(self, valor):
        ctk.set_appearance_mode(valor)

    def _guardar(self):
        for clave, entrada in self._campos_carpeta.items():
            self.config_app[clave] = entrada.get().strip()
        self.config_app["tema"] = self.combo_tema.get()
        guardar_config(self.config_app)
        messagebox.showinfo("Configuración", "Configuración guardada correctamente.")
