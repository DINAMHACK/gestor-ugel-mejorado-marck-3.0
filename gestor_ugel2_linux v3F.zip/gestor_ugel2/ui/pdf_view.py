"""
pdf_view.py
-----------
Pantalla del módulo PDF: unir, dividir, rotar, extraer páginas y comprimir.
"""

import os
import threading
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import pdf_service, pdf_to_word_service, pdf_extractor_service, ocr_service
from services.ocr_campos_service import extraer_campos
from ui.ocr_widgets import OcrEstadoFrame
from utils.helpers import tamano_legible
from utils.logger import registrar


class PdfView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config

        self.columnconfigure(0, weight=1)
        self.rowconfigure(1, weight=1)

        titulo = ctk.CTkLabel(self, text="📄 Herramientas PDF", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        pestañas = ctk.CTkTabview(self)
        pestañas.grid(row=1, column=0, sticky="nsew", padx=20, pady=(0, 20))

        pestañas.add("Unir")
        pestañas.add("Dividir")
        pestañas.add("Rotar")
        pestañas.add("Extraer")
        pestañas.add("Comprimir")
        pestañas.add("PDF a Word")
        pestañas.add("Extraer Datos a Excel")
        pestañas.add("Leer escaneados (OCR)")

        self._construir_unir(pestañas.tab("Unir"))
        self._construir_dividir(pestañas.tab("Dividir"))
        self._construir_rotar(pestañas.tab("Rotar"))
        self._construir_extraer(pestañas.tab("Extraer"))
        self._construir_comprimir(pestañas.tab("Comprimir"))
        self._construir_pdf_a_word(pestañas.tab("PDF a Word"))
        self._construir_extraer_datos(pestañas.tab("Extraer Datos a Excel"))
        self._construir_ocr(pestañas.tab("Leer escaneados (OCR)"))


    # ---------- Unir ----------
    def _construir_unir(self, tab):
        self.lista_pdfs_unir = []
        ctk.CTkButton(tab, text="Agregar PDFs...", command=self._agregar_pdfs_unir).pack(pady=10)
        self.caja_unir = ctk.CTkTextbox(tab, height=150)
        self.caja_unir.pack(fill="both", expand=True, padx=10, pady=10)
        ctk.CTkButton(tab, text="Unir en un solo PDF", command=self._ejecutar_unir).pack(pady=10)

    def _agregar_pdfs_unir(self):
        rutas = filedialog.askopenfilenames(title="Selecciona PDFs a unir", filetypes=[("PDF", "*.pdf")])
        if not rutas:
            return
        self.lista_pdfs_unir.extend(rutas)
        self.caja_unir.delete("1.0", "end")
        for ruta in self.lista_pdfs_unir:
            self.caja_unir.insert("end", os.path.basename(ruta) + "\n")

    def _ejecutar_unir(self):
        if len(self.lista_pdfs_unir) < 2:
            messagebox.showwarning("Aviso", "Selecciona al menos dos PDFs.")
            return
        destino = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
                                                initialfile="DOCUMENTO_FINAL.pdf")
        if not destino:
            return
        try:
            pdf_service.unir_pdfs(self.lista_pdfs_unir, destino)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo unir los PDFs:\n{error}")
            return
        registrar(f"Unió {len(self.lista_pdfs_unir)} PDFs en: {destino}")
        messagebox.showinfo("Listo", f"PDF generado en:\n{destino}")
        self.lista_pdfs_unir = []
        self.caja_unir.delete("1.0", "end")

    # ---------- Dividir ----------
    def _construir_dividir(self, tab):
        ctk.CTkButton(tab, text="Seleccionar PDF a dividir", command=self._ejecutar_dividir).pack(pady=20)
        ctk.CTkLabel(tab, text="Se generará un archivo por cada página, en una carpeta que elijas.",
                     wraplength=420, justify="left").pack(padx=10)

    def _ejecutar_dividir(self):
        ruta = filedialog.askopenfilename(title="Selecciona el PDF a dividir", filetypes=[("PDF", "*.pdf")])
        if not ruta:
            return
        carpeta_salida = filedialog.askdirectory(title="Carpeta donde guardar las páginas")
        if not carpeta_salida:
            return
        try:
            generados = pdf_service.dividir_pdf(ruta, carpeta_salida)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo dividir el PDF:\n{error}")
            return
        registrar(f"Dividió {os.path.basename(ruta)} en {len(generados)} páginas")
        messagebox.showinfo("Listo", f"Se generaron {len(generados)} archivos en:\n{carpeta_salida}")

    # ---------- Rotar ----------
    def _construir_rotar(self, tab):
        self.combo_grados = ctk.CTkComboBox(tab, values=["90", "180", "270"], width=120)
        self.combo_grados.set("90")
        self.combo_grados.pack(pady=(20, 10))
        ctk.CTkButton(tab, text="Seleccionar PDF y rotar (todas las páginas)",
                      command=self._ejecutar_rotar).pack(pady=10)

    def _ejecutar_rotar(self):
        ruta = filedialog.askopenfilename(title="Selecciona el PDF a rotar", filetypes=[("PDF", "*.pdf")])
        if not ruta:
            return
        destino = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")])
        if not destino:
            return
        grados = int(self.combo_grados.get())
        try:
            pdf_service.rotar_pdf(ruta, grados, destino)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo rotar el PDF:\n{error}")
            return
        registrar(f"Rotó {grados}° el PDF: {os.path.basename(ruta)}")
        messagebox.showinfo("Listo", f"PDF rotado guardado en:\n{destino}")

    # ---------- Extraer ----------
    def _construir_extraer(self, tab):
        fila = ctk.CTkFrame(tab, fg_color="transparent")
        fila.pack(pady=20)
        ctk.CTkLabel(fila, text="Desde página:").grid(row=0, column=0, padx=5)
        self.entrada_inicio = ctk.CTkEntry(fila, width=60)
        self.entrada_inicio.grid(row=0, column=1, padx=5)
        ctk.CTkLabel(fila, text="Hasta página:").grid(row=0, column=2, padx=5)
        self.entrada_fin = ctk.CTkEntry(fila, width=60)
        self.entrada_fin.grid(row=0, column=3, padx=5)
        ctk.CTkButton(tab, text="Seleccionar PDF y extraer", command=self._ejecutar_extraer).pack(pady=10)

    def _ejecutar_extraer(self):
        try:
            inicio = int(self.entrada_inicio.get())
            fin = int(self.entrada_fin.get())
        except ValueError:
            messagebox.showwarning("Aviso", "Ingresa números válidos de página.")
            return
        ruta = filedialog.askopenfilename(title="Selecciona el PDF", filetypes=[("PDF", "*.pdf")])
        if not ruta:
            return
        destino = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
                                                initialfile="Documento_parte.pdf")
        if not destino:
            return
        try:
            pdf_service.extraer_paginas(ruta, inicio, fin, destino)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo extraer las páginas:\n{error}")
            return
        registrar(f"Extrajo páginas {inicio}-{fin} de {os.path.basename(ruta)}")
        messagebox.showinfo("Listo", f"Extracto guardado en:\n{destino}")

    # ---------- Comprimir ----------
    def _construir_comprimir(self, tab):
        ctk.CTkLabel(tab, text="Calidad de imagen (1-100, menor = más compresión):").pack(pady=(20, 5))
        self.entrada_calidad = ctk.CTkEntry(tab, width=80)
        self.entrada_calidad.insert(0, "60")
        self.entrada_calidad.pack(pady=(0, 10))
        ctk.CTkButton(tab, text="Seleccionar PDF y comprimir", command=self._ejecutar_comprimir).pack(pady=10)

    def _ejecutar_comprimir(self):
        try:
            calidad = int(self.entrada_calidad.get())
            calidad = max(1, min(100, calidad))
        except ValueError:
            calidad = 60
        ruta = filedialog.askopenfilename(title="Selecciona el PDF a comprimir", filetypes=[("PDF", "*.pdf")])
        if not ruta:
            return
        destino = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
                                                initialfile="comprimido.pdf")
        if not destino:
            return
        try:
            resultado = pdf_service.comprimir_pdf(ruta, destino, calidad)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo comprimir el PDF:\n{error}")
            return
        registrar(f"Comprimió {os.path.basename(ruta)}: "
                  f"{tamano_legible(resultado['tamano_original'])} -> {tamano_legible(resultado['tamano_final'])}")
        messagebox.showinfo(
            "Listo",
            "PDF original: {}\nPDF comprimido: {}".format(
                tamano_legible(resultado["tamano_original"]),
                tamano_legible(resultado["tamano_final"]),
            ),
        )

    # ---------- PDF a Word ----------
    def _construir_pdf_a_word(self, tab):
        ctk.CTkLabel(
            tab,
            text=(
                "Convierte un PDF a un documento Word (.docx) editable.\n\n"
                "• PDF con texto real (generado desde Word o un sistema): conserva el formato.\n"
                "• PDF escaneado o foto (PNG/JPG): el programa te ofrece leerlo con OCR y pasar\n"
                "   el TEXTO a Word (sin logos ni diseño de la página; revisa el resultado)."
            ),
            justify="left",
        ).pack(padx=10, pady=(15, 10), anchor="w")

        fila_rango = ctk.CTkFrame(tab, fg_color="transparent")
        fila_rango.pack(pady=(0, 5))
        self.variable_rango_word = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            fila_rango, text="Convertir solo un rango de páginas", variable=self.variable_rango_word
        ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 5))
        ctk.CTkLabel(fila_rango, text="Desde página:").grid(row=1, column=0, padx=5)
        self.entrada_inicio_word = ctk.CTkEntry(fila_rango, width=60)
        self.entrada_inicio_word.grid(row=1, column=1, padx=5)
        ctk.CTkLabel(fila_rango, text="Hasta página:").grid(row=1, column=2, padx=5)
        self.entrada_fin_word = ctk.CTkEntry(fila_rango, width=60)
        self.entrada_fin_word.grid(row=1, column=3, padx=5)

        self.boton_convertir_word = ctk.CTkButton(
            tab, text="Seleccionar PDF y convertir a Word", command=self._ejecutar_pdf_a_word
        )
        self.boton_convertir_word.pack(pady=10)

        self.etiqueta_estado_word = ctk.CTkLabel(tab, text="", text_color="gray")
        self.etiqueta_estado_word.pack()

    def _ejecutar_pdf_a_word(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona el PDF o la foto a convertir",
            filetypes=[("PDF e imágenes", "*.pdf *.png *.jpg *.jpeg *.tif *.tiff"), ("PDF", "*.pdf")],
        )
        if not ruta:
            return

        es_imagen = os.path.splitext(ruta)[1].lower() in ocr_service.EXTENSIONES_IMAGEN
        usar_ocr = es_imagen

        pagina_inicio = pagina_fin = None
        if self.variable_rango_word.get() and not es_imagen:
            try:
                pagina_inicio = int(self.entrada_inicio_word.get())
                pagina_fin = int(self.entrada_fin_word.get())
            except ValueError:
                messagebox.showwarning("Aviso", "Ingresa números válidos de página para el rango.")
                return

        if not es_imagen:
            try:
                escaneado = pdf_to_word_service.pdf_probablemente_es_escaneado(ruta)
            except Exception as error:
                messagebox.showerror("Error", f"No se pudo leer el PDF:\n{error}")
                return
            if escaneado:
                usar_ocr = messagebox.askyesno(
                    "Este PDF parece un escaneo",
                    "No se detectó texto real (es una imagen escaneada).\n\n"
                    "¿Leerlo con OCR y pasar el texto a Word?\n"
                    "Sí = Word con el texto leído (puede tener errores; revísalo).\n"
                    "No = Word con la imagen pegada, sin texto editable.",
                )

        if usar_ocr and not ocr_service.estado_ocr()["disponible"]:
            messagebox.showwarning(
                "Falta el motor OCR",
                "Para leer escaneos hace falta el motor OCR.\n"
                "Ve a la pestaña \"Leer escaneados (OCR)\" y presiona \"Instalar motor OCR\".",
            )
            return

        nombre_sugerido = os.path.splitext(os.path.basename(ruta))[0] + ".docx"
        destino = filedialog.asksaveasfilename(
            defaultextension=".docx", filetypes=[("Word", "*.docx")], initialfile=nombre_sugerido
        )
        if not destino:
            return

        self.boton_convertir_word.configure(state="disabled")
        self.etiqueta_estado_word.configure(text="Convirtiendo, espera un momento...")

        def avance(pagina, total):
            self.after(0, lambda: self.etiqueta_estado_word.configure(text=f"Leyendo página {pagina} de {total}..."))

        def tarea():
            error_resultado = None
            try:
                if usar_ocr:
                    pdf_to_word_service.convertir_escaneado_a_word(ruta, destino, progreso=avance)
                else:
                    pdf_to_word_service.convertir_pdf_a_word(ruta, destino, pagina_inicio, pagina_fin)
            except Exception as error:
                error_resultado = error
            self.after(0, lambda: self._al_terminar_conversion(ruta, destino, error_resultado))

        threading.Thread(target=tarea, daemon=True).start()

    def _al_terminar_conversion(self, ruta_pdf, destino, error):
        self.boton_convertir_word.configure(state="normal")
        self.etiqueta_estado_word.configure(text="")

        if error is not None:
            messagebox.showerror("Error", f"No se pudo convertir el PDF a Word:\n{error}")
            return

        registrar(f"Convirtió a Word: {os.path.basename(ruta_pdf)} -> {os.path.basename(destino)}")
        messagebox.showinfo("Listo", f"Documento Word generado en:\n{destino}")

    # ---------- Extraer Datos de PDF a Excel ----------
    def _construir_extraer_datos(self, tab):
        ctk.CTkLabel(
            tab,
            text=(
                "Lee un lote de documentos y arma un Excel con: N° de resolución, expediente, DNIs, fechas y\n"
                "códigos patrimoniales, más una hoja \"Índice por DNI\" para ubicar el archivo de cada persona.\n"
                "Entiende PDFs digitales, PDFs ESCANEADOS y fotos PNG/JPG (tipo CamScanner) con OCR local.\n"
                "Lo leído por OCR se marca en la columna \"Revisar\" cuando es dudoso: verifícalo en el documento."
            ),
            justify="left",
        ).pack(padx=10, pady=(15, 5), anchor="w")

        self.estado_ocr_extraer = OcrEstadoFrame(tab)
        self.estado_ocr_extraer.pack(fill="x", padx=10, pady=(0, 5))

        fila_opc = ctk.CTkFrame(tab, fg_color="transparent")
        fila_opc.pack(fill="x", padx=10)
        self.var_subcarpetas = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(fila_opc, text="Incluir subcarpetas", variable=self.var_subcarpetas).pack(side="left", padx=(0, 15))
        self.var_usar_ocr = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(fila_opc, text="Leer escaneos y fotos con OCR", variable=self.var_usar_ocr).pack(side="left")

        fila_botones = ctk.CTkFrame(tab, fg_color="transparent")
        fila_botones.pack(pady=8)
        self.boton_extraer_datos = ctk.CTkButton(
            fila_botones, text="Seleccionar carpeta y procesar", command=self._ejecutar_extraccion_datos
        )
        self.boton_extraer_datos.pack(side="left", padx=5)
        self.boton_cancelar_extraer = ctk.CTkButton(
            fila_botones, text="Cancelar", fg_color="gray", state="disabled", command=self._cancelar_extraccion
        )
        self.boton_cancelar_extraer.pack(side="left", padx=5)

        self.etiqueta_estado_extraer = ctk.CTkLabel(tab, text="", text_color="gray")
        self.etiqueta_estado_extraer.pack()

        self.caja_resultado_extraer = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_resultado_extraer.pack(fill="both", expand=True, padx=10, pady=10)
        self._cancelar_extraer = False

    def _cancelar_extraccion(self):
        self._cancelar_extraer = True
        self.etiqueta_estado_extraer.configure(text="Cancelando...")

    def _ejecutar_extraccion_datos(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta con las resoluciones / PDFs / fotos")
        if not carpeta:
            return

        destino = filedialog.asksaveasfilename(
            title="Guardar Excel de Datos Extraídos",
            defaultextension=".xlsx",
            filetypes=[("Excel", "*.xlsx")],
            initialfile="DATOS_EXTRAIDOS_PDF.xlsx",
        )
        if not destino:
            return

        self._cancelar_extraer = False
        self.boton_extraer_datos.configure(state="disabled")
        self.boton_cancelar_extraer.configure(state="normal")
        self.etiqueta_estado_extraer.configure(text="Preparando...")
        usar_ocr = bool(self.var_usar_ocr.get())
        subcarpetas = bool(self.var_subcarpetas.get())

        def avance(i, total, nombre):
            self.after(0, lambda: self.etiqueta_estado_extraer.configure(text=f"Archivo {i} de {total}: {nombre}"))

        def tarea():
            resultado = None
            error_gen = None
            try:
                resultado = pdf_extractor_service.extraer_datos_patrimonio_pdf(
                    carpeta, destino, usar_ocr=usar_ocr, incluir_subcarpetas=subcarpetas,
                    progreso=avance, cancelar=lambda: self._cancelar_extraer,
                )
            except Exception as err:
                error_gen = err
            self.after(0, lambda: self._al_terminar_extraccion_datos(resultado, error_gen))

        threading.Thread(target=tarea, daemon=True).start()

    def _al_terminar_extraccion_datos(self, resultado, error):
        self.boton_extraer_datos.configure(state="normal")
        self.boton_cancelar_extraer.configure(state="disabled")
        self.etiqueta_estado_extraer.configure(text="")

        self.caja_resultado_extraer.delete("1.0", "end")

        if error is not None:
            messagebox.showerror("Error", f"No se pudo extraer datos de los PDFs:\n{error}")
            return

        if "error" in resultado:
            messagebox.showerror("Error", resultado["error"])
            return

        self.caja_resultado_extraer.insert(
            "end",
            f"Procesamiento completado: {resultado['total_procesados']} archivo(s) analizados.\n"
            f"Excel generado en:\n{resultado['ruta_salida']}\n"
            + (f"\n⚠ {resultado['sin_leer']} archivo(s) NO se pudieron leer (ver Excel).\n" if resultado["sin_leer"] else "")
            + ("\n⚠ Motor OCR no instalado: los escaneos y fotos quedaron sin leer.\n"
               if not resultado["ocr_disponible"] and self.var_usar_ocr.get() else "")
            + "\nResumen de coincidencias encontradas:\n"
            + ("-" * 60) + "\n",
        )

        for d in resultado["datos"]:
            marca = "  ⚠ REVISAR\n" if d["revisar"] == "SÍ" else ""
            conf = f" (confianza {d['confianza']}%)" if d["confianza"] != "" else ""
            self.caja_resultado_extraer.insert(
                "end",
                f"Archivo: {d['archivo']}  [{d['metodo']}{conf}]\n"
                f"  Resolución: {d['resolucion']}\n"
                f"  DNIs:       {d['dnis']}\n"
                f"  Fechas:     {d['fechas']}\n"
                + marca + ("-" * 60) + "\n",
            )

        registrar(f"Extrajo datos de {resultado['total_procesados']} archivos -> {resultado['ruta_salida']}")
        messagebox.showinfo("Listo", f"Datos extraídos en:\n{resultado['ruta_salida']}")

    # ---------- Leer escaneados (OCR) ----------
    def _construir_ocr(self, tab):
        self.ocr_resultado = None
        self.ocr_ruta = None
        self._ocr_cancelar = False

        ctk.CTkLabel(
            tab,
            text=(
                "Lee un PDF escaneado o una foto (PNG, JPG, TIF) de un documento, como las que saca CamScanner:\n"
                "endereza la hoja, quita sombras y reconoce el texto en español, sin internet.\n"
                "Luego puedes guardar el texto, crear un PDF BUSCABLE (con texto seleccionable) o pasarlo a Word."
            ),
            justify="left",
        ).pack(padx=10, pady=(12, 4), anchor="w")

        self.estado_ocr_tab = OcrEstadoFrame(tab)
        self.estado_ocr_tab.pack(fill="x", padx=10, pady=(0, 4))

        fila = ctk.CTkFrame(tab, fg_color="transparent")
        fila.pack(fill="x", padx=10, pady=4)
        self.boton_ocr_leer = ctk.CTkButton(fila, text="Seleccionar archivo y leer", command=self._ocr_seleccionar)
        self.boton_ocr_leer.pack(side="left", padx=(0, 8))
        self.boton_ocr_cancelar = ctk.CTkButton(fila, text="Cancelar", fg_color="gray", width=90, state="disabled",
                                                command=self._ocr_cancelar_click)
        self.boton_ocr_cancelar.pack(side="left", padx=(0, 15))
        self.etiqueta_ocr_estado = ctk.CTkLabel(fila, text="", text_color="gray")
        self.etiqueta_ocr_estado.pack(side="left")

        self.caja_ocr_campos = ctk.CTkTextbox(tab, height=125)
        self.caja_ocr_campos.pack(fill="x", padx=10, pady=(4, 4))
        self.caja_ocr_texto = ctk.CTkTextbox(tab)
        self.caja_ocr_texto.pack(fill="both", expand=True, padx=10, pady=4)

        fila2 = ctk.CTkFrame(tab, fg_color="transparent")
        fila2.pack(fill="x", padx=10, pady=(4, 8))
        self.boton_ocr_txt = ctk.CTkButton(fila2, text="Guardar texto (.txt)", state="disabled", command=self._ocr_guardar_txt)
        self.boton_ocr_txt.pack(side="left", padx=(0, 8))
        self.boton_ocr_pdf = ctk.CTkButton(fila2, text="Crear PDF buscable", state="disabled", command=self._ocr_crear_pdf)
        self.boton_ocr_pdf.pack(side="left", padx=(0, 8))
        self.var_ocr_compacto = ctk.BooleanVar(value=True)
        ctk.CTkCheckBox(fila2, text="PDF liviano", variable=self.var_ocr_compacto).pack(side="left", padx=(0, 8))
        self.boton_ocr_word = ctk.CTkButton(fila2, text="Pasar a Word", state="disabled", command=self._ocr_a_word)
        self.boton_ocr_word.pack(side="left")

    def _ocr_cancelar_click(self):
        self._ocr_cancelar = True
        self.etiqueta_ocr_estado.configure(text="Cancelando...")

    def _ocr_ocupado(self, ocupado: bool):
        self.boton_ocr_leer.configure(state="disabled" if ocupado else "normal")
        self.boton_ocr_cancelar.configure(state="normal" if ocupado else "disabled")
        habil = "normal" if (not ocupado and self.ocr_resultado) else "disabled"
        for boton in (self.boton_ocr_txt, self.boton_ocr_pdf, self.boton_ocr_word):
            boton.configure(state=habil)

    def _ocr_seleccionar(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona el documento escaneado o la foto",
            filetypes=[("PDF e imágenes", "*.pdf *.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp"), ("Todos", "*.*")],
        )
        if not ruta:
            return
        if not ocr_service.es_archivo_soportado(ruta):
            messagebox.showwarning("Aviso", "Selecciona un PDF o una imagen (PNG, JPG, TIF).")
            return
        self.ocr_ruta = ruta
        self.ocr_resultado = None
        self._ocr_cancelar = False
        self.caja_ocr_texto.delete("1.0", "end")
        self.caja_ocr_campos.delete("1.0", "end")
        self._ocr_ocupado(True)
        self.etiqueta_ocr_estado.configure(text="Leyendo...")

        def avance(pagina, total):
            self.after(0, lambda: self.etiqueta_ocr_estado.configure(text=f"Leyendo página {pagina} de {total}..."))

        def tarea():
            resultado, error = None, None
            try:
                resultado = ocr_service.leer_archivo(ruta, progreso=avance, cancelar=lambda: self._ocr_cancelar)
            except ocr_service.OcrCancelado:
                error = "Cancelado."
            except ocr_service.OcrNoDisponible as e:
                error = f"{e}\nPresiona \"Instalar motor OCR\" arriba."
            except Exception as e:
                error = str(e)
            self.after(0, lambda: self._ocr_mostrar(resultado, error))

        threading.Thread(target=tarea, daemon=True).start()

    def _ocr_mostrar(self, resultado, error):
        self.etiqueta_ocr_estado.configure(text="")
        if error or not resultado or resultado.get("error"):
            self.ocr_resultado = None
            self._ocr_ocupado(False)
            if error != "Cancelado.":
                messagebox.showerror("No se pudo leer", error or (resultado or {}).get("error", "Error desconocido"))
            return
        self.ocr_resultado = resultado
        self._ocr_ocupado(False)

        campos = extraer_campos(resultado["texto"])
        conf = resultado["confianza_media"]
        origen = "OCR" if resultado["usa_ocr"] else "texto digital (sin OCR)"
        lineas = [f"Páginas: {len(resultado['paginas'])} · Lectura: {origen}"
                  + (f" · Confianza: {conf}%" if conf is not None else "")]
        if conf is not None and conf < ocr_service.CONFIANZA_MINIMA_BUENA + 8:
            lineas.append("⚠ Confianza baja: compara con el documento antes de usar los datos.")
        lineas += [
            "Resolución: " + (", ".join(campos["resoluciones"]) or "No detectada"),
            "DNI (con etiqueta): " + (", ".join(campos["dnis_confirmados"]) or "No detectado")
            + ("   | Otros números de 8 dígitos: " + ", ".join(campos["dnis_posibles"]) if campos["dnis_posibles"] else ""),
            "Fechas: " + (", ".join(campos["fechas"]) or "No detectadas"),
        ]
        if campos["codigos_patrimoniales"]:
            lineas.append("Códigos patrimoniales: " + ", ".join(campos["codigos_patrimoniales"]))
        self.caja_ocr_campos.delete("1.0", "end")
        self.caja_ocr_campos.insert("end", "\n".join(lineas))
        self.caja_ocr_texto.delete("1.0", "end")
        self.caja_ocr_texto.insert("end", resultado["texto"] or "(No se reconoció texto en este archivo.)")
        registrar(f"Leyó con OCR: {os.path.basename(self.ocr_ruta)}")

    def _ocr_guardar_txt(self):
        if not self.ocr_resultado:
            return
        destino = filedialog.asksaveasfilename(
            defaultextension=".txt", filetypes=[("Texto", "*.txt")],
            initialfile=os.path.splitext(os.path.basename(self.ocr_ruta))[0] + ".txt")
        if not destino:
            return
        with open(destino, "w", encoding="utf-8") as f:
            f.write(self.caja_ocr_texto.get("1.0", "end").strip())
        messagebox.showinfo("Listo", f"Texto guardado en:\n{destino}")

    def _ocr_trabajo_largo(self, destino, funcion, mensaje_ok):
        self._ocr_cancelar = False
        self._ocr_ocupado(True)

        def avance(pagina, total):
            self.after(0, lambda: self.etiqueta_ocr_estado.configure(text=f"Procesando página {pagina} de {total}..."))

        def tarea():
            error = None
            try:
                funcion(avance)
            except ocr_service.OcrCancelado:
                error = "Cancelado."
            except Exception as e:
                error = str(e)
            self.after(0, lambda: self._ocr_fin_trabajo(error, destino, mensaje_ok))

        threading.Thread(target=tarea, daemon=True).start()

    def _ocr_fin_trabajo(self, error, destino, mensaje_ok):
        self.etiqueta_ocr_estado.configure(text="")
        self._ocr_ocupado(False)
        if error:
            if error != "Cancelado.":
                messagebox.showerror("Error", error)
            return
        registrar(f"{mensaje_ok}: {destino}")
        messagebox.showinfo("Listo", f"{mensaje_ok}:\n{destino}")

    def _ocr_crear_pdf(self):
        if not self.ocr_ruta:
            return
        destino = filedialog.asksaveasfilename(
            defaultextension=".pdf", filetypes=[("PDF", "*.pdf")],
            initialfile=os.path.splitext(os.path.basename(self.ocr_ruta))[0] + "_buscable.pdf")
        if not destino:
            return
        compacto = bool(self.var_ocr_compacto.get())
        ruta = self.ocr_ruta
        self._ocr_trabajo_largo(
            destino,
            lambda avance: ocr_service.crear_pdf_buscable(ruta, destino, compacto=compacto, progreso=avance,
                                                          cancelar=lambda: self._ocr_cancelar),
            "PDF buscable guardado en")

    def _ocr_a_word(self):
        if not self.ocr_ruta:
            return
        destino = filedialog.asksaveasfilename(
            defaultextension=".docx", filetypes=[("Word", "*.docx")],
            initialfile=os.path.splitext(os.path.basename(self.ocr_ruta))[0] + ".docx")
        if not destino:
            return
        ruta = self.ocr_ruta
        self._ocr_trabajo_largo(
            destino,
            lambda avance: pdf_to_word_service.convertir_escaneado_a_word(ruta, destino, progreso=avance,
                                                                          cancelar=lambda: self._ocr_cancelar),
            "Word guardado en")
