"""
files_view.py
-------------
Pantalla del módulo Archivos: listar, detectar duplicados, nombres
problemáticos, organizar por tipo, buscar y renombrar según una
correspondencia que tú escribes (el programa no adivina nombres).
"""

import os
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import file_service, excel_service, pdf_rename_from_excel_service
from utils.logger import registrar


class FilesView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config
        self.carpeta_actual = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)

        titulo = ctk.CTkLabel(self, text="📁 Archivos", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        fila_carpeta = ctk.CTkFrame(self, fg_color="transparent")
        fila_carpeta.grid(row=1, column=0, sticky="ew", padx=20)
        fila_carpeta.columnconfigure(1, weight=1)

        ctk.CTkButton(fila_carpeta, text="Seleccionar carpeta", command=self.seleccionar_carpeta).grid(
            row=0, column=0, padx=(0, 10)
        )
        self.etiqueta_carpeta = ctk.CTkLabel(fila_carpeta, text="Ninguna carpeta seleccionada", anchor="w")
        self.etiqueta_carpeta.grid(row=0, column=1, sticky="ew")

        pestañas = ctk.CTkTabview(self)
        pestañas.grid(row=2, column=0, sticky="nsew", padx=20, pady=15)
        pestañas.add("Listado")
        pestañas.add("Duplicados")
        pestañas.add("Nombres")
        pestañas.add("Organizar")
        pestañas.add("Buscar")
        pestañas.add("Renombrar")
        pestañas.add("Renombrar desde Excel")

        self._construir_listado(pestañas.tab("Listado"))
        self._construir_duplicados(pestañas.tab("Duplicados"))
        self._construir_nombres(pestañas.tab("Nombres"))
        self._construir_organizar(pestañas.tab("Organizar"))
        self._construir_buscar(pestañas.tab("Buscar"))
        self._construir_renombrar(pestañas.tab("Renombrar"))
        self._construir_renombrar_desde_excel(pestañas.tab("Renombrar desde Excel"))

    def seleccionar_carpeta(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta de documentos")
        if not carpeta:
            return
        self.carpeta_actual = carpeta
        self.etiqueta_carpeta.configure(text=carpeta)
        self._actualizar_listado()

    def _requiere_carpeta(self) -> bool:
        if not self.carpeta_actual:
            messagebox.showwarning("Aviso", "Primero selecciona una carpeta.")
            return False
        return True

    # ---------- Listado ----------
    def _construir_listado(self, tab):
        ctk.CTkButton(tab, text="Actualizar listado", command=self._actualizar_listado).pack(pady=10)
        self.caja_listado = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_listado.pack(fill="both", expand=True, padx=10, pady=10)

    def _actualizar_listado(self):
        if not self._requiere_carpeta():
            return
        archivos = file_service.listar_carpeta(self.carpeta_actual)
        self.caja_listado.delete("1.0", "end")
        if not archivos:
            self.caja_listado.insert("end", "(La carpeta está vacía o no tiene archivos)")
            return
        for archivo in archivos:
            self.caja_listado.insert(
                "end",
                f"{archivo['nombre']:<45} {archivo['tipo']:<10} {archivo['tamano_legible']}\n",
            )

    # ---------- Duplicados ----------
    def _construir_duplicados(self, tab):
        ctk.CTkButton(tab, text="Detectar duplicados (por contenido)", command=self._detectar_duplicados).pack(
            pady=10
        )
        self.caja_duplicados = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_duplicados.pack(fill="both", expand=True, padx=10, pady=10)

    def _detectar_duplicados(self):
        if not self._requiere_carpeta():
            return
        grupos = file_service.detectar_duplicados(self.carpeta_actual)
        self.caja_duplicados.delete("1.0", "end")
        if not grupos:
            self.caja_duplicados.insert("end", "No se encontraron archivos duplicados.")
        else:
            for grupo in grupos:
                self.caja_duplicados.insert("end", "⚠ DUPLICADO:\n")
                for nombre in grupo["archivos"]:
                    self.caja_duplicados.insert("end", f"   - {nombre}\n")
                self.caja_duplicados.insert("end", "\n")
        registrar(f"Detectó duplicados en {self.carpeta_actual}: {len(grupos)} grupo(s)")

    # ---------- Nombres problemáticos ----------
    def _construir_nombres(self, tab):
        ctk.CTkButton(tab, text="Detectar nombres problemáticos", command=self._detectar_nombres).pack(pady=10)
        self.caja_nombres = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_nombres.pack(fill="both", expand=True, padx=10, pady=10)

    def _detectar_nombres(self):
        if not self._requiere_carpeta():
            return
        problemas = file_service.detectar_nombres_problematicos(self.carpeta_actual)
        self.caja_nombres.delete("1.0", "end")
        if not problemas:
            self.caja_nombres.insert("end", "No se encontraron nombres problemáticos.")
        else:
            for item in problemas:
                self.caja_nombres.insert("end", f"{item['nombre']}: {', '.join(item['motivos'])}\n")

    # ---------- Organizar ----------
    def _construir_organizar(self, tab):
        ctk.CTkLabel(
            tab,
            text="Mueve los archivos a subcarpetas PDF/, Imagenes/ y Otros/\ndentro de la carpeta seleccionada.",
            justify="left",
        ).pack(pady=20)
        ctk.CTkButton(tab, text="Organizar por tipo", command=self._organizar).pack(pady=10)

    def _organizar(self):
        if not self._requiere_carpeta():
            return
        if not messagebox.askyesno("Confirmar", "Esto moverá los archivos a subcarpetas. ¿Continuar?"):
            return
        contador = file_service.organizar_por_tipo(self.carpeta_actual)
        registrar(f"Organizó archivos en {self.carpeta_actual}: {contador}")
        messagebox.showinfo(
            "Listo",
            f"PDF movidos: {contador['PDF']}\nImágenes movidas: {contador['Imagen']}\nOtros movidos: {contador['Otro']}",
        )
        self._actualizar_listado()

    # ---------- Buscar ----------
    def _construir_buscar(self, tab):
        fila = ctk.CTkFrame(tab, fg_color="transparent")
        fila.pack(pady=15)
        self.entrada_busqueda = ctk.CTkEntry(fila, width=250, placeholder_text="Texto a buscar en el nombre")
        self.entrada_busqueda.pack(side="left", padx=(0, 10))
        ctk.CTkButton(fila, text="Buscar", command=self._buscar).pack(side="left")
        self.caja_busqueda = ctk.CTkTextbox(tab, font=ctk.CTkFont(family="Consolas", size=12))
        self.caja_busqueda.pack(fill="both", expand=True, padx=10, pady=10)

    def _buscar(self):
        if not self._requiere_carpeta():
            return
        texto = self.entrada_busqueda.get().strip()
        if not texto:
            return
        resultados = file_service.buscar_por_nombre(self.carpeta_actual, texto)
        self.caja_busqueda.delete("1.0", "end")
        if not resultados:
            self.caja_busqueda.insert("end", "Sin resultados.")
        else:
            for archivo in resultados:
                self.caja_busqueda.insert("end", f"{archivo['nombre']}  ({archivo['tamano_legible']})\n")

    # ---------- Renombrar ----------
    def _construir_renombrar(self, tab):
        ctk.CTkLabel(
            tab,
            text=(
                "Escribe una línea por archivo, con el formato:\n"
                "nombre_actual.pdf = nombre_nuevo.pdf\n\n"
                "El programa solo aplica lo que tú indiques aquí; no adivina nombres."
            ),
            justify="left",
        ).pack(pady=(15, 5), padx=10, anchor="w")
        self.caja_correspondencia = ctk.CTkTextbox(tab, height=150)
        self.caja_correspondencia.pack(fill="x", padx=10, pady=10)
        ctk.CTkButton(tab, text="Aplicar renombrado", command=self._renombrar).pack(pady=5)
        self.caja_resultado_renombrar = ctk.CTkTextbox(tab, height=100)
        self.caja_resultado_renombrar.pack(fill="both", expand=True, padx=10, pady=10)

    def _renombrar(self):
        if not self._requiere_carpeta():
            return
        texto = self.caja_correspondencia.get("1.0", "end").strip()
        if not texto:
            return

        correspondencia = {}
        for linea in texto.splitlines():
            if "=" not in linea:
                continue
            origen, destino = linea.split("=", 1)
            origen = origen.strip()
            destino = destino.strip()
            if origen and destino:
                correspondencia[origen] = destino

        if not correspondencia:
            messagebox.showwarning("Aviso", "No se reconoció ninguna línea con el formato actual=nuevo.")
            return

        resultados = file_service.renombrar_archivos(self.carpeta_actual, correspondencia)
        self.caja_resultado_renombrar.delete("1.0", "end")
        exitosos = 0
        for r in resultados:
            simbolo = "✓" if r["ok"] else "✗"
            self.caja_resultado_renombrar.insert("end", f"{simbolo} {r['origen']} -> {r['detalle']}\n")
            if r["ok"]:
                exitosos += 1

        registrar(f"Renombró {exitosos} de {len(resultados)} archivo(s) en {self.carpeta_actual}")
        self._actualizar_listado()

    # ---------- Renombrar desde Excel (con vista previa obligatoria) ----------
    def _construir_renombrar_desde_excel(self, tab):
        self.ruta_excel_renombrar = None
        self.propuestas_renombrar = []
        self.filas_widgets_renombrar = []

        ctk.CTkLabel(
            tab,
            text=(
                "Empareja, EN ORDEN, las filas del Excel con los PDFs de la carpeta seleccionada arriba\n"
                "(fila 1 = primer PDF, fila 2 = segundo PDF...). Solo funciona bien si escaneaste en\n"
                "ese mismo orden. Revisa la vista previa y destilda lo que no corresponda antes de aplicar."
            ),
            justify="left",
        ).pack(padx=10, pady=(10, 5), anchor="w")

        fila_excel = ctk.CTkFrame(tab, fg_color="transparent")
        fila_excel.pack(fill="x", padx=10, pady=5)
        ctk.CTkButton(fila_excel, text="Seleccionar Excel", command=self._elegir_excel_renombrar).pack(
            side="left", padx=(0, 10)
        )
        self.etiqueta_excel_renombrar = ctk.CTkLabel(fila_excel, text="Ningún Excel seleccionado")
        self.etiqueta_excel_renombrar.pack(side="left", padx=(0, 10))
        self.combo_hoja_renombrar = ctk.CTkComboBox(fila_excel, values=[], width=180)
        self.combo_hoja_renombrar.pack(side="left")

        ctk.CTkButton(tab, text="Generar vista previa", command=self._generar_vista_previa_renombrar).pack(pady=5)

        self.etiqueta_aviso_renombrar = ctk.CTkLabel(tab, text="", text_color="orange", justify="left", wraplength=500)
        self.etiqueta_aviso_renombrar.pack(padx=10, anchor="w")

        self.marco_scroll_renombrar = ctk.CTkScrollableFrame(tab, height=220)
        self.marco_scroll_renombrar.pack(fill="both", expand=True, padx=10, pady=10)

        ctk.CTkButton(tab, text="Aplicar renombrado (solo lo marcado)",
                      command=self._aplicar_renombrado_desde_excel).pack(pady=(0, 10))

    def _elegir_excel_renombrar(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_excel_renombrar = ruta
        self.etiqueta_excel_renombrar.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hoja_renombrar.configure(values=hojas)
        if hojas:
            self.combo_hoja_renombrar.set(hojas[0])

    def _generar_vista_previa_renombrar(self):
        if not self._requiere_carpeta():
            return
        if not self.ruta_excel_renombrar:
            messagebox.showwarning("Aviso", "Primero selecciona un Excel.")
            return

        resultado = pdf_rename_from_excel_service.generar_propuesta(
            self.ruta_excel_renombrar, self.combo_hoja_renombrar.get(), self.carpeta_actual
        )

        if "error" in resultado:
            messagebox.showerror("Error", resultado["error"])
            return

        self.propuestas_renombrar = resultado["propuestas"]
        self.etiqueta_aviso_renombrar.configure(text=resultado.get("aviso") or "")

        for widget in self.marco_scroll_renombrar.winfo_children():
            widget.destroy()
        self.filas_widgets_renombrar = []

        if not self.propuestas_renombrar:
            ctk.CTkLabel(self.marco_scroll_renombrar, text="No hay propuestas para mostrar.").pack(pady=10)
            return

        encabezado = ctk.CTkFrame(self.marco_scroll_renombrar, fg_color="transparent")
        encabezado.pack(fill="x", pady=(0, 5))
        ctk.CTkLabel(encabezado, text="Incluir", width=60).pack(side="left")
        ctk.CTkLabel(encabezado, text="PDF actual", width=160, anchor="w").pack(side="left")
        ctk.CTkLabel(encabezado, text="Nombre propuesto (editable)", width=260, anchor="w").pack(side="left")

        for propuesta in self.propuestas_renombrar:
            fila = ctk.CTkFrame(self.marco_scroll_renombrar, fg_color="transparent")
            fila.pack(fill="x", pady=2)

            variable_incluir = ctk.BooleanVar(value=propuesta["incluir"])
            ctk.CTkCheckBox(fila, text="", variable=variable_incluir, width=60).pack(side="left")

            ctk.CTkLabel(fila, text=propuesta["pdf_actual"], width=160, anchor="w").pack(side="left", padx=(0, 10))

            entrada_nombre = ctk.CTkEntry(fila, width=260)
            entrada_nombre.insert(0, propuesta["nombre_propuesto"] or "")
            entrada_nombre.pack(side="left")

            self.filas_widgets_renombrar.append({
                "propuesta": propuesta,
                "variable_incluir": variable_incluir,
                "entrada_nombre": entrada_nombre,
            })

    def _aplicar_renombrado_desde_excel(self):
        if not self.filas_widgets_renombrar:
            messagebox.showwarning("Aviso", "Primero genera la vista previa.")
            return

        propuestas_finales = []
        for item in self.filas_widgets_renombrar:
            propuesta = dict(item["propuesta"])
            propuesta["incluir"] = item["variable_incluir"].get()
            propuesta["nombre_propuesto"] = item["entrada_nombre"].get().strip()
            propuestas_finales.append(propuesta)

        seleccionadas = [p for p in propuestas_finales if p["incluir"]]
        if not seleccionadas:
            messagebox.showwarning("Aviso", "No marcaste ningún archivo para renombrar.")
            return

        if not messagebox.askyesno(
            "Confirmar renombrado",
            f"Vas a renombrar {len(seleccionadas)} archivo(s). Esta acción no se puede deshacer "
            "automáticamente. ¿Continuar?",
        ):
            return

        resultados = pdf_rename_from_excel_service.aplicar_renombrado(self.carpeta_actual, propuestas_finales)

        exitosos = sum(1 for r in resultados if r["ok"])
        detalle = "\n".join(
            f"{'✓' if r['ok'] else '✗'} {r['origen']} -> {r['detalle']}" for r in resultados
        )
        messagebox.showinfo("Resultado del renombrado", detalle or "No se aplicó ningún cambio.")

        registrar(
            f"Renombró desde Excel {exitosos} de {len(seleccionadas)} archivo(s) en {self.carpeta_actual} "
            f"(Excel: {os.path.basename(self.ruta_excel_renombrar)})"
        )
        self._actualizar_listado()
