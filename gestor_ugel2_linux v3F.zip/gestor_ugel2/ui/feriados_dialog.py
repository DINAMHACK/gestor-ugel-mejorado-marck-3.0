"""
feriados_dialog.py
------------------
Ventana "Feriados y días no laborables": permite ver los feriados
nacionales del año (solo lectura) y administrar, con el mouse, los días
que cambian según el Gobierno o la zona: días no laborables del sector
público, feriados regionales y feriados locales (por ejemplo, Lambayeque).

Todo se guarda en datos/dias_no_laborables.json. Nada de editar archivos
a mano.
"""

from datetime import date, datetime
from tkinter import messagebox

import customtkinter as ctk

from services import dias_habiles_service as dh

DIAS_SEMANA = ["lun", "mar", "mié", "jue", "vie", "sáb", "dom"]


class FeriadosDialog(ctk.CTkToplevel):
    def __init__(self, master, al_guardar=None):
        super().__init__(master)
        self.title("Feriados y días no laborables")
        self.geometry("760x640")
        self.minsize(700, 560)
        self.al_guardar = al_guardar
        self.dias = dh.cargar_dias_personalizados()

        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(4, weight=1)

        # ---- Feriados nacionales (solo lectura) ----
        fila_sup = ctk.CTkFrame(self, fg_color="transparent")
        fila_sup.grid(row=0, column=0, sticky="ew", padx=15, pady=(15, 5))
        ctk.CTkLabel(fila_sup, text="Feriados nacionales del año:",
                     font=ctk.CTkFont(weight="bold")).pack(side="left")
        anio_actual = date.today().year
        self.combo_anio = ctk.CTkComboBox(
            fila_sup, values=[str(a) for a in range(anio_actual - 2, anio_actual + 3)],
            width=90, command=lambda _v: self._mostrar_nacionales(),
        )
        self.combo_anio.set(str(anio_actual))
        self.combo_anio.pack(side="left", padx=10)
        ctk.CTkLabel(fila_sup, text="(fijados por ley, no se editan)", text_color="gray").pack(side="left")

        self.caja_nacionales = ctk.CTkTextbox(self, height=170)
        self.caja_nacionales.grid(row=1, column=0, sticky="ew", padx=15)
        self.caja_nacionales.configure(state="disabled")

        # ---- Días editables ----
        ctk.CTkLabel(
            self,
            text=("Días no laborables y feriados regionales/locales (marca los que quieres que "
                  "se DESCUENTEN al contar días hábiles):"),
            wraplength=720, justify="left", font=ctk.CTkFont(weight="bold"),
        ).grid(row=2, column=0, sticky="nw", padx=15, pady=(12, 0))

        self.marco_lista = ctk.CTkScrollableFrame(self)
        self.marco_lista.grid(row=3, column=0, sticky="nsew", padx=15, pady=5)
        self.rowconfigure(3, weight=1)

        # ---- Agregar ----
        marco_agregar = ctk.CTkFrame(self)
        marco_agregar.grid(row=4, column=0, sticky="ew", padx=15, pady=(5, 5))
        ctk.CTkLabel(marco_agregar, text="Agregar:", font=ctk.CTkFont(weight="bold")).grid(
            row=0, column=0, padx=8, pady=8)
        self.entrada_fecha = ctk.CTkEntry(marco_agregar, width=105, placeholder_text="dd/mm/aaaa")
        self.entrada_fecha.grid(row=0, column=1, padx=4)
        self.entrada_nombre = ctk.CTkEntry(marco_agregar, width=230, placeholder_text="Nombre o motivo")
        self.entrada_nombre.grid(row=0, column=2, padx=4)
        self.combo_tipo = ctk.CTkComboBox(marco_agregar, values=list(dh.TIPOS.values()), width=200)
        self.combo_tipo.set(dh.TIPOS["no_laborable_sp"])
        self.combo_tipo.grid(row=0, column=3, padx=4)
        self.var_anual = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(marco_agregar, text="Se repite todos los años", variable=self.var_anual).grid(
            row=1, column=1, columnspan=2, sticky="w", padx=8, pady=(0, 8))
        ctk.CTkButton(marco_agregar, text="Agregar a la lista", command=self._agregar).grid(
            row=1, column=3, padx=4, pady=(0, 8))

        ctk.CTkLabel(
            self,
            text=("Nota: un feriado regional o local solo debe descontarse si una norma del Gobierno "
                  "Regional o de la Municipalidad lo declara no laborable. Si no estás seguro, déjalo "
                  "desmarcado: el plazo se cuenta de forma más estricta."),
            text_color="gray", wraplength=720, justify="left",
        ).grid(row=5, column=0, sticky="w", padx=15, pady=(0, 5))

        fila_botones = ctk.CTkFrame(self, fg_color="transparent")
        fila_botones.grid(row=6, column=0, sticky="e", padx=15, pady=(5, 15))
        ctk.CTkButton(fila_botones, text="Guardar y cerrar", command=self._guardar).pack(side="left", padx=5)
        ctk.CTkButton(fila_botones, text="Cancelar", fg_color="gray", command=self.destroy).pack(side="left")

        self._mostrar_nacionales()
        self._dibujar_lista()
        self.after(150, self._traer_al_frente)

    def _traer_al_frente(self):
        try:
            self.lift()
            self.focus_force()
            self.grab_set()
        except Exception:
            pass

    # ---------- nacionales ----------
    def _mostrar_nacionales(self):
        anio = int(self.combo_anio.get())
        lineas = []
        for fecha, nombre in dh.feriados_nacionales(anio).items():
            lineas.append(f"{DIAS_SEMANA[fecha.weekday()]} {fecha.strftime('%d/%m/%Y')}  —  {nombre}")
        self.caja_nacionales.configure(state="normal")
        self.caja_nacionales.delete("1.0", "end")
        self.caja_nacionales.insert("end", "\n".join(lineas))
        self.caja_nacionales.configure(state="disabled")

    # ---------- editables ----------
    @staticmethod
    def _texto_fecha(entrada: dict) -> str:
        if entrada.get("anual") and entrada.get("mes_dia"):
            mes, dia = entrada["mes_dia"].split("-")
            return f"{dia}/{mes} (cada año)"
        try:
            return date.fromisoformat(entrada.get("fecha", "")).strftime("%d/%m/%Y")
        except ValueError:
            return str(entrada.get("fecha", "?"))

    def _dibujar_lista(self):
        for w in self.marco_lista.winfo_children():
            w.destroy()
        if not self.dias:
            ctk.CTkLabel(self.marco_lista, text="No hay días en la lista.").pack(pady=10)
            return
        for indice, entrada in enumerate(self.dias):
            fila = ctk.CTkFrame(self.marco_lista, fg_color="transparent")
            fila.pack(fill="x", pady=1)
            var = ctk.BooleanVar(value=bool(entrada.get("activo", True)))

            def cambiar(i=indice, v=var):
                self.dias[i]["activo"] = bool(v.get())

            ctk.CTkCheckBox(fila, text="", variable=var, width=24, command=cambiar).pack(side="left", padx=(4, 6))
            ctk.CTkLabel(fila, text=self._texto_fecha(entrada), width=130, anchor="w").pack(side="left")
            ctk.CTkLabel(fila, text=entrada.get("nombre", ""), width=250, anchor="w").pack(side="left")
            ctk.CTkLabel(fila, text=dh.TIPOS.get(entrada.get("tipo"), entrada.get("tipo", "")),
                         width=170, anchor="w", text_color="gray").pack(side="left")
            ctk.CTkButton(fila, text="Quitar", width=60, fg_color="gray",
                          command=lambda i=indice: self._quitar(i)).pack(side="right", padx=4)

    def _quitar(self, indice: int):
        del self.dias[indice]
        self._dibujar_lista()

    def _agregar(self):
        texto_fecha = self.entrada_fecha.get().strip()
        nombre = self.entrada_nombre.get().strip()
        try:
            fecha = datetime.strptime(texto_fecha, "%d/%m/%Y").date()
        except ValueError:
            messagebox.showwarning("Fecha no válida", "Escribe la fecha como dd/mm/aaaa (ejemplo: 27/12/2026).",
                                   parent=self)
            return
        if not nombre:
            messagebox.showwarning("Falta el nombre", "Escribe un nombre o motivo (ejemplo: Día no laborable).",
                                   parent=self)
            return
        tipo = next((k for k, v in dh.TIPOS.items() if v == self.combo_tipo.get()), "no_laborable_sp")
        entrada = {"nombre": nombre, "tipo": tipo, "activo": True}
        if self.var_anual.get():
            entrada["mes_dia"] = fecha.strftime("%m-%d")
            entrada["anual"] = True
        else:
            entrada["fecha"] = fecha.isoformat()
        self.dias.append(entrada)
        self.entrada_fecha.delete(0, "end")
        self.entrada_nombre.delete(0, "end")
        self._dibujar_lista()

    def _guardar(self):
        try:
            dh.guardar_dias_personalizados(self.dias)
        except OSError as error:
            messagebox.showerror("Error", f"No se pudo guardar:\n{error}", parent=self)
            return
        if self.al_guardar:
            self.al_guardar()
        self.destroy()
