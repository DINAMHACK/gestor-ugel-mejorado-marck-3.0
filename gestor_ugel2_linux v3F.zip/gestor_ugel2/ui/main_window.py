"""
main_window.py
---------------
Ventana principal de la aplicación. Se abre directamente aquí: no hay
ninguna pantalla de usuario/contraseña antes de esto.
"""

import customtkinter as ctk

from ui.excel_view import ExcelView
from ui.excel_avanzado_view import ExcelAvanzadoView
from ui.pdf_view import PdfView
from ui.files_view import FilesView
from ui.search_view import SearchView
from ui.validate_view import ValidateView
from ui.plazos_view import PlazosView
from ui.reports_view import ReportsView
from ui.config_view import ConfigView
from utils.logger import registrar


class VentanaPrincipal(ctk.CTk):
    def __init__(self, config: dict):
        super().__init__()
        self.config_app = config

        self.title(f"{config.get('nombre_app', 'Gestor Documental UGEL')} — v{config.get('version', '1.0')}")
        self.geometry("1100x680")
        self.minsize(900, 560)

        ctk.set_appearance_mode(config.get("tema", "system"))
        ctk.set_default_color_theme(config.get("color_tema", "blue"))

        self.columnconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self._construir_menu_lateral()
        self._construir_contenedor_vistas()

        self.vistas = {}
        self._mostrar_vista("inicio")

        registrar("Se inició la aplicación")

    def _construir_menu_lateral(self):
        menu = ctk.CTkFrame(self, width=220, corner_radius=0)
        menu.grid(row=0, column=0, sticky="nsw")
        menu.grid_propagate(False)

        ctk.CTkLabel(
            menu, text="GESTOR\nDOCUMENTAL\nUGEL", font=ctk.CTkFont(size=18, weight="bold"), justify="left"
        ).pack(padx=20, pady=(25, 20), anchor="w")

        opciones = [
            ("🏠  Inicio", "inicio"),
            ("📊  Excel", "excel"),
            ("🛠  Herramientas Excel", "excel_avanzado"),
            ("📄  Herramientas PDF", "pdf"),
            ("📁  Archivos", "archivos"),
            ("🔎  Buscar", "buscar"),
            ("✓  Validar documentos", "validar"),
            ("🚦  Control de Plazos", "plazos"),
            ("📋  Reportes", "reportes"),
            ("⚙  Configuración", "configuracion"),
        ]

        for texto, clave in opciones:
            boton = ctk.CTkButton(
                menu, text=texto, anchor="w", fg_color="transparent",
                text_color=("gray10", "gray90"), hover_color=("gray75", "gray30"),
                command=lambda c=clave: self._mostrar_vista(c),
            )
            boton.pack(fill="x", padx=10, pady=4)

    def _construir_contenedor_vistas(self):
        self.contenedor = ctk.CTkFrame(self, fg_color="transparent")
        self.contenedor.grid(row=0, column=1, sticky="nsew")
        self.contenedor.columnconfigure(0, weight=1)
        self.contenedor.rowconfigure(0, weight=1)

    def _mostrar_vista(self, clave: str):
        for hijo in self.contenedor.winfo_children():
            hijo.grid_forget()

        if clave not in self.vistas:
            self.vistas[clave] = self._crear_vista(clave)

        self.vistas[clave].grid(row=0, column=0, sticky="nsew")

    def _crear_vista(self, clave: str):
        if clave == "excel":
            return ExcelView(self.contenedor, self.config_app)
        if clave == "excel_avanzado":
            return ExcelAvanzadoView(self.contenedor, self.config_app)
        if clave == "pdf":
            return PdfView(self.contenedor, self.config_app)
        if clave == "archivos":
            return FilesView(self.contenedor, self.config_app)
        if clave == "buscar":
            return SearchView(self.contenedor, self.config_app)
        if clave == "validar":
            return ValidateView(self.contenedor, self.config_app)
        if clave == "plazos":
            return PlazosView(self.contenedor, self.config_app)
        if clave == "reportes":
            return ReportsView(self.contenedor, self.config_app)
        if clave == "configuracion":
            return ConfigView(self.contenedor, self.config_app)
        return self._crear_vista_inicio()

    def _crear_vista_inicio(self):
        marco = ctk.CTkFrame(self.contenedor, fg_color="transparent")
        ctk.CTkLabel(
            marco,
            text=f"{self.config_app.get('nombre_app', 'Gestor Documental UGEL')}",
            font=ctk.CTkFont(size=26, weight="bold"),
        ).pack(padx=30, pady=(40, 10), anchor="w")
        ctk.CTkLabel(
            marco,
            text=(
                "Herramienta local para preparar, validar y organizar documentos\n"
                "antes de usarlos manualmente en el sistema oficial.\n\n"
                "Todo el procesamiento ocurre en este equipo: no se envía\n"
                "información a internet ni a servicios externos."
            ),
            justify="left",
            font=ctk.CTkFont(size=14),
        ).pack(padx=30, anchor="w")
        return marco
