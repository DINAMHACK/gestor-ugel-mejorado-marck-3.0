"""
validate_view.py
-----------------
Pantalla de validación general: junta el Excel y la carpeta de archivos
en un único resultado, con el formato de resumen pensado desde el diseño
del programa.
"""

import os
import threading
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import excel_service, validation_service, report_service
from config.config_manager import obtener_ruta
from utils.logger import registrar


class ValidateView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config
        self.ruta_excel = None
        self.carpeta_archivos = None
        self.ultimo_resumen = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(3, weight=1)

        titulo = ctk.CTkLabel(self, text="✓ Validar documentos", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 10))

        fila1 = ctk.CTkFrame(self, fg_color="transparent")
        fila1.grid(row=1, column=0, sticky="ew", padx=20)
        fila1.columnconfigure(1, weight=1)
        ctk.CTkButton(fila1, text="Seleccionar Excel", command=self._seleccionar_excel).grid(row=0, column=0, padx=(0, 10))
        self.etiqueta_excel = ctk.CTkLabel(fila1, text="Ningún Excel seleccionado", anchor="w")
        self.etiqueta_excel.grid(row=0, column=1, sticky="ew")

        self.combo_hojas = ctk.CTkComboBox(fila1, values=[], width=200)
        self.combo_hojas.grid(row=0, column=2, padx=10)

        fila2 = ctk.CTkFrame(self, fg_color="transparent")
        fila2.grid(row=2, column=0, sticky="ew", padx=20, pady=10)
        fila2.columnconfigure(1, weight=1)
        ctk.CTkButton(fila2, text="Seleccionar carpeta de archivos", command=self._seleccionar_carpeta).grid(
            row=0, column=0, padx=(0, 10)
        )
        self.etiqueta_carpeta = ctk.CTkLabel(fila2, text="Ninguna carpeta seleccionada", anchor="w")
        self.etiqueta_carpeta.grid(row=0, column=1, sticky="ew")

        self.boton_validar = ctk.CTkButton(fila2, text="VALIDAR", command=self._validar, width=120)
        self.boton_validar.grid(row=0, column=2, padx=10)

        self.caja_resultado = ctk.CTkTextbox(self, font=ctk.CTkFont(family="Consolas", size=13))
        self.caja_resultado.grid(row=3, column=0, sticky="nsew", padx=20, pady=(0, 10))
        self.caja_resultado.configure(state="disabled")

        fila_reportes = ctk.CTkFrame(self, fg_color="transparent")
        fila_reportes.grid(row=4, column=0, sticky="ew", padx=20, pady=(0, 20))
        ctk.CTkButton(fila_reportes, text="Reporte Excel", command=lambda: self._generar_reporte("xlsx")).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila_reportes, text="Reporte CSV", command=lambda: self._generar_reporte("csv")).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila_reportes, text="Reporte TXT", command=lambda: self._generar_reporte("txt")).pack(
            side="left"
        )

    def _seleccionar_excel(self):
        ruta = filedialog.askopenfilename(title="Selecciona el Excel", filetypes=[("Excel", "*.xlsx *.xlsm")])
        if not ruta:
            return
        self.ruta_excel = ruta
        self.etiqueta_excel.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hojas.configure(values=hojas)
        if hojas:
            self.combo_hojas.set(hojas[0])

    def _seleccionar_carpeta(self):
        carpeta = filedialog.askdirectory(title="Selecciona la carpeta de archivos")
        if not carpeta:
            return
        self.carpeta_archivos = carpeta
        self.etiqueta_carpeta.configure(text=carpeta)

    def _validar(self):
        if not self.ruta_excel or not self.carpeta_archivos:
            messagebox.showwarning("Aviso", "Selecciona el Excel y la carpeta de archivos.")
            return

        hoja = self.combo_hojas.get()
        tipos_validos = self.config_app.get("tipos_documento_validos", [])
        estados_validos = self.config_app.get("estados_validos", [])
        self.boton_validar.configure(state="disabled", text="Validando...")

        def tarea():
            resumen = validation_service.validar_lote(
                self.ruta_excel, hoja, self.carpeta_archivos, tipos_validos, estados_validos
            )
            self.after(0, lambda: self._mostrar_resumen(resumen))

        threading.Thread(target=tarea, daemon=True).start()

    def _mostrar_resumen(self, resumen):
        self.boton_validar.configure(state="normal", text="VALIDAR")
        self.ultimo_resumen = resumen

        self.caja_resultado.configure(state="normal")
        self.caja_resultado.delete("1.0", "end")
        texto = validation_service.formatear_resumen_texto(resumen)
        self.caja_resultado.insert("end", texto)
        self.caja_resultado.configure(state="disabled")

        if "error" not in resumen:
            registrar(
                f"Validación general: {resumen['correctos']} correctos, {resumen['observados']} observados"
            )

    def _generar_reporte(self, formato):
        if not self.ultimo_resumen or "error" in self.ultimo_resumen:
            messagebox.showwarning("Aviso", "Primero ejecuta una validación.")
            return

        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        try:
            if formato == "xlsx":
                ruta = report_service.generar_reporte_excel(self.ultimo_resumen, carpeta)
            elif formato == "csv":
                ruta = report_service.generar_reporte_csv(self.ultimo_resumen, carpeta)
            else:
                texto = validation_service.formatear_resumen_texto(self.ultimo_resumen)
                ruta = report_service.generar_reporte_txt(texto, carpeta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el reporte:\n{error}")
            return

        registrar(f"Generó reporte {formato.upper()} desde validación general: {ruta}")
        messagebox.showinfo("Reporte generado", f"Reporte guardado en:\n{ruta}")
