"""
ocr_widgets.py
--------------
Componente de pantalla que muestra si el motor OCR está listo y, si no,
lo instala con un botón (pide la contraseña en una ventana gráfica de
Linux; no se usa la terminal).
"""

import threading
from tkinter import messagebox

import customtkinter as ctk

from services import ocr_service
from utils.logger import registrar


class OcrEstadoFrame(ctk.CTkFrame):
    def __init__(self, master, al_cambiar=None):
        super().__init__(master, fg_color="transparent")
        self.al_cambiar = al_cambiar
        self.etiqueta = ctk.CTkLabel(self, text="Comprobando motor OCR...", anchor="w", justify="left",
                                     wraplength=520)
        self.etiqueta.pack(side="left", padx=(0, 10))
        self.boton_instalar = ctk.CTkButton(self, text="Instalar motor OCR", width=150, command=self._instalar)
        self.boton_comprobar = ctk.CTkButton(self, text="Volver a comprobar", width=140, fg_color="gray",
                                             command=self.comprobar)
        self.disponible = False
        self.after(100, self.comprobar)

    def comprobar(self):
        estado = ocr_service.estado_ocr()
        self.disponible = estado["disponible"]
        if self.disponible:
            self.etiqueta.configure(text="✓ " + estado["mensaje"], text_color="#1E7A34")
            self.boton_instalar.pack_forget()
            self.boton_comprobar.pack_forget()
        else:
            self.etiqueta.configure(
                text="⚠ " + estado["mensaje"] + " Los PDFs con texto digital igual se leen; los escaneos y fotos no.",
                text_color="#B00020")
            self.boton_instalar.configure(state="normal", text="Instalar motor OCR")
            self.boton_instalar.pack(side="left", padx=(0, 6))
            self.boton_comprobar.pack(side="left")
        if self.al_cambiar:
            self.al_cambiar(self.disponible)

    def _instalar(self):
        if not messagebox.askokcancel(
            "Instalar motor OCR",
            "Se instalará el motor de lectura de escaneos (Tesseract en español).\n"
            "Necesita internet y la contraseña de tu usuario de Linux (se pide en una ventana).\n"
            "Puede tardar uno o dos minutos.\n\n¿Continuar?",
        ):
            return
        self.boton_instalar.configure(state="disabled", text="Instalando...")
        self.etiqueta.configure(text="Instalando el motor OCR, espera un momento...", text_color="gray")

        def tarea():
            ok, mensaje = ocr_service.instalar_motor_ocr()
            self.after(0, lambda: self._al_terminar(ok, mensaje))

        threading.Thread(target=tarea, daemon=True).start()

    def _al_terminar(self, ok, mensaje):
        registrar("Instaló el motor OCR" if ok else f"No se pudo instalar el motor OCR: {mensaje}")
        self.comprobar()
        if ok:
            messagebox.showinfo("Listo", "El motor OCR quedó instalado. Ya puedes leer escaneos y fotos.")
        else:
            messagebox.showwarning("No se pudo instalar", mensaje)
