"""
plazos_view.py
--------------
Pantalla de "Control de Plazos (Semáforo)": calcula cuántos días
(hábiles según la LPAG, o calendario si se prefiere) han pasado desde la
fecha de ingreso de cada expediente, y muestra un semáforo de colores en
pantalla (verde/amarillo/rojo). Opcionalmente calcula la fecha de
vencimiento de un plazo legal en días hábiles.
"""

import os
import threading
from tkinter import filedialog, messagebox

import customtkinter as ctk

from services import excel_service, plazos_service, report_service, report_tdr_service
from services.dias_habiles_service import Calendario
from config.config_manager import obtener_ruta, guardar_config
from ui.feriados_dialog import FeriadosDialog
from utils.logger import registrar

COLOR_TEXTO = {
    "verde": "#1E7A34",
    "amarillo": "#B8860B",
    "rojo": "#B00020",
}
ETIQUETA_COLOR = {
    "verde": "🟢 VERDE",
    "amarillo": "🟡 AMARILLO",
    "rojo": "🔴 ROJO",
}


class PlazosView(ctk.CTkFrame):
    def __init__(self, master, config):
        super().__init__(master, fg_color="transparent")
        self.config_app = config
        self.ruta_excel = None
        self.ultimo_resultado = None

        self.columnconfigure(0, weight=1)
        self.rowconfigure(5, weight=1)

        titulo = ctk.CTkLabel(self, text="🚦 Control de Plazos", font=ctk.CTkFont(size=20, weight="bold"))
        titulo.grid(row=0, column=0, sticky="w", padx=20, pady=(20, 5))

        subtitulo = ctk.CTkLabel(
            self,
            text=(
                "Días desde la fecha de ingreso hasta hoy (el día de ingreso no cuenta). "
                "En días hábiles se descuentan sábados, domingos, feriados nacionales y los días "
                "no laborables que tengas activos. "
                "Verde: 0-7 días · Amarillo: 8-15 días · Rojo: más de 15 días. "
                "Un expediente ATENDIDO detiene el conteo."
            ),
            text_color="gray",
            wraplength=800,
            justify="left",
        )
        subtitulo.grid(row=1, column=0, sticky="w", padx=20, pady=(0, 10))

        fila_archivo = ctk.CTkFrame(self, fg_color="transparent")
        fila_archivo.grid(row=2, column=0, sticky="ew", padx=20)
        fila_archivo.columnconfigure(1, weight=1)

        ctk.CTkButton(fila_archivo, text="Seleccionar Excel", command=self._seleccionar_archivo).grid(
            row=0, column=0, padx=(0, 10)
        )
        self.etiqueta_archivo = ctk.CTkLabel(fila_archivo, text="Ningún archivo seleccionado", anchor="w")
        self.etiqueta_archivo.grid(row=0, column=1, sticky="ew")

        self.combo_hojas = ctk.CTkComboBox(fila_archivo, values=[], width=200)
        self.combo_hojas.grid(row=0, column=2, padx=10)

        self.boton_calcular = ctk.CTkButton(
            fila_archivo, text="Calcular plazos", command=self._calcular, state="disabled"
        )
        self.boton_calcular.grid(row=0, column=3, padx=(0, 0))

        fila_opciones = ctk.CTkFrame(self, fg_color="transparent")
        fila_opciones.grid(row=3, column=0, sticky="ew", padx=20, pady=(10, 0))

        self.selector_modo = ctk.CTkSegmentedButton(
            fila_opciones, values=["Días hábiles (LPAG)", "Días calendario"], command=self._al_cambiar_modo
        )
        modo_guardado = self.config_app.get("plazos_modo", "habiles")
        self.selector_modo.set("Días calendario" if modo_guardado == "calendario" else "Días hábiles (LPAG)")
        self.selector_modo.pack(side="left", padx=(0, 15))

        ctk.CTkLabel(fila_opciones, text="Plazo legal (días hábiles):").pack(side="left", padx=(0, 5))
        self.entrada_plazo_legal = ctk.CTkEntry(fila_opciones, width=55, placeholder_text="vacío = no")
        plazo_guardado = self.config_app.get("plazos_plazo_legal", 30)
        if plazo_guardado:
            self.entrada_plazo_legal.insert(0, str(plazo_guardado))
        self.entrada_plazo_legal.pack(side="left", padx=(0, 15))

        fila_opciones2 = ctk.CTkFrame(self, fg_color="transparent")
        fila_opciones2.grid(row=4, column=0, sticky="ew", padx=20, pady=(8, 0))
        self.var_no_laborables = ctk.BooleanVar(value=bool(self.config_app.get("plazos_descontar_no_laborables", True)))
        ctk.CTkCheckBox(
            fila_opciones2, text="Descontar días no laborables del sector público",
            variable=self.var_no_laborables,
        ).pack(side="left", padx=(0, 15))
        ctk.CTkButton(
            fila_opciones2, text="📅 Feriados y días no laborables…", width=230, command=self._abrir_feriados
        ).pack(side="left")

        self.marco_scroll = ctk.CTkScrollableFrame(self)
        self.marco_scroll.grid(row=5, column=0, sticky="nsew", padx=20, pady=15)
        self._mostrar_mensaje_vacio("Selecciona un Excel con las columnas EXPEDIENTE (opcional), DNI, "
                                     "NOMBRE, FECHA_INGRESO y ESTADO, y presiona \"Calcular plazos\".")

        fila_reportes = ctk.CTkFrame(self, fg_color="transparent")
        fila_reportes.grid(row=6, column=0, sticky="ew", padx=20, pady=(0, 20))
        ctk.CTkButton(fila_reportes, text="Generar reporte Excel", command=lambda: self._generar_reporte("xlsx")).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila_reportes, text="Generar reporte CSV", command=lambda: self._generar_reporte("csv")).pack(
            side="left", padx=(0, 10)
        )
        ctk.CTkButton(fila_reportes, text="📋 Reporte Mensual TDR (Entregables)", command=self._generar_reporte_tdr).pack(
            side="left"
        )

    def _mostrar_mensaje_vacio(self, texto):
        for widget in self.marco_scroll.winfo_children():
            widget.destroy()
        ctk.CTkLabel(self.marco_scroll, text=texto, justify="left", wraplength=800).pack(pady=20, padx=10, anchor="w")

    def _seleccionar_archivo(self):
        ruta = filedialog.askopenfilename(
            title="Selecciona un archivo Excel de expedientes",
            filetypes=[("Archivos Excel", "*.xlsx *.xlsm")],
        )
        if not ruta:
            return
        self.ruta_excel = ruta
        self.etiqueta_archivo.configure(text=os.path.basename(ruta))
        try:
            hojas = excel_service.listar_hojas(ruta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo abrir el archivo:\n{error}")
            return
        self.combo_hojas.configure(values=hojas)
        if hojas:
            self.combo_hojas.set(hojas[0])
        self.boton_calcular.configure(state="normal")

    def _modo_actual(self) -> str:
        return "calendario" if self.selector_modo.get() == "Días calendario" else "habiles"

    def _al_cambiar_modo(self, _valor=None):
        # Si ya hay resultados en pantalla, recalcula para que la tabla cambie al instante.
        if self.ruta_excel and self.ultimo_resultado:
            self._calcular()

    def _abrir_feriados(self):
        FeriadosDialog(self.winfo_toplevel(), al_guardar=self._al_cambiar_modo)

    def _leer_plazo_legal(self):
        """Devuelve (valor, ok). valor=None si el campo está vacío; ok=False si no es un número."""
        texto = self.entrada_plazo_legal.get().strip()
        if not texto:
            return None, True
        if texto.isdigit() and int(texto) > 0:
            return int(texto), True
        return None, False

    def _calcular(self):
        if not self.ruta_excel:
            return
        plazo_legal, ok = self._leer_plazo_legal()
        if not ok:
            messagebox.showwarning("Aviso", "El plazo legal debe ser un número de días (ejemplo: 30), o déjalo vacío.")
            return
        hoja = self.combo_hojas.get()
        modo = self._modo_actual()
        descontar_nl = bool(self.var_no_laborables.get())

        # Recuerda las opciones para la próxima vez
        self.config_app["plazos_modo"] = modo
        self.config_app["plazos_plazo_legal"] = plazo_legal or 0
        self.config_app["plazos_descontar_no_laborables"] = descontar_nl
        try:
            guardar_config(self.config_app)
        except OSError:
            pass

        self.boton_calcular.configure(state="disabled", text="Calculando...")

        def tarea():
            try:
                calendario = Calendario(incluir_no_laborables=descontar_nl)
                resultado = plazos_service.calcular_plazos(
                    self.ruta_excel, hoja, modo=modo, plazo_legal=plazo_legal, calendario=calendario
                )
            except Exception as error:
                resultado = {"error": f"No se pudo calcular: {error}"}
            self.after(0, lambda: self._mostrar_resultado(resultado))

        threading.Thread(target=tarea, daemon=True).start()

    def _mostrar_resultado(self, resultado):
        self.boton_calcular.configure(state="normal", text="Calcular plazos")
        self.ultimo_resultado = resultado

        for widget in self.marco_scroll.winfo_children():
            widget.destroy()

        if "error" in resultado:
            ctk.CTkLabel(self.marco_scroll, text=f"⚠ {resultado['error']}", text_color="#B00020",
                         wraplength=800, justify="left").pack(pady=20, padx=10, anchor="w")
            return

        filas = resultado["filas"]
        if not filas:
            self._mostrar_mensaje_vacio("El Excel no tiene filas con datos.")
            return

        encabezado = ctk.CTkFrame(self.marco_scroll, fg_color="transparent")
        encabezado.pack(fill="x", pady=(0, 5))
        etiqueta_dias = "Días háb." if resultado.get("modo") == "habiles" else "Días cal."
        con_plazo = bool(resultado.get("plazo_legal"))
        columnas = [("Expediente", 90), ("DNI", 80), ("Nombre", 140), ("Ingreso", 80),
                    ("Estado", 85), (etiqueta_dias, 62)]
        if con_plazo:
            columnas += [("Vence", 80), ("Restan", 55)]
        columnas.append(("Semáforo", 125))
        for texto, ancho in columnas:
            ctk.CTkLabel(encabezado, text=texto, width=ancho, anchor="w",
                         font=ctk.CTkFont(weight="bold")).pack(side="left", padx=2)

        for fila in filas:
            marco_fila = ctk.CTkFrame(self.marco_scroll, fg_color="transparent")
            marco_fila.pack(fill="x", pady=1)

            fecha_ingreso = fila["fecha_ingreso"]
            if hasattr(fecha_ingreso, "strftime"):
                fecha_ingreso = fecha_ingreso.strftime("%d/%m/%Y")
            valores = [
                (str(fila["expediente"] or "—"), 90),
                (str(fila["dni"] or "—"), 80),
                (str(fila["nombre"] or "—"), 140),
                (str(fecha_ingreso or "—"), 80),
                (str(fila["estado"] or "—"), 85),
                (str(fila["dias_transcurridos"] if fila["dias_transcurridos"] is not None else "—"), 62),
            ]
            for valor, ancho in valores:
                ctk.CTkLabel(marco_fila, text=valor, width=ancho, anchor="w").pack(side="left", padx=2)

            if con_plazo:
                ctk.CTkLabel(marco_fila, text=fila.get("fecha_vencimiento") or "—", width=80,
                             anchor="w").pack(side="left", padx=2)
                restantes = fila.get("dias_restantes")
                ctk.CTkLabel(
                    marco_fila, text="—" if restantes is None else str(restantes), width=55, anchor="w",
                    text_color=COLOR_TEXTO["rojo"] if (restantes is not None and restantes < 0) else None,
                    font=ctk.CTkFont(weight="bold") if (restantes is not None and restantes < 0) else None,
                ).pack(side="left", padx=2)

            color = fila["color"]
            if color:
                ctk.CTkLabel(
                    marco_fila, text=ETIQUETA_COLOR[color], width=125, anchor="w",
                    text_color=COLOR_TEXTO[color], font=ctk.CTkFont(weight="bold"),
                ).pack(side="left", padx=2)
            else:
                ctk.CTkLabel(marco_fila, text=fila["observacion"] or "—", width=125, anchor="w",
                             text_color="gray", wraplength=150, justify="left").pack(side="left", padx=2)

        conteo = {"verde": 0, "amarillo": 0, "rojo": 0}
        for fila in filas:
            if fila["color"]:
                conteo[fila["color"]] += 1
        registrar(
            f"Calculó plazos de {os.path.basename(self.ruta_excel)}: "
            f"{conteo['verde']} verde(s), {conteo['amarillo']} amarillo(s), {conteo['rojo']} rojo(s)"
        )

    def _generar_reporte(self, formato):
        if not self.ultimo_resultado or "error" in self.ultimo_resultado:
            messagebox.showwarning("Aviso", "Primero calcula los plazos para poder generar el reporte.")
            return

        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        try:
            if formato == "xlsx":
                ruta = report_service.generar_reporte_plazos_excel(self.ultimo_resultado["filas"], carpeta)
            else:
                ruta = report_service.generar_reporte_plazos_csv(self.ultimo_resultado["filas"], carpeta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el reporte:\n{error}")
            return

        registrar(f"Generó reporte de plazos {formato.upper()}: {ruta}")
        messagebox.showinfo("Reporte generado", f"Reporte guardado en:\n{ruta}")

    def _generar_reporte_tdr(self):
        if not self.ultimo_resultado or "error" in self.ultimo_resultado:
            messagebox.showwarning("Aviso", "Primero calcula los plazos para obtener el listado de entregables.")
            return

        carpeta = obtener_ruta(self.config_app, "carpeta_reportes", "reports")
        try:
            ruta = report_tdr_service.generar_reporte_mensual_tdr(self.ultimo_resultado["filas"], carpeta)
        except Exception as error:
            messagebox.showerror("Error", f"No se pudo generar el reporte TDR:\n{error}")
            return

        registrar(f"Generó Reporte Mensual TDR (Entregables): {ruta}")
        messagebox.showinfo("Reporte TDR Generado", f"Reporte de Entregables Atendidos guardado en:\n{ruta}")

