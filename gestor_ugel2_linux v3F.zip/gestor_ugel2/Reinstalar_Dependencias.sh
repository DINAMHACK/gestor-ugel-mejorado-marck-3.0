#!/usr/bin/env bash
# Reinstalar_Dependencias.sh
# --------------------------
# Borra el entorno del programa (.venv) y lo vuelve a crear desde cero.
# Úsalo solo si algo quedó mal instalado. Funciona con doble clic: los
# mensajes salen en ventanas (no hace falta terminal). Necesita internet.

cd "$(dirname "$(readlink -f "$0")")" || exit 1
TITULO="Gestor Documental UGEL"
mkdir -p temp
LOG="temp/reinstalar.log"
: > "$LOG"

tiene_ventanas() { [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && command -v zenity >/dev/null 2>&1; }
aviso() {   # $1 = tipo (info|error)  $2 = mensaje
    echo "$2"
    if tiene_ventanas; then zenity "--$1" --no-markup --title="$TITULO" --width=460 --text="$2" 2>/dev/null; fi
}
confirmar() {
    if tiene_ventanas; then zenity --question --no-markup --title="$TITULO" --width=460 --text="$1" 2>/dev/null; return $?; fi
    read -r -p "$1 Escribe SI para continuar: " r; [ "$r" = "SI" ] || [ "$r" = "si" ]
}

if ! confirmar "Esto borrará el entorno actual del programa y lo instalará de nuevo desde cero (necesita internet y puede tardar varios minutos). Tus archivos, reportes y datos NO se borran. ¿Continuar?"; then
    aviso info "Cancelado. No se hizo ningún cambio."
    exit 0
fi

command -v python3 >/dev/null 2>&1 || { aviso error "No se encontró Python 3. Instálalo desde el Gestor de software (busca \"python3\")."; exit 1; }
if [ "$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 10) else 0)')" != "1" ]; then
    aviso error "Se requiere Python 3.10 o superior. Usa Linux Mint 21 o más reciente."
    exit 1
fi
python3 -c "import tkinter, venv, ensurepip" >/dev/null 2>&1 || {
    aviso error "Falta un componente de Linux (python3-tk / python3-venv). Ábrelo con Iniciar_GestorUGEL.sh, que ofrece instalarlo, o instálalo desde el Gestor de software."
    exit 1
}

rm -rf ".venv"
python3 -m venv .venv >>"$LOG" 2>&1 || { aviso error "No se pudo crear el entorno. Detalle en $LOG"; exit 1; }
# shellcheck disable=SC1091
source ".venv/bin/activate"
python -m pip install --upgrade pip >>"$LOG" 2>&1

if tiene_ventanas; then
    ( pip install -r requirements.txt 2>&1 | tee -a "$LOG" | while IFS= read -r linea; do echo "# ${linea:0:70}"; done ) \
        | zenity --progress --pulsate --auto-close --no-cancel --title="$TITULO" --width=460 --text="Instalando librerías..." 2>/dev/null
    python -c "import customtkinter, openpyxl, pymupdf, pdfplumber, pdf2docx, cv2, numpy" >>"$LOG" 2>&1
    ESTADO=$?
else
    pip install -r requirements.txt >>"$LOG" 2>&1
    ESTADO=$?
fi

if [ "$ESTADO" -ne 0 ]; then
    rm -rf ".venv"
    aviso error "No se pudieron instalar las librerías. Revisa tu conexión a internet e inténtalo de nuevo. Detalle en: $LOG"
    exit 1
fi
sha256sum requirements.txt | cut -d" " -f1 > ".venv/instalado.ok"
aviso info "Listo. Ya puedes abrir el programa con su icono o con Iniciar_GestorUGEL.sh."
