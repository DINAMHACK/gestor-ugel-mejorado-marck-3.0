"""
file_service.py
----------------
Gestión de archivos dentro de una carpeta de trabajo: listar, detectar
duplicados reales (por contenido, no solo por nombre), renombrar según
una correspondencia que tú proporcionas, organizar por tipo y buscar
por nombre.

El programa nunca "adivina" a qué DNI o docente corresponde un archivo:
solo aplica la correspondencia (nombre_actual -> nombre_nuevo) que tú
entregues explícitamente.
"""

import os
import shutil
from utils.helpers import calcular_hash_archivo, tamano_legible, nombre_archivo_seguro

EXTENSIONES_PDF = {".pdf"}
EXTENSIONES_IMAGEN = {".jpg", ".jpeg", ".png", ".bmp", ".tiff", ".gif"}


def listar_carpeta(carpeta: str) -> list:
    """
    Lista los archivos de una carpeta con su tipo, tamaño y extensión.
    No entra en subcarpetas.
    """
    resultado = []
    if not os.path.isdir(carpeta):
        return resultado

    for nombre in sorted(os.listdir(carpeta)):
        ruta = os.path.join(carpeta, nombre)
        if not os.path.isfile(ruta):
            continue
        _, ext = os.path.splitext(nombre)
        ext = ext.lower()
        if ext in EXTENSIONES_PDF:
            tipo = "PDF"
        elif ext in EXTENSIONES_IMAGEN:
            tipo = "Imagen"
        else:
            tipo = "Otro"
        tamano_bytes = os.path.getsize(ruta)
        resultado.append({
            "nombre": nombre,
            "ruta": ruta,
            "extension": ext,
            "tipo": tipo,
            "tamano_bytes": tamano_bytes,
            "tamano_legible": tamano_legible(tamano_bytes),
        })
    return resultado


def detectar_duplicados(carpeta: str) -> list:
    """
    Agrupa archivos que tienen exactamente el mismo contenido (mismo hash),
    sin importar el nombre.
    """
    archivos = listar_carpeta(carpeta)
    por_hash = {}
    for archivo in archivos:
        try:
            h = calcular_hash_archivo(archivo["ruta"])
        except OSError:
            continue
        por_hash.setdefault(h, []).append(archivo["nombre"])

    return [
        {"hash": h, "archivos": nombres}
        for h, nombres in por_hash.items()
        if len(nombres) > 1
    ]


def detectar_nombres_problematicos(carpeta: str) -> list:
    """Marca archivos con nombres genéricos o con caracteres poco recomendables."""
    problemas = []
    caracteres_raros = set('<>:"/\\|?*')
    for archivo in listar_carpeta(carpeta):
        nombre = archivo["nombre"]
        motivos = []
        base, _ = os.path.splitext(nombre)
        if base.lower().startswith(("scan", "documento", "imagen", "img", "sin titulo", "sin_titulo")):
            motivos.append("nombre genérico (no identifica el documento)")
        if any(c in nombre for c in caracteres_raros):
            motivos.append("contiene caracteres no recomendados")
        if " " in nombre:
            motivos.append("contiene espacios")
        if motivos:
            problemas.append({"nombre": nombre, "motivos": motivos})
    return problemas


def renombrar_archivos(carpeta: str, correspondencia: dict) -> list:
    """
    Renombra archivos según una correspondencia explícita
    {"nombre_actual.pdf": "nuevo_nombre.pdf", ...} proporcionada por ti.
    Devuelve la lista de operaciones realizadas (o el error si alguna falla).
    """
    resultados = []
    for nombre_actual, nombre_nuevo in correspondencia.items():
        ruta_actual = os.path.join(carpeta, nombre_actual)
        nombre_nuevo_seguro = nombre_archivo_seguro(nombre_nuevo)
        ruta_nueva = os.path.join(carpeta, nombre_nuevo_seguro)

        if not os.path.isfile(ruta_actual):
            resultados.append({"origen": nombre_actual, "ok": False, "detalle": "No existe"})
            continue
        if os.path.exists(ruta_nueva):
            resultados.append({"origen": nombre_actual, "ok": False, "detalle": "Ya existe un archivo con ese nombre"})
            continue

        os.rename(ruta_actual, ruta_nueva)
        resultados.append({"origen": nombre_actual, "ok": True, "detalle": nombre_nuevo_seguro})
    return resultados


def organizar_por_tipo(carpeta: str) -> dict:
    """
    Mueve los archivos a subcarpetas PDF/, Imagenes/ y Otros/ dentro de la
    misma carpeta de trabajo. Devuelve cuántos archivos se movieron a cada una.
    """
    subcarpetas = {"PDF": "PDF", "Imagen": "Imagenes", "Otro": "Otros"}
    contador = {"PDF": 0, "Imagen": 0, "Otro": 0}

    for archivo in listar_carpeta(carpeta):
        destino_carpeta = os.path.join(carpeta, subcarpetas[archivo["tipo"]])
        os.makedirs(destino_carpeta, exist_ok=True)
        destino_ruta = os.path.join(destino_carpeta, archivo["nombre"])
        if not os.path.exists(destino_ruta):
            shutil.move(archivo["ruta"], destino_ruta)
            contador[archivo["tipo"]] += 1

    return contador


def buscar_por_nombre(carpeta: str, texto: str) -> list:
    """Busca archivos cuyo nombre contenga el texto indicado (sin distinguir mayúsculas)."""
    texto = texto.lower()
    return [a for a in listar_carpeta(carpeta) if texto in a["nombre"].lower()]
