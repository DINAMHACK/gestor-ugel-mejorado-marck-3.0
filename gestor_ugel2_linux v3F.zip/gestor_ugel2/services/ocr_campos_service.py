"""
ocr_campos_service.py
----------------------
Busca datos clave dentro de un texto (digital o leído por OCR):
DNI, fechas, número de resolución, expediente y códigos patrimoniales.

Tolera los errores típicos del OCR:
  - "N°" leído como "N?", "N*", "No", "N."
  - "DNI" leído como "D.N.L", "ONI", "DN1"
  - letras en lugar de números dentro de un DNI que tiene etiqueta
    ("1671234S" -> 16712345, "O2345678" -> 02345678)

Diferencia dos niveles de seguridad para el DNI:
  - CONFIRMADO: 8 dígitos justo después de una etiqueta (DNI, L.E....).
  - POSIBLE: cualquier otro número suelto de 8 dígitos.
"""

import re
from datetime import date

CONFUSION_DIGITOS = str.maketrans({
    "O": "0", "o": "0", "Q": "0", "D": "0",
    "I": "1", "l": "1", "|": "1", "i": "1", "!": "1",
    "Z": "2", "z": "2", "S": "5", "s": "5", "B": "8", "b": "6", "G": "6",
})

_ETIQUETA_DNI = (
    r"(?<![A-Za-z])(?:D\s?\.?\s?N\s?\.?\s?[I1Ll|]\s?\.?|O\s?N\s?I|DN1|"
    r"doc(?:umento)?\.?\s*(?:nacional\s+)?(?:de\s+)?identidad|L\.?\s?E\.?|libreta\s+electoral)"
)
_SIMBOLO_NUMERO = r"(?:N\s*[°º?*˚.o0]{0,2}\s*)?"
PATRON_DNI_ETIQUETADO = re.compile(
    _ETIQUETA_DNI + r"\s*[:\-.]?\s*" + _SIMBOLO_NUMERO + r"[:\-.]?\s*([0-9OoQDIl|iSsBbGZz]{8})(?![0-9A-Za-z])",
    re.IGNORECASE,
)
PATRON_NUMERO_8 = re.compile(r"(?<![\d\-/.])\d{8}(?![\d\-/.]*\d)")

MESES = {"enero": 1, "febrero": 2, "marzo": 3, "abril": 4, "mayo": 5, "junio": 6, "julio": 7,
         "agosto": 8, "setiembre": 9, "septiembre": 9, "octubre": 10, "noviembre": 11, "diciembre": 12}
PATRON_FECHA_NUM = re.compile(r"(?<!\d)(\d{1,2})\s?[/\-.]\s?(\d{1,2})\s?[/\-.]\s?(\d{4})(?!\d)")
PATRON_FECHA_TEXTO = re.compile(
    r"(?<!\d)(\d{1,2})\s+de\s+(" + "|".join(MESES) + r")\s+(?:del?\s+)?(\d{4})", re.IGNORECASE)

PATRON_RESOLUCION = re.compile(
    r"(?i)(?:resoluci[óo]n\s+(?:(?:sub)?director[ao]l|ejecutiva|jefatural|gerencial|administrativa|"
    r"de\s+alcald[ií]a|regional)?\s*(?:regional\s+)?(?:sectorial\s+)?|\bR\.?\s?D\.?\s*)"
    r"N\s*[°º?*˚.o]{0,2}\s*[:\-]?\s*(\d{1,7}(?:\s?[\-/]\s?[A-Za-z0-9ÁÉÍÓÚÑ.]+)*)"
)
PATRON_EXPEDIENTE = re.compile(
    r"(?i)expediente\s*(?:N\s*[°º?*˚.o]{0,2})?\s*[:\-]?\s*([0-9][A-Za-z0-9\-/.]{2,24})")
PATRON_PATRIMONIAL = re.compile(r"(?<![\d])(\d{4}[\s\-]?\d{4}[\s\-]?\d{4})(?![\d])")


def _unico(lista):
    return list(dict.fromkeys(lista))


def buscar_dnis(texto: str) -> dict:
    """Devuelve {"confirmados": [...], "posibles": [...]} (8 dígitos cada uno)."""
    confirmados = []
    for m in PATRON_DNI_ETIQUETADO.finditer(texto):
        candidato = m.group(1).translate(CONFUSION_DIGITOS)
        if candidato.isdigit() and len(candidato) == 8:
            confirmados.append(candidato)
    confirmados = _unico(confirmados)
    posibles = [n for n in _unico(PATRON_NUMERO_8.findall(texto)) if n not in confirmados]
    return {"confirmados": confirmados, "posibles": posibles}


def buscar_fechas(texto: str) -> list:
    """Fechas válidas como dd/mm/aaaa (descarta las imposibles, típicas de errores del OCR)."""
    hallazgos = []

    def _agregar(d, m, a):
        try:
            if 1900 <= a <= 2100:
                hallazgos.append(date(a, m, d).strftime("%d/%m/%Y"))
        except ValueError:
            pass

    for m in PATRON_FECHA_NUM.finditer(texto):
        _agregar(int(m.group(1)), int(m.group(2)), int(m.group(3)))
    for m in PATRON_FECHA_TEXTO.finditer(texto):
        _agregar(int(m.group(1)), MESES[m.group(2).lower()], int(m.group(3)))
    return _unico(hallazgos)


def buscar_resoluciones(texto: str) -> list:
    resultado = []
    for m in PATRON_RESOLUCION.finditer(texto):
        numero = re.sub(r"\s*([\-/])\s*", r"\1", m.group(1)).strip(" .-/")
        resultado.append(numero)
    return _unico(resultado)


def buscar_expedientes(texto: str) -> list:
    return _unico([m.group(1).strip(".-/") for m in PATRON_EXPEDIENTE.finditer(texto)])


def buscar_codigos_patrimoniales(texto: str) -> list:
    codigos = []
    for m in PATRON_PATRIMONIAL.finditer(texto):
        codigos.append(re.sub(r"\D", "", m.group(1)))
    return _unico(codigos)


def extraer_campos(texto: str) -> dict:
    """Todos los campos de un texto. Las claves son listas de strings."""
    dnis = buscar_dnis(texto)
    return {
        "resoluciones": buscar_resoluciones(texto),
        "expedientes": buscar_expedientes(texto),
        "dnis_confirmados": dnis["confirmados"],
        "dnis_posibles": dnis["posibles"],
        "fechas": buscar_fechas(texto),
        "codigos_patrimoniales": buscar_codigos_patrimoniales(texto),
    }
