"""
pdf_rename_from_excel_service.py
----------------------------------
Genera una PROPUESTA de nombres para los PDFs de una carpeta, a partir
de las filas de un Excel (DNI, DOCUMENTO, FECHA), emparejando por orden
(fila 1 del Excel <-> primer PDF de la carpeta, fila 2 <-> segundo PDF...).

Importante: esto NUNCA renombra nada por sí solo. Solo arma una lista de
propuestas para que TÚ la revises, quites lo que no corresponda y recién
entonces confirmes. El emparejamiento por orden solo tiene sentido si
escaneaste los documentos en el mismo orden que las filas del Excel —
por eso la vista previa es obligatoria antes de aplicar cualquier cambio.
"""

import os
import openpyxl
from utils.helpers import nombre_archivo_seguro

COLUMNAS_CLAVE = {
    "DNI": "dni",
    "NOMBRE": "nombre",
    "DOCUMENTO": "documento",
    "FECHA": "fecha",
}


def _detectar_columnas(hoja) -> dict:
    columnas = {}
    primera_fila = next(hoja.iter_rows(min_row=1, max_row=1), [])
    for celda in primera_fila:
        if celda.value is None:
            continue
        texto = str(celda.value).strip().upper()
        if texto in COLUMNAS_CLAVE:
            columnas[COLUMNAS_CLAVE[texto]] = celda.column - 1
    return columnas


def _listar_pdfs_ordenados(carpeta: str) -> list:
    if not os.path.isdir(carpeta):
        return []
    nombres = [n for n in os.listdir(carpeta) if n.lower().endswith(".pdf")]
    return sorted(nombres)


def generar_propuesta(ruta_excel: str, hoja: str, carpeta_pdfs: str) -> dict:
    """
    Empareja, EN ORDEN, las filas del Excel con los PDFs de la carpeta
    (ambos ordenados: filas de arriba hacia abajo, PDFs por nombre).

    Devuelve un diccionario con:
      - "propuestas": lista de {pdf_actual, dni, nombre, documento, fecha,
        nombre_propuesto, incluir}
      - "aviso": texto si la cantidad de PDFs y de filas no coincide
                 (en ese caso, igual arma la propuesta hasta donde alcance,
                 pero avisa para que revises con más cuidado)
    """
    libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    hoja_activa = libro[hoja]
    columnas = _detectar_columnas(hoja_activa)
    faltantes = [c for c in ("dni", "documento") if c not in columnas]
    if faltantes:
        libro.close()
        return {"error": f"Faltan columnas obligatorias en el Excel: {', '.join(faltantes).upper()}"}

    filas = []
    for fila in hoja_activa.iter_rows(min_row=2, values_only=True):
        if fila is None or all(v is None for v in fila):
            continue
        filas.append(fila)
    libro.close()

    pdfs = _listar_pdfs_ordenados(carpeta_pdfs)

    aviso = None
    if len(pdfs) != len(filas):
        aviso = (
            f"El Excel tiene {len(filas)} fila(s) y la carpeta tiene {len(pdfs)} PDF(s). "
            "No coinciden en cantidad: revisa con cuidado cada emparejamiento antes de aplicar, "
            "o quita de la lista los que no correspondan."
        )

    total = min(len(pdfs), len(filas))
    propuestas = []
    for i in range(total):
        fila = filas[i]

        def obtener(campo):
            idx = columnas.get(campo)
            if idx is None or idx >= len(fila):
                return None
            return fila[idx]

        dni = obtener("dni")
        documento = obtener("documento")
        fecha = obtener("fecha")

        partes = [str(p).strip() for p in (dni, documento) if p not in (None, "")]
        if fecha not in (None, ""):
            partes.append(str(fecha).strip().replace("/", "-"))
        nombre_propuesto = nombre_archivo_seguro("_".join(partes).upper() + ".pdf") if partes else None

        propuestas.append({
            "pdf_actual": pdfs[i],
            "dni": dni,
            "documento": documento,
            "fecha": fecha,
            "nombre_propuesto": nombre_propuesto,
            "incluir": nombre_propuesto is not None,
        })

    return {"propuestas": propuestas, "aviso": aviso}


def aplicar_renombrado(carpeta_pdfs: str, propuestas: list) -> list:
    """
    Aplica SOLO las propuestas marcadas con incluir=True, usando el
    nombre_propuesto (que pudo haber sido editado a mano antes de llegar
    aquí). Devuelve el resultado de cada operación.
    """
    resultados = []
    for propuesta in propuestas:
        if not propuesta.get("incluir"):
            continue

        nombre_nuevo = nombre_archivo_seguro(str(propuesta.get("nombre_propuesto") or "").strip())
        if not nombre_nuevo:
            resultados.append({
                "origen": propuesta["pdf_actual"], "ok": False, "detalle": "Nombre propuesto vacío",
            })
            continue

        ruta_actual = os.path.join(carpeta_pdfs, propuesta["pdf_actual"])
        ruta_nueva = os.path.join(carpeta_pdfs, nombre_nuevo)

        if not os.path.isfile(ruta_actual):
            resultados.append({"origen": propuesta["pdf_actual"], "ok": False, "detalle": "El archivo ya no existe"})
            continue
        if os.path.exists(ruta_nueva):
            resultados.append({
                "origen": propuesta["pdf_actual"], "ok": False,
                "detalle": f"Ya existe un archivo llamado {nombre_nuevo}",
            })
            continue

        os.rename(ruta_actual, ruta_nueva)
        resultados.append({"origen": propuesta["pdf_actual"], "ok": True, "detalle": nombre_nuevo})

    return resultados
