"""
validation_service.py
----------------------
Junta la validación del Excel con la revisión de la carpeta de archivos
(PDFs dañados, duplicados, nombres problemáticos) y arma un resumen único,
en el mismo formato que se pensó desde el diseño del programa:

    RESULTADO DE VALIDACIÓN
    Archivos analizados: N
    Correctos: N
    Observados: N
    <lista de problemas>
"""

from services import excel_service, file_service, pdf_service


def validar_lote(ruta_excel: str, hoja: str, carpeta_archivos: str,
                  tipos_validos: list, estados_validos: list) -> dict:
    resumen_excel = excel_service.validar_excel(ruta_excel, hoja, tipos_validos, estados_validos)
    if "error" in resumen_excel:
        return resumen_excel

    problemas = list(resumen_excel["problemas"])

    # Duplicados de archivo (contenido idéntico)
    duplicados_archivo = file_service.detectar_duplicados(carpeta_archivos)
    for grupo in duplicados_archivo:
        problemas.append({
            "fila": "—",
            "dni": "—",
            "errores": [f"Archivos duplicados: {', '.join(grupo['archivos'])}"],
        })

    # Nombres problemáticos
    nombres_problema = file_service.detectar_nombres_problematicos(carpeta_archivos)
    for item in nombres_problema:
        problemas.append({
            "fila": "—",
            "dni": "—",
            "errores": [f"Nombre de archivo observado ({item['nombre']}): {', '.join(item['motivos'])}"],
        })

    # PDFs ilegibles / corruptos
    archivos_pdf = [a for a in file_service.listar_carpeta(carpeta_archivos) if a["tipo"] == "PDF"]
    for archivo in archivos_pdf:
        info = pdf_service.info_pdf(archivo["ruta"])
        if not info["valido"]:
            problemas.append({
                "fila": "—",
                "dni": "—",
                "errores": [f"PDF ilegible o dañado: {archivo['nombre']}"],
            })
        elif info["paginas"] == 0:
            problemas.append({
                "fila": "—",
                "dni": "—",
                "errores": [f"PDF vacío (0 páginas): {archivo['nombre']}"],
            })

    total_analizados = resumen_excel["total"] + len(archivos_pdf)
    observados = len(problemas)
    correctos = max(total_analizados - observados, 0)

    return {
        "total": total_analizados,
        "correctos": correctos,
        "observados": observados,
        "problemas": problemas,
        "avisos": resumen_excel.get("avisos", []),
        "columnas_detectadas": resumen_excel.get("columnas_detectadas", {}),
    }


def formatear_resumen_texto(resumen: dict) -> str:
    """Da el formato de bloque de texto pensado desde el inicio del proyecto."""
    if "error" in resumen:
        return f"No se pudo validar: {resumen['error']}"

    linea = "═" * 36
    partes = [
        linea,
        "       RESULTADO DE VALIDACIÓN".center(36),
        linea,
        "",
        f"Archivos/registros analizados: {resumen['total']}",
        "",
        f"✓ Correctos:   {resumen['correctos']}",
        f"⚠ Observados:  {resumen['observados']}",
        "",
    ]
    if resumen["problemas"]:
        partes.append("Problemas:")
        for problema in resumen["problemas"]:
            detalle = "; ".join(problema["errores"])
            partes.append(f"Fila {problema['fila']} (DNI {problema['dni']}) → {detalle}")
    if resumen.get("avisos"):
        partes.append("")
        partes.append("Avisos (no son errores, pero conviene revisarlos):")
        for aviso in resumen["avisos"]:
            partes.append(f"Fila {aviso['fila']} (DNI {aviso['dni']}) → {aviso['aviso']}")
    partes.append(linea)
    return "\n".join(partes)
