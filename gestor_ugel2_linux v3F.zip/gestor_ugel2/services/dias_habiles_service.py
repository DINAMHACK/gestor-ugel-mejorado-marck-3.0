"""
dias_habiles_service.py
------------------------
Cálculo de DÍAS HÁBILES para plazos administrativos (LPAG).

Regla aplicada (TUO de la Ley 27444, artículo de cómputo de plazos):
los plazos en días son días hábiles consecutivos, excluyendo los días
no laborables del servicio y los feriados no laborables de orden
nacional o regional. En la práctica se descuentan:

  1. Sábados y domingos.
  2. Feriados nacionales (D. Leg. 713 y leyes posteriores).
  3. Días no laborables del sector público decretados por el Ejecutivo
     (por ejemplo, el viernes "puente"). Se pueden desactivar.
  4. Feriados regionales / locales (por ejemplo, Lambayeque). Solo se
     descuentan si la persona los marca como ACTIVOS en la pantalla
     "Feriados y días no laborables": son decretados por el Gobierno
     Regional o la Municipalidad y no se pueden asumir de antemano.

Feriados nacionales incluidos (16 desde 2024):
  1 ene · Jueves y Viernes Santo (móviles) · 1 may · 7 jun (desde 2024)
  · 29 jun · 23 jul (desde 2023) · 28 y 29 jul · 6 ago (desde 2022)
  · 30 ago · 8 oct · 1 nov · 8 dic · 9 dic (desde 2022) · 25 dic

Conteo: el día de ingreso NO cuenta; se cuenta desde el día siguiente
(el plazo corre a partir del día hábil siguiente a la presentación).

Los días no laborables y feriados locales se guardan en
datos/dias_no_laborables.json y se editan desde la aplicación.
"""

import json
import os
from datetime import date, timedelta

from utils.paths import carpeta_base

RUTA_DIAS = os.path.join(carpeta_base(), "datos", "dias_no_laborables.json")

TIPOS = {
    "no_laborable_sp": "No laborable (sector público)",
    "regional": "Feriado regional",
    "local": "Feriado local",
}

# (mes, dia, nombre, año desde el cual aplica)
_FERIADOS_FIJOS = [
    (1, 1, "Año Nuevo", 1900),
    (5, 1, "Día del Trabajo", 1900),
    (6, 7, "Batalla de Arica y Día de la Bandera", 2024),
    (6, 29, "San Pedro y San Pablo", 1900),
    (7, 23, "Día de la Fuerza Aérea del Perú", 2023),
    (7, 28, "Fiestas Patrias", 1900),
    (7, 29, "Fiestas Patrias", 1900),
    (8, 6, "Batalla de Junín", 2022),
    (8, 30, "Santa Rosa de Lima", 1900),
    (10, 8, "Combate de Angamos", 1900),
    (11, 1, "Todos los Santos", 1900),
    (12, 8, "Inmaculada Concepción", 1900),
    (12, 9, "Batalla de Ayacucho", 2022),
    (12, 25, "Navidad", 1900),
]

# Valores iniciales de los días editables. Los tres "no laborable" son
# días no laborables compensables del sector público ya decretados.
# El 27 de diciembre (proclamación de independencia de Lambayeque, 1820)
# es fecha cívica local: queda DESACTIVADO hasta que se confirme que la
# norma regional/municipal lo declara no laborable.
_DIAS_INICIALES = [
    {"fecha": "2025-05-02", "nombre": "Día no laborable (sector público)", "tipo": "no_laborable_sp", "activo": True},
    {"fecha": "2025-12-26", "nombre": "Día no laborable (sector público)", "tipo": "no_laborable_sp", "activo": True},
    {"fecha": "2026-01-02", "nombre": "Día no laborable (sector público)", "tipo": "no_laborable_sp", "activo": True},
    {"mes_dia": "12-27", "nombre": "Independencia de Lambayeque", "tipo": "local", "activo": False, "anual": True},
]


def pascua(anio: int) -> date:
    """Domingo de Pascua (algoritmo de Meeus/Jones/Butcher)."""
    a = anio % 19
    b, c = divmod(anio, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mes = (h + l - 7 * m + 114) // 31
    dia = ((h + l - 7 * m + 114) % 31) + 1
    return date(anio, mes, dia)


def feriados_nacionales(anio: int) -> dict:
    """Devuelve {fecha: nombre} con los feriados nacionales del año."""
    resultado = {}
    for mes, dia, nombre, desde in _FERIADOS_FIJOS:
        if anio >= desde:
            resultado[date(anio, mes, dia)] = nombre
    domingo = pascua(anio)
    resultado[domingo - timedelta(days=3)] = "Jueves Santo"
    resultado[domingo - timedelta(days=2)] = "Viernes Santo"
    return dict(sorted(resultado.items()))


# ---------------------------------------------------------------
# Días editables (no laborables del sector público, regionales, locales)
# ---------------------------------------------------------------
def cargar_dias_personalizados() -> list:
    """Lee datos/dias_no_laborables.json (lo crea con valores iniciales si no existe)."""
    if not os.path.exists(RUTA_DIAS):
        guardar_dias_personalizados(_DIAS_INICIALES)
        return [dict(d) for d in _DIAS_INICIALES]
    try:
        with open(RUTA_DIAS, "r", encoding="utf-8") as f:
            datos = json.load(f)
        if isinstance(datos, list):
            return datos
    except (OSError, json.JSONDecodeError):
        pass
    guardar_dias_personalizados(_DIAS_INICIALES)
    return [dict(d) for d in _DIAS_INICIALES]


def guardar_dias_personalizados(lista: list) -> None:
    os.makedirs(os.path.dirname(RUTA_DIAS), exist_ok=True)
    with open(RUTA_DIAS, "w", encoding="utf-8") as f:
        json.dump(lista, f, indent=2, ensure_ascii=False)


def _fecha_de_entrada(entrada: dict, anio: int):
    """Fecha concreta de una entrada para un año dado (o None si no corresponde)."""
    try:
        if entrada.get("anual") and entrada.get("mes_dia"):
            mes, dia = (int(x) for x in entrada["mes_dia"].split("-"))
            return date(anio, mes, dia)
        if entrada.get("fecha"):
            d = date.fromisoformat(entrada["fecha"])
            return d if d.year == anio else None
    except (ValueError, TypeError):
        return None
    return None


class Calendario:
    """
    Calendario laboral para contar días hábiles.

    incluir_no_laborables: descuenta los días no laborables del sector
        público activos (recomendado: la LPAG excluye los "no
        laborables del servicio").
    incluir_locales: descuenta los feriados regionales/locales ACTIVOS.
    """

    def __init__(self, incluir_no_laborables: bool = True, incluir_locales: bool = True,
                 dias_personalizados: list = None):
        self.incluir_no_laborables = incluir_no_laborables
        self.incluir_locales = incluir_locales
        self._personalizados = (
            dias_personalizados if dias_personalizados is not None else cargar_dias_personalizados()
        )
        self._cache = {}

    def _inhabiles_del_anio(self, anio: int) -> dict:
        if anio in self._cache:
            return self._cache[anio]
        dias = dict(feriados_nacionales(anio))
        for entrada in self._personalizados:
            if not entrada.get("activo", True):
                continue
            tipo = entrada.get("tipo", "local")
            if tipo == "no_laborable_sp" and not self.incluir_no_laborables:
                continue
            if tipo in ("regional", "local") and not self.incluir_locales:
                continue
            fecha = _fecha_de_entrada(entrada, anio)
            if fecha:
                dias.setdefault(fecha, entrada.get("nombre", "Día no laborable"))
        self._cache[anio] = dias
        return dias

    def motivo_inhabil(self, d: date):
        """Texto del motivo por el que el día no es hábil, o None si es hábil."""
        if d.weekday() == 5:
            return "Sábado"
        if d.weekday() == 6:
            return "Domingo"
        return self._inhabiles_del_anio(d.year).get(d)

    def es_habil(self, d: date) -> bool:
        return self.motivo_inhabil(d) is None

    def contar_habiles(self, desde: date, hasta: date) -> int:
        """Días hábiles entre dos fechas: NO cuenta 'desde', SÍ cuenta 'hasta'."""
        if hasta <= desde:
            return 0
        total = 0
        actual = desde + timedelta(days=1)
        while actual <= hasta:
            if self.es_habil(actual):
                total += 1
            actual += timedelta(days=1)
        return total

    def sumar_habiles(self, desde: date, cantidad: int) -> date:
        """Fecha en que vence un plazo de 'cantidad' días hábiles contados desde 'desde'."""
        actual = desde
        restantes = cantidad
        while restantes > 0:
            actual += timedelta(days=1)
            if self.es_habil(actual):
                restantes -= 1
        return actual

    def restar_habiles_entre(self, hoy: date, vencimiento: date) -> int:
        """Días hábiles que faltan para el vencimiento (negativo = ya venció)."""
        if vencimiento >= hoy:
            return self.contar_habiles(hoy, vencimiento)
        return -self.contar_habiles(vencimiento, hoy)
