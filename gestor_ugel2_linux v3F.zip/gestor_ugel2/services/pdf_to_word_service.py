"""
pdf_to_word_service.py
------------------------
Convierte un PDF a un documento Word (.docx) editable, usando pdf2docx.

Funciona muy bien cuando el PDF tiene texto real (por ejemplo, generado
desde Word, un sistema, o cualquier programa que no sea un escáner).

Si el PDF es un escaneo (una imagen dentro del PDF, sin texto real),
el resultado NO tendrá texto editable: solo se incrustará la imagen tal
cual, porque no existe texto que extraer. Para esos casos hace falta
OCR (reconocimiento óptico de caracteres), que es una función distinta.
"""

import pymupdf as fitz  # pymupdf (nombre de import recomendado), solo para revisar si el PDF tiene texto real
from pdf2docx import Converter


def pdf_probablemente_es_escaneado(ruta_pdf: str, paginas_a_revisar: int = 3) -> bool:
    """
    Revisa si el PDF tiene texto real extraíble. Si ninguna de las
    primeras páginas tiene texto, es casi seguro que es un escaneo
    (una imagen), y advertimos antes de convertir.
    """
    with fitz.open(ruta_pdf) as doc:
        paginas = min(len(doc), paginas_a_revisar)
        for i in range(paginas):
            texto = doc[i].get_text().strip()
            if texto:
                return False
    return True


def convertir_pdf_a_word(ruta_pdf: str, ruta_salida_docx: str,
                          pagina_inicio: int = None, pagina_fin: int = None) -> str:
    """
    Convierte el PDF (o un rango de páginas) a un .docx editable.
    pagina_inicio/pagina_fin usan numeración desde 1 (inclusive). Si se
    dejan en None, convierte el documento completo.
    """
    inicio = (pagina_inicio - 1) if pagina_inicio else 0
    fin = (pagina_fin - 1) if pagina_fin else None

    convertidor = Converter(ruta_pdf)
    try:
        convertidor.convert(ruta_salida_docx, start=inicio, end=fin)
    finally:
        convertidor.close()

    return ruta_salida_docx


def convertir_escaneado_a_word(ruta_archivo: str, ruta_salida_docx: str, progreso=None, cancelar=None) -> dict:
    """
    Convierte un PDF ESCANEADO o una foto (PNG/JPG/TIF) a un Word editable
    usando OCR. Solo recupera el TEXTO (párrafos); no reproduce el diseño
    de la página, los logos ni las tablas. Las páginas que ya tenían texto
    digital se pasan tal cual.

    Devuelve {"ruta_salida", "paginas", "confianza_media"}.
    """
    from docx import Document
    from docx.shared import Pt
    from services import ocr_service

    lectura = ocr_service.leer_archivo(ruta_archivo, progreso=progreso, cancelar=cancelar)
    if lectura.get("error"):
        raise RuntimeError(lectura["error"])

    documento = Document()
    estilo = documento.styles["Normal"]
    estilo.font.name = "Arial"
    estilo.font.size = Pt(11)

    for indice, pagina in enumerate(lectura["paginas"]):
        if indice > 0:
            documento.add_page_break()
        texto = pagina["texto"].strip()
        if not texto:
            documento.add_paragraph("[Página sin texto legible]")
            continue
        for bloque in texto.split("\n\n"):
            if bloque.strip():
                documento.add_paragraph(bloque.strip())  # los saltos de línea del bloque se conservan

    documento.save(ruta_salida_docx)
    return {"ruta_salida": ruta_salida_docx, "paginas": len(lectura["paginas"]),
            "confianza_media": lectura["confianza_media"]}
