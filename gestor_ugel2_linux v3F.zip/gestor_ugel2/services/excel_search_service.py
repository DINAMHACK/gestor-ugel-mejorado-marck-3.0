"""
excel_search_service.py
------------------------
Búsqueda "Full Excel": en vez de guardar los registros en una base de
datos aparte, este módulo busca directamente dentro de los archivos
.xlsx que ya usas para tu control (los mismos que abre el resto de la
oficina). Así tu información sigue viviendo en Excel, pero la puedes
consultar en segundos en vez de abrir archivo por archivo a mano.

Incluye filtro por rango de años (llave compuesta DNI/texto + año),
pensado para el caso real de constancias de pago: un profesor que pide
varios años de historial puede aparecer decenas de veces (un registro
por mes), y filtrar solo por texto devolvería una lista enorme y
desordenada. Con el rango de años, la búsqueda trae solo lo que
corresponde al periodo solicitado, y ordenado cronológicamente.

No modifica ni guarda nada: solo lee.
"""

import os
from datetime import datetime

import openpyxl

from utils.helpers import limpiar_texto_oculto

COLUMNAS_CLAVE = {
    "DNI": "dni",
    "NOMBRE": "nombre",
    "NOMBRES": "nombre",
    "NOMBRES COMPLETOS": "nombre",
    "APELLIDOS Y NOMBRES": "nombre",
    "NOMBRES Y APELLIDOS": "nombre",
    "DOCUMENTO": "documento",
    "FECHA": "fecha",
    "FECHA_INGRESO": "fecha",
    "ESTADO": "estado",
}


def _detectar_columnas(hoja) -> dict:
    """Ubica en qué columna está cada campo clave, leyendo la primera fila."""
    columnas = {}
    primera_fila = next(hoja.iter_rows(min_row=1, max_row=1), [])
    for celda in primera_fila:
        if celda.value is None:
            continue
        texto = str(celda.value).strip().upper()
        if texto in COLUMNAS_CLAVE:
            # setdefault: si ya se encontró una columna para esta clave,
            # no la pisa (por ejemplo, si el Excel tuviera tanto NOMBRE
            # como NOMBRES COMPLETOS, se respeta la primera que aparezca).
            columnas.setdefault(COLUMNAS_CLAVE[texto], celda.column - 1)
    return columnas


def _listar_excels(carpeta: str) -> list:
    if not os.path.isdir(carpeta):
        return []
    return [
        os.path.join(carpeta, nombre)
        for nombre in os.listdir(carpeta)
        if nombre.lower().endswith((".xlsx", ".xlsm")) and not nombre.startswith("~$")
    ]


def _partes_fecha(valor):
    """
    Intenta extraer (año, mes, dia) de un valor de fecha, sea un objeto
    datetime real (lo más común en Excel) o texto en formato
    DD/MM/AAAA, DD-MM-AAAA o AAAA-MM-DD. Si no se puede interpretar,
    devuelve None (nunca inventa una fecha).
    """
    if valor is None:
        return None
    if isinstance(valor, datetime):
        return (valor.year, valor.month, valor.day)

    texto = str(valor).strip()
    formatos = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d")
    for formato in formatos:
        try:
            fecha = datetime.strptime(texto, formato)
            return (fecha.year, fecha.month, fecha.day)
        except ValueError:
            continue
    return None


def buscar_en_carpeta(carpeta: str, texto_buscado: str, anio_desde: int = None, anio_hasta: int = None) -> list:
    """
    Busca un DNI o texto en todos los Excel (.xlsx) de una carpeta.
    Revisa todas las hojas de cada archivo.

    Si se indica anio_desde y/o anio_hasta, además del texto, solo
    devuelve filas cuya columna FECHA caiga dentro de ese rango
    (ambos límites inclusive). Si una fila no tiene una fecha
    reconocible, se excluye cuando hay filtro de año activo (para no
    mezclar fechas sin verificar con el rango que se pidió).

    Los resultados se devuelven ordenados cronológicamente cuando la
    fecha se pudo interpretar; los que no tienen fecha reconocible van
    al final, en el orden en que se encontraron.
    """
    texto_buscado = limpiar_texto_oculto(texto_buscado).lower()
    hay_filtro_anio = anio_desde is not None or anio_hasta is not None
    resultados = []

    for ruta in _listar_excels(carpeta):
        try:
            libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        except Exception as error:
            resultados.append({
                "archivo": os.path.basename(ruta),
                "hoja": None,
                "fila": None,
                "error": f"No se pudo abrir: {error}",
            })
            continue

        for nombre_hoja in libro.sheetnames:
            hoja = libro[nombre_hoja]
            columnas = _detectar_columnas(hoja)
            if not columnas:
                continue  # esta hoja no tiene los encabezados esperados

            for numero_fila, fila in enumerate(hoja.iter_rows(min_row=2, values_only=True), start=2):
                if fila is None or all(v is None for v in fila):
                    continue

                valores_texto = " ".join(limpiar_texto_oculto(v) for v in fila if v is not None).lower()
                if texto_buscado not in valores_texto:
                    continue

                def obtener(campo):
                    idx = columnas.get(campo)
                    if idx is None or idx >= len(fila):
                        return None
                    return fila[idx]

                def obtener_limpio(campo):
                    valor = obtener(campo)
                    return limpiar_texto_oculto(valor) if valor is not None else None

                fecha_valor = obtener("fecha")
                partes = _partes_fecha(fecha_valor)

                if hay_filtro_anio:
                    if partes is None:
                        continue  # sin fecha reconocible: no se puede confirmar que entra en el rango
                    anio_fila = partes[0]
                    if anio_desde is not None and anio_fila < anio_desde:
                        continue
                    if anio_hasta is not None and anio_fila > anio_hasta:
                        continue

                resultados.append({
                    "archivo": os.path.basename(ruta),
                    "hoja": nombre_hoja,
                    "fila": numero_fila,
                    "dni": obtener_limpio("dni"),
                    "nombre": obtener_limpio("nombre"),
                    "documento": obtener_limpio("documento"),
                    "fecha": fecha_valor,
                    "estado": obtener_limpio("estado"),
                    "_orden_fecha": partes,
                })

        libro.close()

    # Ordenar cronologicamente los que sí tienen fecha reconocible;
    # los que no, quedan al final en el orden en que se encontraron.
    con_fecha = [r for r in resultados if r.get("_orden_fecha") is not None]
    sin_fecha = [r for r in resultados if r.get("_orden_fecha") is None]
    con_fecha.sort(key=lambda r: r["_orden_fecha"])

    for r in resultados:
        r.pop("_orden_fecha", None)

    return con_fecha + sin_fecha
