"""
sisgedo_export_service.py
---------------------------
Limpia el texto de una fila de tu Excel de control para que puedas
copiarlo y pegarlo directamente en el sistema web oficial (SISGEDO u
otro similar), evitando errores de digitación por espacios de más o
caracteres invisibles que a veces trae el copiado y pegado desde Excel.

Importante: esto NO elimina tildes ni la letra "ñ". SISGEDO es un
sistema web moderno que espera nombres escritos correctamente en
español — quitarle los acentos a un nombre real (por ejemplo, convertir
"Peña" en "Pena") sería introducir un error, no corregirlo. Esto es
distinto del limpiador de NOMBRES DE ARCHIVO del programa, que sí
elimina tildes porque ahí el problema es la compatibilidad con
sistemas de archivos antiguos, no el contenido de un formulario web.

Todo el procesamiento es local: no se envía nada a internet, solo se
prepara el texto para que tú lo pegues manualmente donde corresponda.
"""

import re
import unicodedata

from utils.helpers import limpiar_texto_oculto

# Espacios "raros" que a veces trae el copiado desde Excel u otras
# fuentes, y que no se ven a simple vista pero rompen la digitación:
# espacio de no separación, tabulación, etc.
ESPACIOS_INVISIBLES = ("\u00a0", "\u200b", "\t")


def limpiar_texto(valor) -> str:
    """
    Limpia un solo valor de celda: quita espacios invisibles, recorta
    espacios al inicio/final, colapsa espacios dobles en uno solo, y
    quita caracteres de control. Conserva tildes, ñ, y la puntuación
    normal (puntos, guiones, comas).

    Esta función es un envoltorio de utils.helpers.limpiar_texto_oculto
    (la lógica vive centralizada ahí para que otros módulos, como la
    búsqueda, también puedan usarla).
    """
    return limpiar_texto_oculto(valor)


def limpiar_fila(valores: dict) -> dict:
    """
    Limpia todos los valores de un diccionario de fila (por ejemplo,
    {"dni": ..., "nombre": ..., "documento": ...}), aplicando
    limpiar_texto a cada uno.
    """
    return {clave: limpiar_texto(valor) for clave, valor in valores.items()}


def formatear_para_portapapeles(valores: dict, separador: str = "\t") -> str:
    """
    Limpia una fila y la arma como una sola línea de texto, lista para
    pegar en SISGEDO (por ejemplo, en un buscador que espera
    "DNI Nombre" o para pegar en varias casillas seguidas con Tab).

    'separador' por defecto es un tabulador, para que si pegas sobre
    varias casillas de un formulario web, cada valor caiga en la
    casilla siguiente (igual que copiar celdas contiguas de Excel).
    """
    limpio = limpiar_fila(valores)
    return separador.join(limpio.values())
