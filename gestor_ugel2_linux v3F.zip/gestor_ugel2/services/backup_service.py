"""
backup_service.py
------------------
Copia de seguridad simple: copia todos los archivos .xlsx/.xlsm de tu
carpeta de Excel de control a una subcarpeta con fecha, dentro de
backups/. No se hace ninguna copia de PDFs ni de documentos sensibles:
solo de los Excel de control, que es lo que este programa modifica
(por ejemplo, al renombrar PDFs a partir de ellos).
"""

import os
import shutil
from datetime import datetime


def crear_backup_excel(carpeta_excel: str, carpeta_backups: str) -> dict:
    """
    Copia todos los .xlsx/.xlsm de carpeta_excel a
    backups/backup_<fecha>/ dentro de carpeta_backups.
    Devuelve cuántos archivos se copiaron y a dónde.
    """
    if not carpeta_excel or not os.path.isdir(carpeta_excel):
        return {"error": "La carpeta de Excel de control no es válida."}

    marca = datetime.now().strftime("%Y-%m-%d_%H%M")
    destino = os.path.join(carpeta_backups, f"backup_{marca}")
    os.makedirs(destino, exist_ok=True)

    copiados = []
    for nombre in os.listdir(carpeta_excel):
        if nombre.lower().endswith((".xlsx", ".xlsm")) and not nombre.startswith("~$"):
            origen = os.path.join(carpeta_excel, nombre)
            if os.path.isfile(origen):
                shutil.copy2(origen, os.path.join(destino, nombre))
                copiados.append(nombre)

    return {"destino": destino, "archivos": copiados}
