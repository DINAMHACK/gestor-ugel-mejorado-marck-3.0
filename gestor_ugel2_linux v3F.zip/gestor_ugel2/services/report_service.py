"""
report_service.py
------------------
Genera reportes en Excel (.xlsx), CSV y TXT a partir del resultado de
una validación. Texto en negro, fondo blanco, sin colores ni encabezados
repetidos: un reporte simple y legible.
"""

import csv
import os
from datetime import datetime

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font


def _nombre_reporte(extension: str) -> str:
    marca = datetime.now().strftime("%Y-%m-%d_%H%M")
    return f"REPORTE_PROCESAMIENTO_{marca}.{extension}"


def generar_reporte_excel(resumen: dict, carpeta_destino: str) -> str:
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte("xlsx"))

    libro = openpyxl.Workbook()
    hoja = libro.active
    hoja.title = "Reporte"

    encabezados = ["Fila", "DNI", "Estado", "Observación"]
    hoja.append(encabezados)
    for celda in hoja[1]:
        celda.font = Font(bold=True, color="000000")

    for problema in resumen.get("problemas", []):
        hoja.append([
            problema["fila"],
            problema["dni"],
            "OBSERVADO",
            "; ".join(problema["errores"]),
        ])

    hoja.append([])
    hoja.append(["Total analizados", resumen.get("total", 0)])
    hoja.append(["Correctos", resumen.get("correctos", 0)])
    hoja.append(["Observados", resumen.get("observados", 0)])

    for indice_col, columna in enumerate(hoja.columns, start=1):
        longitud_maxima = max((len(str(c.value)) for c in columna if c.value is not None), default=10)
        hoja.column_dimensions[get_column_letter(indice_col)].width = min(longitud_maxima + 2, 60)

    libro.save(ruta)
    return ruta


def generar_reporte_csv(resumen: dict, carpeta_destino: str) -> str:
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte("csv"))

    with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        escritor.writerow(["Fila", "DNI", "Estado", "Observación"])
        for problema in resumen.get("problemas", []):
            escritor.writerow([
                problema["fila"],
                problema["dni"],
                "OBSERVADO",
                "; ".join(problema["errores"]),
            ])
        escritor.writerow([])
        escritor.writerow(["Total analizados", resumen.get("total", 0)])
        escritor.writerow(["Correctos", resumen.get("correctos", 0)])
        escritor.writerow(["Observados", resumen.get("observados", 0)])
    return ruta


def generar_reporte_txt(resumen_texto: str, carpeta_destino: str) -> str:
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte("txt"))
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(resumen_texto)
    return ruta


_ENCABEZADOS_PLAZOS = [
    "Expediente", "DNI", "Nombre", "Fecha ingreso", "Estado",
    "Días transcurridos", "Días calendario", "Días hábiles",
    "Vence (plazo legal)", "Hábiles restantes", "Semáforo", "Observación",
]


def _texto_fecha(valor) -> str:
    """Fecha como dd/mm/aaaa (si viene como fecha de Excel); otro valor, tal cual."""
    if valor is None:
        return ""
    if hasattr(valor, "strftime"):
        return valor.strftime("%d/%m/%Y")
    return str(valor)


def _vacio_si_none(valor):
    return "" if valor is None else valor


def _fila_plazos(fila: dict) -> list:
    return [
        fila.get("expediente") or "",
        fila.get("dni") or "",
        fila.get("nombre") or "",
        _texto_fecha(fila.get("fecha_ingreso")),
        fila.get("estado") or "",
        _vacio_si_none(fila.get("dias_transcurridos")),
        _vacio_si_none(fila.get("dias_calendario")),
        _vacio_si_none(fila.get("dias_habiles")),
        fila.get("fecha_vencimiento") or "",
        _vacio_si_none(fila.get("dias_restantes")),
        (fila.get("color") or "").upper(),
        fila.get("observacion") or "",
    ]


def _nombre_reporte_plazos(extension: str) -> str:
    marca = datetime.now().strftime("%Y-%m-%d_%H%M")
    return f"REPORTE_PLAZOS_{marca}.{extension}"


def generar_reporte_plazos_excel(filas: list, carpeta_destino: str) -> str:
    """
    Genera el reporte de Control de Plazos. El semáforo se deja como
    texto (VERDE/AMARILLO/ROJO), no como color de celda, para mantener
    el reporte en blanco y negro como el resto de reportes del programa.
    """
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte_plazos("xlsx"))

    libro = openpyxl.Workbook()
    hoja = libro.active
    hoja.title = "Plazos"

    encabezados = list(_ENCABEZADOS_PLAZOS)
    hoja.append(encabezados)
    for celda in hoja[1]:
        celda.font = Font(bold=True, color="000000")

    for fila in filas:
        hoja.append(_fila_plazos(fila))

    for indice_col, columna in enumerate(hoja.columns, start=1):
        longitud_maxima = max((len(str(c.value)) for c in columna if c.value is not None), default=10)
        hoja.column_dimensions[get_column_letter(indice_col)].width = min(longitud_maxima + 2, 60)

    libro.save(ruta)
    return ruta


def generar_reporte_plazos_csv(filas: list, carpeta_destino: str) -> str:
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte_plazos("csv"))

    with open(ruta, "w", newline="", encoding="utf-8-sig") as f:
        escritor = csv.writer(f)
        escritor.writerow(_ENCABEZADOS_PLAZOS)
        for fila in filas:
            escritor.writerow(_fila_plazos(fila))
    return ruta
