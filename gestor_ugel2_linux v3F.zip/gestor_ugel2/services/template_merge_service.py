"""
template_merge_service.py
---------------------------
Fusiona datos (por ejemplo, el resultado de una validación o de
Control de Plazos) dentro de una plantilla Excel oficial que ya tiene
el logo, encabezados y formato de la UGEL — sin tocar ese formato.

Importante: este programa NO inventa la plantilla oficial. Tú debes
proporcionar el archivo .xlsx con el formato real de tu oficina
(logo, colores, tipografía). Esta función solo escribe los datos
dentro de las celdas que ya existen en esa plantilla, a partir de la
fila que indiques — nunca crea columnas, colores ni logos por su
cuenta.

Para no dañar el formato de la plantilla, esta función NUNCA inserta
filas nuevas (insertar filas puede correr celdas combinadas, fórmulas
y bordes). Si tienes más datos que filas disponibles en la plantilla,
te avisa en vez de romper el diseño.
"""

import os
import shutil
from datetime import datetime

import openpyxl


def _fila_es_segura_para_datos(hoja, numero_fila: int, cantidad_columnas: int) -> bool:
    """
    Una fila se considera seguro para escribir datos solo si NINGUNA de
    las columnas objetivo (1 a cantidad_columnas) está combinada con
    otra celda, ni contiene ya una fórmula. Esto evita pisar un pie de
    página, un título combinado, o una fila de totales con fórmula,
    aunque venga pegada justo después de los datos sin ninguna fila
    vacía de por medio.
    """
    for rango_combinado in hoja.merged_cells.ranges:
        if rango_combinado.min_row <= numero_fila <= rango_combinado.max_row:
            if rango_combinado.min_col <= cantidad_columnas:
                return False

    for columna in range(1, cantidad_columnas + 1):
        celda = hoja.cell(row=numero_fila, column=columna)
        valor = celda.value
        if isinstance(valor, str) and valor.startswith("="):
            return False

    return True


def fusionar_con_plantilla(
    ruta_plantilla: str,
    filas_datos: list,
    fila_inicio: int,
    hoja: str = None,
    ruta_salida: str = None,
) -> dict:
    """
    Copia la plantilla a un archivo nuevo y escribe 'filas_datos'
    (una lista de listas, cada una con los valores de una fila) a
    partir de 'fila_inicio', columna A en adelante.

    No modifica la plantilla original: siempre trabaja sobre una copia.

    Antes de escribir cada fila, comprueba que no tenga celdas
    combinadas ni fórmulas en las columnas donde va a escribir (por
    ejemplo, una fila de "TOTAL" justo debajo de los datos, sin fila
    vacía de separación). En cuanto encuentra una fila así, se detiene
    ahí — nunca la pisa — y avisa cuántas filas sí pudo escribir.
    """
    if not os.path.exists(ruta_plantilla):
        return {"error": f"No se encontró la plantilla: {ruta_plantilla}"}

    if not filas_datos:
        return {"error": "No hay datos para escribir."}

    if ruta_salida is None:
        marca = datetime.now().strftime("%Y-%m-%d_%H%M")
        carpeta = os.path.dirname(ruta_plantilla) or "."
        ruta_salida = os.path.join(carpeta, f"Reporte_{marca}.xlsx")

    # Trabajar siempre sobre una copia: la plantilla original nunca se toca.
    shutil.copy2(ruta_plantilla, ruta_salida)

    libro = openpyxl.load_workbook(ruta_salida)  # sin read_only: vamos a escribir
    hoja_activa = libro[hoja] if hoja else libro.active

    cantidad_columnas = max(len(fila) for fila in filas_datos)

    filas_escritas = 0
    aviso = None

    for offset, valores_fila in enumerate(filas_datos):
        fila_excel = fila_inicio + offset

        if not _fila_es_segura_para_datos(hoja_activa, fila_excel, cantidad_columnas):
            aviso = (
                f"Se detuvo en la fila {fila_excel} porque ahí la plantilla tiene una celda "
                f"combinada o una fórmula (por ejemplo, un total o un pie de página). Se "
                f"escribieron {filas_escritas} de {len(filas_datos)} fila(s) pedidas. Usa una "
                f"plantilla con más filas libres para datos si necesitas escribir todo el listado."
            )
            break

        for offset_columna, valor in enumerate(valores_fila, start=1):
            hoja_activa.cell(row=fila_excel, column=offset_columna).value = valor
        filas_escritas += 1

    libro.save(ruta_salida)
    libro.close()

    return {
        "ruta_salida": ruta_salida,
        "filas_escritas": filas_escritas,
        "filas_pedidas": len(filas_datos),
        "aviso": aviso,
    }
