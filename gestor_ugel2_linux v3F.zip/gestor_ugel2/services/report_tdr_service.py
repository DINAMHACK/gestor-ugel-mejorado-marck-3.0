"""
report_tdr_service.py
-----------------------
Genera el "Reporte Mensual de Entregables (TDR)" a partir de los expedientes
que han sido marcados como "ATENDIDO" en el módulo de Control de Plazos.

Este reporte sirve como sustento oficial formateado e imprimible para adjuntar
al Recibo por Honorarios y Orden de Servicio de cobro mensual en la UGEL.
"""

import os
from datetime import datetime
import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side


def _nombre_reporte_tdr() -> str:
    marca = datetime.now().strftime("%m_%Y")
    return f"Reporte_Mensual_Entregables_{marca}.xlsx"


def generar_reporte_mensual_tdr(filas_atendidas: list, carpeta_destino: str) -> str:
    """
    Toma una lista de diccionarios de filas atendidas (provenientes de plazos_service)
    o procesa directamente las filas cuyo estado sea ATENDIDO, y genera el archivo Excel
    oficial de Entregables Mensuales (TDR).
    """
    os.makedirs(carpeta_destino, exist_ok=True)
    ruta = os.path.join(carpeta_destino, _nombre_reporte_tdr())

    libro = openpyxl.Workbook()
    hoja = libro.active
    hoja.title = "Entregables Atendidos"

    # Estilos
    fuente_titulo = Font(name="Arial", size=14, bold=True, color="000000")
    fuente_subtitulo = Font(name="Arial", size=10, italic=True, color="333333")
    fuente_encabezado = Font(name="Arial", size=10, bold=True, color="000000")
    fuente_datos = Font(name="Arial", size=10, color="000000")
    fuente_total = Font(name="Arial", size=11, bold=True, color="000000")

    borde_delgado = Border(
        left=Side(style="thin", color="CCCCCC"),
        right=Side(style="thin", color="CCCCCC"),
        top=Side(style="thin", color="CCCCCC"),
        bottom=Side(style="thin", color="CCCCCC"),
    )

    # Título principal
    hoja.merge_cells("A1:G1")
    celda_titulo = hoja["A1"]
    celda_titulo.value = "REPORTE MENSUAL DE ENTREGABLES (TDR)"
    celda_titulo.font = fuente_titulo
    celda_titulo.alignment = Alignment(horizontal="center", vertical="center")

    hoja.merge_cells("A2:G2")
    celda_sub = hoja["A2"]
    fecha_hoy = datetime.now().strftime("%d/%m/%Y %H:%M")
    celda_sub.value = f"Sustento de Entregables Atendidos - Emisión: {fecha_hoy}"
    celda_sub.font = fuente_subtitulo
    celda_sub.alignment = Alignment(horizontal="center", vertical="center")

    hoja.append([])  # Fila 3 vacía

    # Encabezados de tabla (Fila 4)
    encabezados = [
        "N°",
        "Expediente",
        "DNI",
        "Apellidos y Nombres",
        "Fecha Ingreso",
        "Estado",
        "Observación / Sustento",
    ]
    hoja.append(encabezados)

    for celda in hoja[4]:
        celda.font = fuente_encabezado
        celda.alignment = Alignment(horizontal="center", vertical="center")
        celda.border = Border(bottom=Side(style="medium", color="000000"))

    # Filtrar solo atendidos por seguridad
    filas_filtradas = [
        f for f in filas_atendidas
        if str(f.get("estado") or "").strip().upper() == "ATENDIDO"
        or "ATENDIDO" in str(f.get("observacion") or "").upper()
    ]
    # Si no había ningún filtro estrictamente "ATENDIDO", usar las filas pasadas
    if not filas_filtradas:
        filas_filtradas = filas_atendidas

    for idx, f in enumerate(filas_filtradas, start=1):
        hoja.append([
            idx,
            f.get("expediente") or "—",
            f.get("dni") or "—",
            f.get("nombre") or "—",
            (f["fecha_ingreso"].strftime("%d/%m/%Y") if hasattr(f.get("fecha_ingreso"), "strftime") else str(f.get("fecha_ingreso") or "—")),
            f.get("estado") or "ATENDIDO",
            f.get("observacion") or "Atendido y cerrado correctamente",
        ])
        fila_actual = hoja.max_row
        for col_idx in range(1, 8):
            celda = hoja.cell(row=fila_actual, column=col_idx)
            celda.font = fuente_datos
            celda.border = borde_delgado
            if col_idx in (1, 2, 3, 5, 6):
                celda.alignment = Alignment(horizontal="center")

    # Fila de Totales
    hoja.append([])
    hoja.append(["Total de Entregables Atendidos:", len(filas_filtradas)])
    fila_total = hoja.max_row
    hoja.cell(row=fila_total, column=1).font = fuente_total
    hoja.cell(row=fila_total, column=2).font = fuente_total

    # Ajuste de ancho de columnas
    for indice, columna in enumerate(hoja.columns, start=1):
        longitud_maxima = max(
            (len(str(c.value)) for c in columna if c.value is not None),
            default=10,
        )
        # Se usa el número de columna (no columna[0]) porque la primera celda puede estar combinada.
        hoja.column_dimensions[get_column_letter(indice)].width = min(
            longitud_maxima + 4, 50
        )

    libro.save(ruta)
    libro.close()
    return ruta
