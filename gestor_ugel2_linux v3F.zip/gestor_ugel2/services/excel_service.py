"""
excel_service.py
-----------------
Carga un Excel, detecta sus columnas, y valida los datos fila por fila
contra las reglas configuradas (DNI, nombre, tipo de documento, fecha,
estado). No inventa categorías: solo compara contra lo que está en
config/settings.json.
"""

import openpyxl
from utils.validators import (
    es_dni_valido,
    es_dni_posible_formato_antiguo,
    es_texto_no_vacio,
    es_tipo_documento_valido,
    es_fecha_valida,
    es_estado_valido,
    normalizar_dni,
)

COLUMNAS_CLAVE = {
    "DNI": "dni",
    "NOMBRE": "nombre",
    "DOCUMENTO": "documento",
    "FECHA": "fecha",
    "ESTADO": "estado",
}


def listar_hojas(ruta_excel: str) -> list:
    """Devuelve los nombres de las hojas de un archivo Excel."""
    libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    hojas = libro.sheetnames
    libro.close()
    return hojas


def detectar_columnas(ruta_excel: str, hoja: str) -> dict:
    """
    Lee la primera fila de la hoja y ubica en qué columna está cada
    campo clave (DNI, NOMBRE, DOCUMENTO, FECHA, ESTADO), sin importar
    el orden en que aparezcan.
    """
    libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    hoja_activa = libro[hoja]
    encabezados = {}
    primera_fila = next(hoja_activa.iter_rows(min_row=1, max_row=1), [])
    for celda in primera_fila:
        if celda.value is None:
            continue
        texto = str(celda.value).strip().upper()
        if texto in COLUMNAS_CLAVE:
            encabezados[COLUMNAS_CLAVE[texto]] = celda.column - 1  # índice base 0
    libro.close()
    return encabezados


def cargar_filas(ruta_excel: str, hoja: str) -> list:
    """Carga todas las filas (después del encabezado) como listas de valores."""
    libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    hoja_activa = libro[hoja]
    filas = []
    for fila in hoja_activa.iter_rows(min_row=2, values_only=True):
        if fila is None or all(v is None for v in fila):
            continue
        filas.append(list(fila))
    libro.close()
    return filas


def leer_fila_bruta(ruta_excel: str, hoja: str, numero_fila: int) -> dict:
    """
    Lee una fila completa de la hoja (todas las columnas que tengan
    encabezado en la fila 1), sin limitarse a las columnas clave
    (DNI, NOMBRE, etc.). Útil para exportar una fila cualquiera —por
    ejemplo, con Código Modular u otras columnas propias del Excel de
    la oficina— lista para copiar a otro sistema.

    'numero_fila' usa la numeración real de Excel (la fila 2 es la
    primera fila de datos, justo debajo del encabezado).

    Devuelve un diccionario ordenado {encabezado: valor}. Si una
    columna no tiene encabezado en la fila 1, se omite (no se puede
    nombrar un dato sin encabezado).
    """
    libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    if hoja not in libro.sheetnames:
        libro.close()
        raise ValueError(f"La hoja \"{hoja}\" no existe en este archivo.")

    hoja_activa = libro[hoja]

    # values_only=True evita depender de objetos de celda: filas
    # totalmente vacías pueden devolver tipos internos de openpyxl
    # (EmptyCell) que no tienen los mismos atributos que una celda
    # normal; trabajar solo con valores por posición evita ese problema.
    encabezados = next(hoja_activa.iter_rows(min_row=1, max_row=1, values_only=True), None)
    fila_datos = next(hoja_activa.iter_rows(min_row=numero_fila, max_row=numero_fila, values_only=True), None)
    libro.close()

    if not encabezados:
        raise ValueError("Esta hoja no tiene encabezados en la primera fila.")
    if fila_datos is None:
        raise ValueError(f"La fila {numero_fila} no existe en esta hoja.")

    resultado = {}
    for encabezado, valor in zip(encabezados, fila_datos):
        if encabezado is not None:
            resultado[str(encabezado).strip()] = valor

    return resultado


def validar_excel(ruta_excel: str, hoja: str, tipos_validos: list, estados_validos: list) -> dict:
    """
    Valida un Excel completo y devuelve un resumen:
    total de filas, correctas, observadas, y el detalle de cada problema.
    """
    columnas = detectar_columnas(ruta_excel, hoja)
    faltantes = [c for c in ("dni", "nombre", "documento") if c not in columnas]
    if faltantes:
        return {
            "error": (
                "No se encontraron las columnas obligatorias: "
                + ", ".join(faltantes).upper()
                + ". Verifica los encabezados de la primera fila."
            )
        }

    filas = cargar_filas(ruta_excel, hoja)
    problemas = []
    avisos = []
    dnis_vistos = {}
    correctos = 0

    for numero_fila, fila in enumerate(filas, start=2):
        errores_fila = []

        def obtener(campo):
            idx = columnas.get(campo)
            if idx is None or idx >= len(fila):
                return None
            return fila[idx]

        dni_valor = obtener("dni")
        nombre_valor = obtener("nombre")
        documento_valor = obtener("documento")
        fecha_valor = obtener("fecha")
        estado_valor = obtener("estado")

        if es_dni_valido(dni_valor):
            dni_normalizado = normalizar_dni(dni_valor)
            dnis_vistos.setdefault(dni_normalizado, []).append(numero_fila)
        elif es_dni_posible_formato_antiguo(dni_valor):
            # 7 dígitos: no se rechaza como error (podría ser un DNI
            # antiguo real, común en personas mayores), pero tampoco se
            # acepta en silencio, porque también podría ser un DNI de 8
            # dígitos con un dígito faltante por error de digitación.
            # Se marca aparte para que TÚ decidas, revisando el caso.
            avisos.append({
                "fila": numero_fila,
                "dni": dni_valor,
                "aviso": "DNI de 7 dígitos: verificar si es un documento antiguo real o un dígito faltante.",
            })
            dni_normalizado = normalizar_dni(dni_valor)
            dnis_vistos.setdefault(dni_normalizado, []).append(numero_fila)
        else:
            errores_fila.append("DNI inválido")

        if not es_texto_no_vacio(nombre_valor):
            errores_fila.append("Nombre vacío")

        if documento_valor is not None and not es_tipo_documento_valido(documento_valor, tipos_validos):
            errores_fila.append(f"Tipo de documento desconocido ({documento_valor})")
        elif documento_valor is None:
            errores_fila.append("Documento vacío")

        if fecha_valor is not None and not es_fecha_valida(fecha_valor):
            errores_fila.append("Fecha con formato inválido")

        if estado_valor is not None and not es_estado_valido(estado_valor, estados_validos):
            errores_fila.append(f"Estado desconocido ({estado_valor})")

        if errores_fila:
            problemas.append({
                "fila": numero_fila,
                "dni": dni_valor,
                "errores": errores_fila,
            })
        else:
            correctos += 1

    # DNI duplicados dentro del mismo Excel
    duplicados = {dni: filas_ocurrencia for dni, filas_ocurrencia in dnis_vistos.items() if len(filas_ocurrencia) > 1}
    for dni, filas_ocurrencia in duplicados.items():
        problemas.append({
            "fila": ", ".join(str(f) for f in filas_ocurrencia),
            "dni": dni,
            "errores": [f"DNI duplicado (filas {', '.join(str(f) for f in filas_ocurrencia)})"],
        })

    return {
        "total": len(filas),
        "correctos": correctos,
        "avisos": avisos,
        "observados": len(problemas),
        "problemas": problemas,
        "columnas_detectadas": columnas,
    }
