"""
pdf_extractor_service.py
--------------------------
Extrae datos (Resolución, Expediente, DNIs, Fechas, Códigos patrimoniales)
de un lote de documentos y los guarda en un Excel nuevo.

Lee:
  - PDFs con texto digital (rápido, sin OCR).
  - PDFs ESCANEADOS y fotos PNG/JPG/TIF (tipo CamScanner) mediante OCR
    local (ver ocr_service.py), si el motor OCR está instalado.

El Excel trae dos hojas:
  1. "Datos Extraídos": una fila por archivo.
  2. "Índice por DNI": una fila por cada DNI y archivo donde aparece
     (con las páginas), para ubicar rápido el documento de una persona.

Los datos leídos por OCR llevan la columna "Revisar" en SÍ cuando la
lectura es dudosa (confianza baja, o DNI sin etiqueta): hay que
compararlos con el documento antes de usarlos. No modifica ningún
archivo original.
"""

import os

import openpyxl
from openpyxl.utils import get_column_letter
from openpyxl.styles import Font

from services import ocr_service
from services.ocr_campos_service import extraer_campos

UMBRAL_REVISAR = ocr_service.CONFIANZA_MINIMA_BUENA + 8  # 80


def _listar_documentos(carpeta: str, incluir_subcarpetas: bool) -> list:
    encontrados = []
    if incluir_subcarpetas:
        for raiz, _dirs, archivos in os.walk(carpeta):
            for nombre in archivos:
                encontrados.append(os.path.join(raiz, nombre))
    else:
        for nombre in os.listdir(carpeta):
            ruta = os.path.join(carpeta, nombre)
            if os.path.isfile(ruta):
                encontrados.append(ruta)
    return sorted(r for r in encontrados
                  if ocr_service.es_archivo_soportado(r) and not os.path.basename(r).startswith("~"))


def _unir(lista, vacio="No detectado") -> str:
    return ", ".join(lista) if lista else vacio


def extraer_datos_patrimonio_pdf(ruta_carpeta_pdfs: str, ruta_salida_excel: str = None,
                                 usar_ocr: bool = True, incluir_subcarpetas: bool = False,
                                 progreso=None, cancelar=None) -> dict:
    """
    Procesa todos los PDFs e imágenes de la carpeta y guarda el Excel.

    progreso(indice_archivo, total_archivos, nombre_archivo) se llama por cada archivo.
    cancelar() debe devolver True para detener el proceso.

    Devuelve {"ruta_salida", "total_procesados", "datos": [...], "ocr_disponible", "sin_leer"}
    o {"error": "..."}. Cada elemento de "datos" trae: archivo, resolucion, expedientes,
    dnis, dnis_posibles, fechas, codigos_patrimoniales, metodo, confianza, revisar, paginas.
    """
    if not os.path.isdir(ruta_carpeta_pdfs):
        return {"error": "La carpeta especificada no existe."}

    documentos = _listar_documentos(ruta_carpeta_pdfs, incluir_subcarpetas)
    if not documentos:
        return {"error": "No se encontraron PDFs ni imágenes (PNG, JPG, TIF) en la carpeta seleccionada."}

    estado = ocr_service.estado_ocr()
    ocr_ok = usar_ocr and estado["disponible"]

    datos = []
    indice_dni = []  # (dni, archivo, paginas, metodo, revisar)
    sin_leer = 0

    for i, ruta in enumerate(documentos, start=1):
        if cancelar and cancelar():
            break
        nombre = os.path.relpath(ruta, ruta_carpeta_pdfs)
        if progreso:
            progreso(i, len(documentos), nombre)

        extension = os.path.splitext(ruta)[1].lower()
        fila = {"archivo": nombre, "resolucion": "—", "expedientes": "—", "dnis": "—",
                "dnis_posibles": "—", "fechas": "—", "codigos_patrimoniales": "—",
                "metodo": "", "confianza": "", "revisar": "", "paginas": ""}

        # Una imagen o un PDF sin texto necesitan OCR; si no está disponible, se avisa.
        try:
            if ocr_ok:
                lectura = ocr_service.leer_archivo(ruta, cancelar=cancelar)
            elif extension == ".pdf":
                lectura = _leer_pdf_solo_texto(ruta)
            else:
                lectura = {"error": None, "paginas": [], "texto": "", "usa_ocr": False,
                           "confianza_media": None, "necesita_ocr": True}
        except ocr_service.OcrCancelado:
            break
        except Exception as error:
            fila["resolucion"] = f"Error de lectura: {error}"
            fila["metodo"] = "Error"
            fila["revisar"] = "SÍ"
            datos.append(fila)
            sin_leer += 1
            continue

        if lectura.get("error"):
            fila["resolucion"] = f"Error de lectura: {lectura['error']}"
            fila["metodo"] = "Error"
            fila["revisar"] = "SÍ"
            datos.append(fila)
            sin_leer += 1
            continue

        if lectura.get("necesita_ocr") or not (lectura.get("texto") or "").strip():
            motivo = ("Sin texto: requiere OCR (motor OCR no instalado)" if not ocr_ok
                      else "Sin texto legible (hoja en blanco o imagen muy dañada)")
            for clave in ("resolucion", "expedientes", "dnis", "dnis_posibles", "fechas", "codigos_patrimoniales"):
                fila[clave] = motivo
            fila["metodo"] = "Escaneado sin leer"
            fila["revisar"] = "SÍ"
            datos.append(fila)
            sin_leer += 1
            continue

        # Campos por página, para saber en qué páginas está cada DNI
        resoluciones, expedientes, fechas, patrimoniales = [], [], [], []
        confirmados, posibles = [], []
        paginas_por_dni = {}
        for pagina in lectura["paginas"]:
            campos = extraer_campos(pagina["texto"])
            resoluciones += campos["resoluciones"]
            expedientes += campos["expedientes"]
            fechas += campos["fechas"]
            patrimoniales += campos["codigos_patrimoniales"]
            confirmados += campos["dnis_confirmados"]
            posibles += campos["dnis_posibles"]
            for dni in campos["dnis_confirmados"] + campos["dnis_posibles"]:
                paginas_por_dni.setdefault(dni, []).append(pagina["numero"])

        confirmados = list(dict.fromkeys(confirmados))
        posibles = [p for p in dict.fromkeys(posibles) if p not in confirmados]

        usa_ocr = lectura["usa_ocr"]
        confianza = lectura["confianza_media"]
        hay_texto_digital = any(p["origen"] == "texto" for p in lectura["paginas"])
        metodo = ("OCR + texto digital" if usa_ocr and hay_texto_digital
                  else "OCR" if usa_ocr else "Texto digital")
        # Se revisa si el OCR dudó, o si el DNI vino de OCR sin etiqueta clara
        revisar = usa_ocr and ((confianza is not None and confianza < UMBRAL_REVISAR)
                               or (not confirmados and bool(posibles)))

        fila.update({
            "resolucion": _unir(list(dict.fromkeys(resoluciones))[:3]),
            "expedientes": _unir(list(dict.fromkeys(expedientes))[:3]),
            "dnis": _unir(confirmados),
            "dnis_posibles": _unir(posibles, vacio="—"),
            "fechas": _unir(list(dict.fromkeys(fechas))),
            "codigos_patrimoniales": _unir(list(dict.fromkeys(patrimoniales)), vacio="—"),
            "metodo": metodo,
            "confianza": "" if confianza is None else confianza,
            "revisar": "SÍ" if revisar else "NO",
            "paginas": len(lectura["paginas"]),
        })
        datos.append(fila)

        for dni, paginas in paginas_por_dni.items():
            indice_dni.append((dni, nombre, ", ".join(str(p) for p in dict.fromkeys(paginas)), metodo,
                               "SÍ" if (revisar or dni in posibles) and usa_ocr else "NO",
                               "Con etiqueta DNI" if dni in confirmados else "Número suelto de 8 dígitos"))

    if ruta_salida_excel is None:
        ruta_salida_excel = os.path.join(ruta_carpeta_pdfs, "DATOS_EXTRAIDOS_PDF.xlsx")

    _guardar_excel(ruta_salida_excel, datos, indice_dni)

    return {"ruta_salida": ruta_salida_excel, "total_procesados": len(datos), "datos": datos,
            "ocr_disponible": estado["disponible"], "ocr_mensaje": estado["mensaje"], "sin_leer": sin_leer}


def _leer_pdf_solo_texto(ruta: str) -> dict:
    """Lectura sin OCR (motor no instalado): solo PDFs con texto digital."""
    import pymupdf as fitz
    paginas = []
    with fitz.open(ruta) as doc:
        for i, pagina in enumerate(doc, start=1):
            paginas.append({"numero": i, "texto": pagina.get_text().strip(), "origen": "texto", "confianza": None})
    texto = "\n\n".join(p["texto"] for p in paginas if p["texto"])
    return {"error": None, "paginas": paginas, "texto": texto, "usa_ocr": False,
            "confianza_media": None, "necesita_ocr": not texto.strip()}


def _guardar_excel(ruta: str, datos: list, indice_dni: list):
    libro = openpyxl.Workbook()
    hoja = libro.active
    hoja.title = "Datos Extraídos"
    encabezados = ["Archivo", "N° Resolución Detectado", "Expediente", "DNIs Encontrados",
                   "Otros números de 8 dígitos (verificar)", "Fechas Detectadas",
                   "Códigos patrimoniales (12 dígitos)", "Método de lectura", "Confianza OCR (%)",
                   "Revisar", "Páginas"]
    hoja.append(encabezados)
    for d in datos:
        hoja.append([d["archivo"], d["resolucion"], d["expedientes"], d["dnis"], d["dnis_posibles"],
                     d["fechas"], d["codigos_patrimoniales"], d["metodo"], d["confianza"],
                     d["revisar"], d["paginas"]])
    _formato_simple(hoja)

    hoja2 = libro.create_sheet("Índice por DNI")
    hoja2.append(["DNI", "Archivo", "Páginas", "Método de lectura", "Revisar", "Cómo se detectó"])
    for fila in sorted(indice_dni, key=lambda f: (f[0], f[1])):
        celda_dni = fila[0]
        hoja2.append([celda_dni, fila[1], fila[2], fila[3], fila[4], fila[5]])
        hoja2.cell(row=hoja2.max_row, column=1).number_format = "@"
    _formato_simple(hoja2)

    # Los DNI y códigos como texto para que Excel no les borre el cero inicial
    for fila in hoja.iter_rows(min_row=2):
        for celda in (fila[3], fila[4], fila[6]):
            celda.number_format = "@"
    libro.save(ruta)
    libro.close()


def _formato_simple(hoja):
    """Solo negrita en el encabezado; texto negro sobre fondo blanco."""
    for celda in hoja[1]:
        celda.font = Font(bold=True)
    for indice_col, columna in enumerate(hoja.columns, start=1):
        mayor = max((len(str(c.value)) for c in columna if c.value is not None), default=12)
        hoja.column_dimensions[get_column_letter(indice_col)].width = min(mayor + 3, 60)
    hoja.freeze_panes = "A2"
