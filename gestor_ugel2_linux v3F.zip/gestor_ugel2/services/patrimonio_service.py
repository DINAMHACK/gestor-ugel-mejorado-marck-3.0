"""
patrimonio_service.py
-----------------------
Formateador y validador de Códigos Patrimoniales de la SBN (Superintendencia
Nacional de Bienes Estatales) y SIGA/SINABIP.

Exige códigos de exactamente 12 dígitos numéricos. Si el dato viene con
espacios, guiones, letras, "N°", "#" u otros caracteres, los remueve y deja
únicamente la secuencia numérica limpia.

Además, si el Catálogo SBN fue importado (ver catalogo_sbn_service.py),
comprueba que los primeros 8 dígitos existan en el catálogo oficial y agrega
al final de la hoja las columnas: CATALOGO SBN (8), CORRELATIVO (4),
DENOMINACION CATALOGO y VALIDACION CATALOGO. Las alertas van en texto
y negrita (sin colores).

Seguridad: esta función NUNCA modifica tu archivo original. Siempre guarda el
resultado en un archivo nuevo (*_patrimonial.xlsx).
"""

import os
import re
import openpyxl
from openpyxl.styles import Font

from services import catalogo_sbn_service

ENCABEZADOS_CATALOGO = ["CATALOGO SBN (8)", "CORRELATIVO (4)", "DENOMINACION CATALOGO", "VALIDACION CATALOGO"]
TEXTO_ESTADO = {
    "OK": "OK",
    "NO_ENCONTRADO": "ALERTA: NO EXISTE EN EL CATALOGO",
    "SIN_CATALOGO": "CATALOGO NO CARGADO",
}


def limpiar_codigo_patrimonial(texto_sucio) -> str:
    """
    Remueve letras, espacios, guiones, N°, # y deja solo los 12 números exactos.
    Si al final no tiene 12 dígitos, devuelve una advertencia de error.
    """
    if texto_sucio is None or str(texto_sucio).strip().lower() in ("none", "nan", ""):
        return ""

    texto = str(texto_sucio).strip()

    # Si Excel lo interpretó como flotante (ej. 742200500012.0)
    if texto.endswith(".0"):
        texto = texto[:-2]

    # Extrae únicamente los dígitos numéricos
    solo_numeros = re.sub(r"\D", "", texto)

    if len(solo_numeros) == 12:
        return solo_numeros
    elif len(solo_numeros) > 0:
        return f"OBSERVADO: {len(solo_numeros)} dígitos (Debe ser 12 -> {solo_numeros})"
    else:
        return "OBSERVADO: Sin dígitos numéricos"


def proteger_codigo_patrimonial_excel(
    ruta_excel: str, hoja: str, nombre_columna: str, ruta_salida: str = None
) -> dict:
    """
    Abre el Excel, busca la columna por encabezado y limpia los códigos patrimoniales:
      - Remueve ruido (N°, guiones, espacios, letras).
      - Aplica formato de celda "@" (Texto) para no perder ceros a la izquierda.
      - Guarda en ruta_salida (*_patrimonial.xlsx por defecto). NUNCA toca el original.
    """
    try:
        libro = openpyxl.load_workbook(ruta_excel, data_only=True)
    except Exception as error:
        return {"error": f"No se pudo abrir el archivo: {error}"}

    if hoja not in libro.sheetnames:
        libro.close()
        return {"error": f'La hoja "{hoja}" no existe en este archivo.'}

    hoja_activa = libro[hoja]

    columna_indice = None
    for celda in next(hoja_activa.iter_rows(min_row=1, max_row=1), []):
        if (
            celda.value is not None
            and str(celda.value).strip().upper() == nombre_columna.strip().upper()
        ):
            columna_indice = celda.column
            break

    if columna_indice is None:
        libro.close()
        return {
            "error": f'No se encontró la columna "{nombre_columna}" en la primera fila.'
        }

    corregidos = 0
    observados = 0
    total_con_dato = 0

    estado_cat = catalogo_sbn_service.estado_catalogo()
    columnas_cat = _columnas_catalogo(hoja_activa)
    conteo_cat = {"OK": 0, "NO_ENCONTRADO": 0, "SIN_CATALOGO": 0}
    alertas = []

    for fila in hoja_activa.iter_rows(min_row=2):
        celda = fila[columna_indice - 1]
        if celda.value is None:
            continue

        total_con_dato += 1
        valor_original = celda.value
        valor_limpio = limpiar_codigo_patrimonial(valor_original)

        if valor_limpio.startswith("OBSERVADO"):
            observados += 1
        elif str(valor_original) != valor_limpio or celda.number_format != "@":
            corregidos += 1

        celda.value = valor_limpio
        celda.number_format = "@"

        if re.fullmatch(r"\d{12}", valor_limpio):
            validacion = catalogo_sbn_service.validar_codigo(valor_limpio)
            conteo_cat[validacion["estado"]] += 1
            texto_estado = TEXTO_ESTADO[validacion["estado"]]
            if validacion["estado"] == "NO_ENCONTRADO" and estado_cat["parcial"]:
                texto_estado += " (catalogo parcial)"
            if validacion["detalle"] and validacion["estado"] != "SIN_CATALOGO":
                texto_estado += f" - {validacion['detalle']}"
            _escribir_catalogo(hoja_activa, celda.row, columnas_cat, validacion, texto_estado)
            if validacion["estado"] == "NO_ENCONTRADO":
                alertas.append((celda.row, valor_limpio, texto_estado))
        elif valor_limpio.startswith("OBSERVADO"):
            _escribir_catalogo(hoja_activa, celda.row, columnas_cat, None, "NO VALIDADO: codigo sin 12 digitos")

    if alertas:
        if "Alertas catalogo" in libro.sheetnames:
            del libro["Alertas catalogo"]
        hoja_alertas = libro.create_sheet("Alertas catalogo")
        hoja_alertas.append(["Fila", "Codigo patrimonial", "Alerta"])
        for celda_enc in hoja_alertas[1]:
            celda_enc.font = Font(bold=True)
        for fila_n, codigo, texto in alertas:
            hoja_alertas.append([fila_n, codigo, texto])
            hoja_alertas.cell(row=hoja_alertas.max_row, column=2).number_format = "@"
        hoja_alertas.column_dimensions["B"].width = 20
        hoja_alertas.column_dimensions["C"].width = 70

    if ruta_salida is None:
        base, ext = os.path.splitext(ruta_excel)
        ruta_salida = f"{base}_patrimonial{ext}"

    libro.save(ruta_salida)
    libro.close()

    return {
        "ruta_salida": ruta_salida,
        "columna": nombre_columna,
        "celdas_con_dato": total_con_dato,
        "celdas_corregidas": corregidos,
        "celdas_observadas": observados,
        "catalogo": estado_cat,
        "catalogo_ok": conteo_cat["OK"],
        "catalogo_no_encontrados": conteo_cat["NO_ENCONTRADO"],
        "catalogo_sin_validar": conteo_cat["SIN_CATALOGO"],
    }


def _columnas_catalogo(hoja) -> dict:
    """Ubica (o reserva al final de la hoja) las 4 columnas de validación del catálogo."""
    existentes = {}
    for celda in next(hoja.iter_rows(min_row=1, max_row=1), []):
        if celda.value is not None:
            existentes[str(celda.value).strip().upper()] = celda.column
    siguiente = hoja.max_column + 1
    columnas = {}
    for nombre in ENCABEZADOS_CATALOGO:
        if nombre in existentes:
            columnas[nombre] = existentes[nombre]
        else:
            columnas[nombre] = siguiente
            hoja.cell(row=1, column=siguiente, value=nombre).font = Font(bold=True)
            siguiente += 1
    return columnas


def _escribir_catalogo(hoja, fila: int, columnas: dict, validacion, texto_estado: str):
    valores = {
        "CATALOGO SBN (8)": validacion["catalogo"] if validacion else "",
        "CORRELATIVO (4)": validacion["correlativo"] if validacion else "",
        "DENOMINACION CATALOGO": validacion["denominacion"] if validacion else "",
        "VALIDACION CATALOGO": texto_estado,
    }
    for nombre, valor in valores.items():
        celda = hoja.cell(row=fila, column=columnas[nombre], value=valor)
        celda.number_format = "@"
        if nombre == "VALIDACION CATALOGO" and texto_estado.startswith(("ALERTA", "NO VALIDADO")):
            celda.font = Font(bold=True)
