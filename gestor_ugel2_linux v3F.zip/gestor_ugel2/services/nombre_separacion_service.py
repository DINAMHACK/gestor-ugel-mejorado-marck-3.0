"""
nombre_separacion_service.py
------------------------------
Separa una columna de "Apellidos y Nombres" (formato estándar de la
administración pública peruana: "APELLIDO PATERNO APELLIDO MATERNO,
NOMBRES") en tres columnas nuevas: Apellido Paterno, Apellido Materno
y Nombres.

Antes de separar, limpia espacios invisibles (como el espacio de no
separación que traen muchas plataformas del Estado) para que la
separación por espacios no falle silenciosamente.

Seguridad: esta función NUNCA modifica tu archivo original. Siempre
guarda el resultado en un archivo nuevo, con las 3 columnas agregadas
al final — nunca sobreescribe ni reordena las columnas existentes.
"""

import os
from datetime import datetime

import openpyxl

from utils.helpers import limpiar_texto_oculto

# Partículas comunes en apellidos compuestos peruanos/hispanos. Si una de
# estas palabras aparece al inicio de un bloque de apellido, se agrupa
# junto con la palabra siguiente (por ejemplo, "DE LA CRUZ" se trata como
# un solo apellido, no como "DE" + "LA CRUZ").
PARTICULAS_APELLIDO = {"de", "del", "la", "los", "las", "san", "santa", "vda"}


def _extraer_bloque_apellido(palabras: list, inicio: int):
    """
    Agrupa, a partir de 'inicio', cualquier partícula (de, la, del...)
    junto con la palabra ancla que le sigue, para formar un solo bloque
    de apellido. Devuelve (bloque_de_texto, siguiente_indice).
    """
    if inicio >= len(palabras):
        return "", inicio
    fin = inicio
    while fin < len(palabras) - 1 and palabras[fin].lower() in PARTICULAS_APELLIDO:
        fin += 1
    fin += 1  # incluir la palabra ancla (el apellido en sí) tras las partículas
    return " ".join(palabras[inicio:fin]), fin


def _separar_paterno_materno(bloque_apellidos: str):
    """
    Divide un bloque de apellidos ("PEREZ GOMEZ", "DE LA CRUZ MENDOZA",
    "TORRES") en (apellido_paterno, apellido_materno), reconociendo
    partículas compuestas. Cualquier palabra sobrante (apellidos con más
    de dos bloques) se agrega al final del materno, sin perderla.
    """
    palabras = bloque_apellidos.split()
    if not palabras:
        return "", ""

    paterno, siguiente = _extraer_bloque_apellido(palabras, 0)
    resto = palabras[siguiente:]
    if not resto:
        return paterno, ""

    materno, siguiente2 = _extraer_bloque_apellido(resto, 0)
    sobrante = resto[siguiente2:]
    if sobrante:
        materno = materno + " " + " ".join(sobrante)

    return paterno, materno


def separar_apellidos_y_nombres(ruta_excel: str, hoja: str, nombre_columna: str, ruta_salida: str = None) -> dict:
    """
    Lee la columna indicada (por ejemplo, "Nombres Completos") y, para
    cada fila cuyo texto tenga el formato "APELLIDOS, NOMBRES" (con una
    coma separando ambos bloques), agrega tres columnas nuevas al final
    de la hoja: Apellido Paterno, Apellido Materno, Nombres.

    Si el texto no tiene coma, se deja tal cual en "Nombres" como
    respaldo (no se inventa una separación que no está clara).

    Devuelve un resumen con la ruta del archivo nuevo y cuántas filas
    se separaron correctamente.
    """
    libro = openpyxl.load_workbook(ruta_excel, data_only=True)  # sin read_only: vamos a escribir
    if hoja not in libro.sheetnames:
        libro.close()
        return {"error": f"La hoja \"{hoja}\" no existe en este archivo."}

    hoja_activa = libro[hoja]

    columna_indice = None
    for celda in next(hoja_activa.iter_rows(min_row=1, max_row=1), []):
        if celda.value is not None and str(celda.value).strip().upper() == nombre_columna.strip().upper():
            columna_indice = celda.column
            break

    if columna_indice is None:
        libro.close()
        return {"error": f"No se encontró la columna \"{nombre_columna}\" en la primera fila."}

    max_col_original = hoja_activa.max_column
    col_paterno = max_col_original + 1
    col_materno = max_col_original + 2
    col_nombres = max_col_original + 3

    hoja_activa.cell(row=1, column=col_paterno, value="Apellido Paterno")
    hoja_activa.cell(row=1, column=col_materno, value="Apellido Materno")
    hoja_activa.cell(row=1, column=col_nombres, value="Nombres Separados")

    filas_con_coma = 0
    filas_sin_coma = 0
    filas_vacias = 0

    for numero_fila in range(2, hoja_activa.max_row + 1):
        celda_origen = hoja_activa.cell(row=numero_fila, column=columna_indice)
        valor_original = celda_origen.value

        if valor_original is None:
            filas_vacias += 1
            continue

        # Limpia espacios invisibles (por ejemplo, de plataformas del Estado)
        # ANTES de separar por comas y espacios, para que la separación no
        # falle silenciosamente por un espacio que no se ve.
        texto = limpiar_texto_oculto(valor_original)
        celda_origen.value = texto  # deja también la celda original limpia (mismo archivo de salida)

        if not texto:
            filas_vacias += 1
            continue

        if "," in texto:
            # split(",", 1): solo corta en la PRIMERA coma. Si el dato
            # tuviera una coma de más (dato raro), todo lo que sigue se
            # queda dentro del bloque de nombres en vez de perderse.
            bloque_apellidos, bloque_nombres = texto.split(",", 1)
            bloque_apellidos = bloque_apellidos.strip()
            bloque_nombres = bloque_nombres.strip()

            # .split() sin argumentos: colapsa automáticamente cualquier
            # espacio múltiple, a diferencia de .split(" ").
            # _separar_paterno_materno reconoce partículas compuestas
            # (DE, DEL, LA...) para no cortar mal un apellido como
            # "DE LA CRUZ".
            ape_paterno, ape_materno = _separar_paterno_materno(bloque_apellidos)

            hoja_activa.cell(row=numero_fila, column=col_paterno, value=ape_paterno.upper())
            hoja_activa.cell(row=numero_fila, column=col_materno, value=ape_materno.upper())
            hoja_activa.cell(row=numero_fila, column=col_nombres, value=bloque_nombres.upper())
            filas_con_coma += 1
        else:
            # Sin coma: no se adivina dónde termina el apellido y empieza
            # el nombre. Se deja todo en "Nombres" como respaldo visible.
            hoja_activa.cell(row=numero_fila, column=col_nombres, value=texto.upper())
            filas_sin_coma += 1

    if ruta_salida is None:
        base, ext = os.path.splitext(ruta_excel)
        ruta_salida = f"{base}_separado{ext}"

    libro.save(ruta_salida)
    libro.close()

    return {
        "ruta_salida": ruta_salida,
        "filas_separadas": filas_con_coma,
        "filas_sin_coma": filas_sin_coma,
        "filas_vacias": filas_vacias,
    }
