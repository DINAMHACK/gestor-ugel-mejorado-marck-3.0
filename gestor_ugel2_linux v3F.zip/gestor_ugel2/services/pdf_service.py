"""
pdf_service.py
---------------
Herramientas PDF: unir, dividir, rotar, extraer páginas y comprimir.
Usa PyMuPDF (fitz) como motor principal.
"""

import os
import pymupdf as fitz  # PyMuPDF (nombre de import recomendado)


def unir_pdfs(rutas_pdf: list, ruta_salida: str) -> str:
    """Une varios PDFs, en el orden de la lista, en un solo archivo."""
    if not rutas_pdf:
        raise ValueError("No se proporcionó ningún PDF para unir.")

    documento_final = fitz.open()
    try:
        for ruta in rutas_pdf:
            with fitz.open(ruta) as doc:
                documento_final.insert_pdf(doc)
        documento_final.save(ruta_salida)
    finally:
        documento_final.close()
    return ruta_salida


def dividir_pdf(ruta_pdf: str, carpeta_salida: str, prefijo: str = "parte") -> list:
    """Divide un PDF en un archivo por cada página."""
    os.makedirs(carpeta_salida, exist_ok=True)
    rutas_generadas = []
    with fitz.open(ruta_pdf) as doc:
        total_paginas = len(doc)
        relleno = max(3, len(str(total_paginas)))
        for numero in range(total_paginas):
            nuevo = fitz.open()
            nuevo.insert_pdf(doc, from_page=numero, to_page=numero)
            nombre = f"{prefijo}_{str(numero + 1).zfill(relleno)}.pdf"
            ruta_destino = os.path.join(carpeta_salida, nombre)
            nuevo.save(ruta_destino)
            nuevo.close()
            rutas_generadas.append(ruta_destino)
    return rutas_generadas


def rotar_pdf(ruta_pdf: str, grados: int, ruta_salida: str, paginas: list = None) -> str:
    """
    Rota páginas de un PDF. Si 'paginas' es None, rota todas.
    'paginas' usa numeración empezando en 1.
    grados debe ser 90, 180 o 270 (o -90, etc.).
    """
    with fitz.open(ruta_pdf) as doc:
        indices = range(len(doc)) if paginas is None else [p - 1 for p in paginas]
        for indice in indices:
            if 0 <= indice < len(doc):
                pagina = doc[indice]
                pagina.set_rotation((pagina.rotation + grados) % 360)
        doc.save(ruta_salida)
    return ruta_salida


def extraer_paginas(ruta_pdf: str, pagina_inicio: int, pagina_fin: int, ruta_salida: str) -> str:
    """Extrae un rango de páginas (numeración desde 1, inclusive) a un nuevo PDF."""
    with fitz.open(ruta_pdf) as doc:
        total = len(doc)
        inicio = max(1, pagina_inicio) - 1
        fin = min(total, pagina_fin) - 1
        if inicio > fin:
            raise ValueError("El rango de páginas no es válido.")
        nuevo = fitz.open()
        nuevo.insert_pdf(doc, from_page=inicio, to_page=fin)
        nuevo.save(ruta_salida)
        nuevo.close()
    return ruta_salida


def comprimir_pdf(ruta_pdf: str, ruta_salida: str, calidad_imagen: int = 60) -> dict:
    """
    Comprime un PDF: limpia estructura interna y recomprime las imágenes
    incluidas como JPEG con la calidad indicada (1-100, menor = más compresión).
    Devuelve el tamaño original y el tamaño final.
    """
    tamano_original = os.path.getsize(ruta_pdf)

    with fitz.open(ruta_pdf) as doc:
        for pagina in doc:
            for img_info in pagina.get_images(full=True):
                xref = img_info[0]
                try:
                    pixmap = fitz.Pixmap(doc, xref)
                    if pixmap.n - pixmap.alpha >= 4:  # CMYK -> convertir a RGB
                        pixmap = fitz.Pixmap(fitz.csRGB, pixmap)
                    datos_jpg = pixmap.tobytes("jpeg", jpg_quality=calidad_imagen)
                    doc.update_stream(xref, datos_jpg)
                except Exception:
                    # si una imagen no se puede recomprimir, se deja como está
                    continue
        doc.save(ruta_salida, garbage=4, deflate=True, clean=True)

    tamano_final = os.path.getsize(ruta_salida)
    return {
        "tamano_original": tamano_original,
        "tamano_final": tamano_final,
        "ruta_salida": ruta_salida,
    }


def info_pdf(ruta_pdf: str) -> dict:
    """Información básica de un PDF: número de páginas y si abre correctamente."""
    try:
        with fitz.open(ruta_pdf) as doc:
            return {"valido": True, "paginas": len(doc), "error": None}
    except Exception as error:
        return {"valido": False, "paginas": 0, "error": str(error)}
