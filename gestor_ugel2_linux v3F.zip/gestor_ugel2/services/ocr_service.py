"""
ocr_service.py
--------------
Motor OCR local (100% sin internet) para leer documentos ESCANEADOS:
PDFs que son imágenes y fotos PNG/JPG/TIF, incluidas las que salen de
aplicaciones tipo CamScanner (fotos con sombras, hojas chuecas o torcidas).

Usa Tesseract (programa del sistema) con el idioma español. Antes de
leer, cada página se "limpia" como lo haría una app de escaneo:
  1. Respeta la orientación de la foto (EXIF) y corrige páginas giradas
     90°/180°/270° (detección OSD de Tesseract).
  2. En fotos, recorta la hoja y corrige la perspectiva si detecta sus
     cuatro bordes.
  3. Quita sombras y ajusta el contraste.
  4. Endereza la inclinación leve del texto.
  5. Si la lectura sale dudosa, reintenta con otra binarización y se
     queda con la mejor.

Las páginas de un PDF que YA tienen texto digital no se pasan por OCR:
se usa su texto tal cual (más rápido y exacto).

Importante (honestidad del OCR): una foto muy borrosa o una boleta
antigua descolorida se lee peor. Por eso cada lectura trae una
"confianza" (0-100) y el programa marca para REVISAR lo que salga bajo.
Nunca debe darse por bueno un DNI leído por OCR sin compararlo con el
documento.

No modifica los archivos originales.
"""

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile

import cv2
import numpy as np
import pymupdf as fitz
from PIL import Image, ImageOps

from utils.paths import carpeta_base

IDIOMA = "spa"
EXTENSIONES_IMAGEN = (".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp")
EXTENSIONES_SOPORTADAS = (".pdf",) + EXTENSIONES_IMAGEN
MIN_CARACTERES_TEXTO_DIGITAL = 40
CONFIANZA_MINIMA_BUENA = 72.0
VERSION_CACHE = "1"

PAQUETES_APT = ["tesseract-ocr", "tesseract-ocr-spa", "tesseract-ocr-osd"]

Image.MAX_IMAGE_PIXELS = None  # fotos grandes de celular / escáner


class OcrNoDisponible(Exception):
    """Falta Tesseract o el idioma español."""


class OcrCancelado(Exception):
    """La persona canceló el proceso."""


# ---------------------------------------------------------------
# Estado e instalación del motor
# ---------------------------------------------------------------
def _ruta_tesseract():
    return shutil.which("tesseract")


def estado_ocr() -> dict:
    """
    Revisa si el OCR está listo.
    Devuelve {"disponible": bool, "mensaje": str, "idiomas": [...], "tiene_osd": bool}.
    """
    ruta = _ruta_tesseract()
    if not ruta:
        return {"disponible": False, "idiomas": [], "tiene_osd": False,
                "mensaje": "El motor OCR (Tesseract) no está instalado en este equipo."}
    try:
        salida = subprocess.run([ruta, "--list-langs"], capture_output=True, text=True, timeout=20)
        idiomas = [l.strip() for l in (salida.stdout + salida.stderr).splitlines()[1:] if l.strip()]
    except Exception as error:
        return {"disponible": False, "idiomas": [], "tiene_osd": False,
                "mensaje": f"No se pudo consultar Tesseract: {error}"}
    if IDIOMA not in idiomas:
        return {"disponible": False, "idiomas": idiomas, "tiene_osd": "osd" in idiomas,
                "mensaje": "Tesseract está instalado, pero falta el idioma español."}
    return {"disponible": True, "idiomas": idiomas, "tiene_osd": "osd" in idiomas,
            "mensaje": "Motor OCR listo (español)."}


def instalar_motor_ocr() -> tuple:
    """
    Instala Tesseract + español desde los repositorios del sistema, con la
    ventana GRÁFICA de contraseña de Linux (pkexec): no hace falta terminal.
    Devuelve (ok, mensaje).
    """
    if not shutil.which("pkexec"):
        return False, (
            "No se encontró el pedido de contraseña gráfico del sistema.\n"
            "Abre el \"Gestor de software\" de Linux Mint, busca \"tesseract-ocr-spa\" e instálalo "
            "(también instala el motor). Luego vuelve aquí y presiona \"Volver a comprobar\"."
        )
    comando = (
        "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq || true; "
        "apt-get install -y " + " ".join(PAQUETES_APT)
    )
    try:
        resultado = subprocess.run(["pkexec", "/bin/sh", "-c", comando],
                                   capture_output=True, text=True, timeout=1800)
    except subprocess.TimeoutExpired:
        return False, "La instalación tardó demasiado y se detuvo. Revisa tu conexión a internet."
    except Exception as error:
        return False, f"No se pudo iniciar la instalación: {error}"

    if resultado.returncode in (126, 127):
        return False, "La instalación se canceló (no se ingresó la contraseña)."
    if resultado.returncode != 0:
        detalle = (resultado.stderr or resultado.stdout or "").strip().splitlines()[-3:]
        return False, "No se pudo instalar. Revisa tu conexión a internet.\n" + "\n".join(detalle)
    estado = estado_ocr()
    return estado["disponible"], estado["mensaje"]


_cache_osd = {}


def _tiene_osd() -> bool:
    """Consulta (una sola vez por ejecución) si Tesseract tiene el detector de orientación."""
    ruta = _ruta_tesseract()
    if ruta not in _cache_osd:
        _cache_osd[ruta] = bool(estado_ocr().get("tiene_osd"))
    return _cache_osd[ruta]


def _exigir_ocr():
    estado = estado_ocr()
    if not estado["disponible"]:
        raise OcrNoDisponible(estado["mensaje"])


# ---------------------------------------------------------------
# Carga de imágenes
# ---------------------------------------------------------------
def _pil_a_bgr(imagen: Image.Image) -> np.ndarray:
    rgb = np.array(imagen.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def _cargar_imagenes(ruta: str) -> list:
    """Abre una foto/escaneo y devuelve una lista de imágenes BGR (TIFF multipágina → varias)."""
    resultado = []
    with Image.open(ruta) as imagen:
        n_frames = getattr(imagen, "n_frames", 1)
        for i in range(n_frames):
            if n_frames > 1:
                imagen.seek(i)
            frame = ImageOps.exif_transpose(imagen)  # fotos de celular giradas
            resultado.append(_pil_a_bgr(frame))
    return resultado


def _pagina_pdf_a_gris(pagina, dpi: int = 300, lado_maximo: int = 4500) -> np.ndarray:
    ancho_pt, alto_pt = pagina.rect.width, pagina.rect.height
    zoom = min(dpi / 72.0, lado_maximo / max(ancho_pt, alto_pt, 1))
    pix = pagina.get_pixmap(matrix=fitz.Matrix(zoom, zoom), colorspace=fitz.csGRAY, alpha=False)
    return np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width).copy()


# ---------------------------------------------------------------
# Limpieza de imagen (estilo CamScanner)
# ---------------------------------------------------------------
def _a_gris(img: np.ndarray) -> np.ndarray:
    return img if img.ndim == 2 else cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)


def _ordenar_puntos(pts: np.ndarray) -> np.ndarray:
    pts = pts.reshape(4, 2).astype("float32")
    suma = pts.sum(axis=1)
    resta = np.diff(pts, axis=1).ravel()
    return np.array([pts[np.argmin(suma)], pts[np.argmin(resta)],
                     pts[np.argmax(suma)], pts[np.argmax(resta)]], dtype="float32")


def _cuadrilatero_de_hoja(mascara: np.ndarray, gris: np.ndarray):
    """
    Busca la hoja como el contorno blanco más grande y lo reduce a 4 esquinas.
    Solo acepta hojas "despegadas" del borde de la foto (con mesa visible
    alrededor) y con buen contraste contra el fondo. Si no, devuelve None
    y la imagen se deja como está (así un escaneo normal nunca se recorta).
    """
    alto, ancho = mascara.shape[:2]
    area_img = float(alto * ancho)
    nucleo = cv2.getStructuringElement(cv2.MORPH_RECT, (25, 25))
    cerrada = cv2.morphologyEx(mascara, cv2.MORPH_CLOSE, nucleo)
    contornos, _ = cv2.findContours(cerrada, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contornos:
        return None
    contorno = max(contornos, key=cv2.contourArea)
    area = cv2.contourArea(contorno)
    if area < 0.30 * area_img or area > 0.95 * area_img:
        return None

    # La hoja debe verse rodeada de fondo: si toca 2 o más bordes del cuadro, no es una foto sobre mesa.
    x, y, w, h = cv2.boundingRect(contorno)
    margen = max(4, int(min(alto, ancho) * 0.015))
    lados_tocados = sum([x <= margen, y <= margen, x + w >= ancho - margen, y + h >= alto - margen])
    if lados_tocados >= 2:
        return None

    # Contraste claro entre hoja y fondo.
    relleno = np.zeros_like(mascara)
    cv2.drawContours(relleno, [contorno], -1, 255, thickness=cv2.FILLED)
    dentro, fuera = gris[relleno > 0], gris[relleno == 0]
    if fuera.size == 0 or float(dentro.mean()) - float(fuera.mean()) < 30:
        return None

    casco = cv2.convexHull(contorno)
    perimetro = cv2.arcLength(casco, True)
    for eps in (0.01, 0.02, 0.03, 0.05):
        aprox = cv2.approxPolyDP(casco, eps * perimetro, True)
        if len(aprox) == 4:
            return aprox
    return None


def _enderezar_hoja(bgr: np.ndarray) -> np.ndarray:
    """
    Si la imagen es una FOTO de una hoja sobre una mesa, la recorta y corrige
    la perspectiva. Si no encuentra con seguridad los cuatro bordes de la
    hoja, devuelve la imagen sin tocar (nunca deforma "a ciegas").
    """
    alto, ancho = bgr.shape[:2]
    escala = min(1.0, 1000.0 / max(alto, ancho))
    chica = cv2.resize(bgr, None, fx=escala, fy=escala, interpolation=cv2.INTER_AREA) if escala < 1 else bgr
    gris = cv2.GaussianBlur(cv2.cvtColor(chica, cv2.COLOR_BGR2GRAY), (9, 9), 0)
    umbral, _ = cv2.threshold(gris, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    # Umbral algo más bajo que Otsu: así la parte de la hoja que quedó en sombra no se recorta.
    _, mascara = cv2.threshold(gris, umbral * 0.8, 255, cv2.THRESH_BINARY)

    cuadrilatero = _cuadrilatero_de_hoja(mascara, gris)
    if cuadrilatero is None:
        return bgr

    puntos = _ordenar_puntos(cuadrilatero) / escala
    centro = puntos.mean(axis=0)
    puntos = centro + (puntos - centro) * 1.02  # pequeño margen para no cortar letras del borde
    tl, tr, br, bl = puntos
    ancho_dest = int(max(np.linalg.norm(br - bl), np.linalg.norm(tr - tl)))
    alto_dest = int(max(np.linalg.norm(tr - br), np.linalg.norm(tl - bl)))
    if ancho_dest < 300 or alto_dest < 300 or not 0.45 <= ancho_dest / float(alto_dest) <= 2.2:
        return bgr
    destino = np.array([[0, 0], [ancho_dest - 1, 0], [ancho_dest - 1, alto_dest - 1], [0, alto_dest - 1]],
                       dtype="float32")
    matriz = cv2.getPerspectiveTransform(puntos.astype("float32"), destino)
    return cv2.warpPerspective(bgr, matriz, (ancho_dest, alto_dest),
                               flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REPLICATE)


def _ajustar_tamano(gris: np.ndarray) -> np.ndarray:
    """Lleva la imagen a un tamaño donde Tesseract lee bien (~300 dpi en una hoja A4)."""
    lado = max(gris.shape[:2])
    if lado < 2200:
        factor = 2600.0 / lado
        return cv2.resize(gris, None, fx=factor, fy=factor, interpolation=cv2.INTER_CUBIC)
    if lado > 4600:
        factor = 4200.0 / lado
        return cv2.resize(gris, None, fx=factor, fy=factor, interpolation=cv2.INTER_AREA)
    return gris


def _quitar_sombras(gris: np.ndarray) -> np.ndarray:
    """Parece 'escáner': iguala la iluminación de la hoja y blanquea el fondo."""
    dilatada = cv2.dilate(gris, np.ones((7, 7), np.uint8))
    fondo = cv2.medianBlur(dilatada, 21)
    diferencia = 255 - cv2.absdiff(gris, fondo)
    return cv2.normalize(diferencia, None, 0, 255, cv2.NORM_MINMAX)


def _rotar(gris: np.ndarray, grados: float, borde: int = 255) -> np.ndarray:
    alto, ancho = gris.shape[:2]
    matriz = cv2.getRotationMatrix2D((ancho / 2, alto / 2), grados, 1.0)
    return cv2.warpAffine(gris, matriz, (ancho, alto), flags=cv2.INTER_CUBIC,
                          borderMode=cv2.BORDER_CONSTANT, borderValue=borde)


def _angulo_inclinacion(gris: np.ndarray) -> float:
    """Inclinación del texto en grados (positivo = girar antihorario para enderezar), ±15°."""
    lado = max(gris.shape[:2])
    chica = cv2.resize(gris, None, fx=900.0 / lado, fy=900.0 / lado, interpolation=cv2.INTER_AREA) if lado > 900 else gris
    binaria = cv2.adaptiveThreshold(chica, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 25, 15)
    if cv2.countNonZero(binaria) < 400:
        return 0.0

    def puntaje(angulo):
        perfil = _rotar(binaria, angulo, borde=0).sum(axis=1).astype(np.float64)
        return float(np.sum(np.diff(perfil) ** 2))

    mejor = max(np.arange(-15, 15.1, 1.0), key=puntaje)
    mejor = max(np.arange(mejor - 1.0, mejor + 1.01, 0.1), key=puntaje)
    return 0.0 if abs(mejor) < 0.3 else float(mejor)


def _corregir_giro_90(gris: np.ndarray) -> np.ndarray:
    """Detecta páginas giradas 90/180/270° con el detector de orientación (OSD) de Tesseract."""
    if not _tiene_osd():
        return gris
    try:
        with tempfile.TemporaryDirectory() as tmp:
            ruta = os.path.join(tmp, "osd.png")
            cv2.imwrite(ruta, _reducir_para_osd(gris))
            salida = subprocess.run([_ruta_tesseract(), ruta, "stdout", "--psm", "0", "-l", "osd"],
                                    capture_output=True, text=True, timeout=60)
        rotar = re.search(r"Rotate:\s*(\d+)", salida.stdout)
        confianza = re.search(r"Orientation confidence:\s*([\d.]+)", salida.stdout)
        if rotar and confianza and float(confianza.group(1)) >= 2.0:
            grados = int(rotar.group(1))
            if grados == 90:
                return cv2.rotate(gris, cv2.ROTATE_90_CLOCKWISE)
            if grados == 180:
                return cv2.rotate(gris, cv2.ROTATE_180)
            if grados == 270:
                return cv2.rotate(gris, cv2.ROTATE_90_COUNTERCLOCKWISE)
    except Exception:
        pass
    return gris


def _reducir_para_osd(gris: np.ndarray) -> np.ndarray:
    lado = max(gris.shape[:2])
    if lado > 2400:
        f = 2400.0 / lado
        return cv2.resize(gris, None, fx=f, fy=f, interpolation=cv2.INTER_AREA)
    return gris


def preparar_imagen(img: np.ndarray, es_foto: bool = False) -> np.ndarray:
    """Devuelve la página limpia en escala de grises, lista para leer o guardar."""
    if es_foto and img.ndim == 3:
        img = _enderezar_hoja(img)
    gris = _ajustar_tamano(_a_gris(img))
    gris = _corregir_giro_90(gris)
    gris = _quitar_sombras(gris)
    angulo = _angulo_inclinacion(gris)
    if angulo:
        gris = _rotar(gris, angulo)
    if es_foto:
        # Borra los bordes de la foto (sombras de la orilla de la hoja): confunden la lectura.
        m = max(6, int(min(gris.shape[:2]) * 0.012))
        gris[:m, :] = 255
        gris[-m:, :] = 255
        gris[:, :m] = 255
        gris[:, -m:] = 255
    return gris


def _binarizar(gris: np.ndarray) -> np.ndarray:
    suave = cv2.GaussianBlur(gris, (3, 3), 0)
    return cv2.adaptiveThreshold(suave, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 35, 15)


# ---------------------------------------------------------------
# Lectura con Tesseract
# ---------------------------------------------------------------
def _tesseract_palabras(gris: np.ndarray, psm: int = 3) -> list:
    """Corre Tesseract y devuelve las palabras con posición y confianza."""
    with tempfile.TemporaryDirectory() as tmp:
        ruta = os.path.join(tmp, "pagina.png")
        cv2.imwrite(ruta, gris)
        comando = [_ruta_tesseract(), ruta, "stdout", "-l", IDIOMA, "--oem", "1", "--psm", str(psm),
                   "-c", "preserve_interword_spaces=1", "tsv"]
        salida = subprocess.run(comando, capture_output=True, text=True, encoding="utf-8", timeout=600)
    if salida.returncode != 0:
        raise RuntimeError((salida.stderr or "Tesseract falló").strip())

    palabras = []
    for linea in salida.stdout.splitlines()[1:]:
        campos = linea.split("\t")
        if len(campos) < 12 or campos[0] != "5":
            continue
        texto = campos[11].strip()
        if not texto:
            continue
        try:
            confianza = float(campos[10])
        except ValueError:
            continue
        if confianza < 0:
            continue
        palabras.append({
            "texto": texto, "conf": confianza,
            "x": int(campos[6]), "y": int(campos[7]), "w": int(campos[8]), "h": int(campos[9]),
            "clave": (int(campos[2]), int(campos[3]), int(campos[4])),
        })
    return palabras


def _texto_de_palabras(palabras: list) -> str:
    """Reconstruye el texto respetando líneas y párrafos."""
    lineas = []
    ultimo_bloque_par = None
    ultima_clave = None
    actual = []
    for p in palabras:
        clave = p["clave"]
        bloque_par = clave[:2]
        if clave != ultima_clave:
            if actual:
                lineas.append(" ".join(actual))
            actual = []
            if ultimo_bloque_par is not None and bloque_par != ultimo_bloque_par:
                lineas.append("")
            ultima_clave = clave
            ultimo_bloque_par = bloque_par
        actual.append(p["texto"])
    if actual:
        lineas.append(" ".join(actual))
    return "\n".join(lineas).strip()


def _confianza_media(palabras: list):
    """Confianza media ponderada por la longitud de cada palabra (0-100)."""
    if not palabras:
        return None
    peso = sum(len(p["texto"]) for p in palabras)
    return sum(p["conf"] * len(p["texto"]) for p in palabras) / max(peso, 1)


def _leer_pagina_limpia(gris: np.ndarray, psm: int = 3) -> tuple:
    """Lee una página ya limpia. Devuelve (palabras, confianza)."""
    palabras = _tesseract_palabras(gris, psm)
    confianza = _confianza_media(palabras)
    if confianza is None or confianza < CONFIANZA_MINIMA_BUENA:
        palabras_b = _tesseract_palabras(_binarizar(gris), psm)
        confianza_b = _confianza_media(palabras_b)
        if confianza_b is not None and (confianza is None or confianza_b > confianza):
            return palabras_b, confianza_b
    return palabras, confianza


# ---------------------------------------------------------------
# Caché (para no repetir lecturas de PDFs pesados)
# ---------------------------------------------------------------
def _carpeta_cache() -> str:
    carpeta = os.path.join(carpeta_base(), "temp", "ocr_cache")
    os.makedirs(carpeta, exist_ok=True)
    return carpeta


def _clave_cache(ruta: str, dpi: int, forzar_ocr: bool) -> str:
    sha = hashlib.sha256()
    with open(ruta, "rb") as f:
        for bloque in iter(lambda: f.read(1 << 20), b""):
            sha.update(bloque)
    sha.update(f"|{dpi}|{forzar_ocr}|{VERSION_CACHE}|{IDIOMA}".encode())
    return sha.hexdigest()[:32]


def _cache_leer(clave: str):
    ruta = os.path.join(_carpeta_cache(), clave + ".json")
    if os.path.exists(ruta):
        try:
            with open(ruta, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return None
    return None


def _cache_guardar(clave: str, datos: dict):
    try:
        with open(os.path.join(_carpeta_cache(), clave + ".json"), "w", encoding="utf-8") as f:
            json.dump(datos, f, ensure_ascii=False)
    except OSError:
        pass


# ---------------------------------------------------------------
# API pública: leer archivos
# ---------------------------------------------------------------
def es_archivo_soportado(ruta: str) -> bool:
    return os.path.splitext(ruta)[1].lower() in EXTENSIONES_SOPORTADAS


def _resultado_vacio(ruta: str) -> dict:
    return {"archivo": os.path.basename(ruta), "ruta": ruta, "paginas": [], "texto": "",
            "confianza_media": None, "usa_ocr": False, "error": None}


def _cerrar_resultado(resultado: dict) -> dict:
    resultado["texto"] = "\n\n".join(p["texto"] for p in resultado["paginas"] if p["texto"])
    confs = [(p["confianza"], len(p["texto"])) for p in resultado["paginas"]
             if p["origen"] == "ocr" and p["confianza"] is not None]
    if confs:
        peso = sum(n for _, n in confs) or 1
        resultado["confianza_media"] = round(sum(c * n for c, n in confs) / peso, 1)
    resultado["usa_ocr"] = any(p["origen"] == "ocr" for p in resultado["paginas"])
    return resultado


def leer_archivo(ruta: str, dpi: int = 300, forzar_ocr: bool = False, usar_cache: bool = True,
                 progreso=None, cancelar=None) -> dict:
    """
    Lee el texto de un PDF (digital o escaneado) o de una foto/escaneo (PNG, JPG, TIF...).

    progreso(pagina_actual, total_paginas) se llama al avanzar. cancelar() debe
    devolver True para detener el proceso. Lanza OcrNoDisponible si hace falta OCR
    y el motor no está instalado.

    Devuelve {"archivo", "ruta", "paginas": [{"numero", "texto", "origen": "texto"|"ocr",
    "confianza"}], "texto", "confianza_media", "usa_ocr", "error"}.
    """
    resultado = _resultado_vacio(ruta)
    extension = os.path.splitext(ruta)[1].lower()
    if extension not in EXTENSIONES_SOPORTADAS:
        resultado["error"] = "Tipo de archivo no soportado."
        return resultado

    clave = None
    if usar_cache:
        try:
            clave = _clave_cache(ruta, dpi, forzar_ocr)
            guardado = _cache_leer(clave)
            if guardado:
                resultado["paginas"] = guardado["paginas"]
                return _cerrar_resultado(resultado)
        except OSError:
            clave = None

    def _revisar_cancelacion():
        if cancelar and cancelar():
            raise OcrCancelado()

    if extension == ".pdf":
        with fitz.open(ruta) as doc:
            if doc.needs_pass:
                resultado["error"] = "El PDF tiene contraseña."
                return resultado
            total = len(doc)
            for i in range(total):
                _revisar_cancelacion()
                if progreso:
                    progreso(i + 1, total)
                pagina = doc[i]
                texto_digital = pagina.get_text().strip()
                if len(texto_digital) >= MIN_CARACTERES_TEXTO_DIGITAL and not forzar_ocr:
                    resultado["paginas"].append({"numero": i + 1, "texto": texto_digital,
                                                 "origen": "texto", "confianza": None})
                    continue
                _exigir_ocr()
                gris = preparar_imagen(_pagina_pdf_a_gris(pagina, dpi), es_foto=False)
                palabras, confianza = _leer_pagina_limpia(gris)
                resultado["paginas"].append({
                    "numero": i + 1, "texto": _texto_de_palabras(palabras), "origen": "ocr",
                    "confianza": None if confianza is None else round(confianza, 1)})
    else:
        _exigir_ocr()
        imagenes = _cargar_imagenes(ruta)
        for i, img in enumerate(imagenes):
            _revisar_cancelacion()
            if progreso:
                progreso(i + 1, len(imagenes))
            gris = preparar_imagen(img, es_foto=True)
            palabras, confianza = _leer_pagina_limpia(gris)
            resultado["paginas"].append({
                "numero": i + 1, "texto": _texto_de_palabras(palabras), "origen": "ocr",
                "confianza": None if confianza is None else round(confianza, 1)})

    if clave:
        _cache_guardar(clave, {"paginas": resultado["paginas"]})
    return _cerrar_resultado(resultado)


# ---------------------------------------------------------------
# PDF buscable (con texto seleccionable) a partir de un escaneo
# ---------------------------------------------------------------
def _agregar_texto_invisible(pagina_pdf, palabras: list, escala: float):
    for p in palabras:
        texto = p["texto"]
        try:
            ancho_natural = fitz.get_text_length(texto, fontname="helv", fontsize=1)
        except Exception:
            continue
        if ancho_natural <= 0:
            continue
        tamano = (p["w"] * escala) / ancho_natural
        tamano = max(p["h"] * escala * 0.5, min(tamano, p["h"] * escala * 1.3))
        try:
            pagina_pdf.insert_text(
                fitz.Point(p["x"] * escala, (p["y"] + p["h"] * 0.8) * escala),
                texto, fontsize=max(tamano, 3), fontname="helv", render_mode=3,
            )
        except Exception:
            continue


def crear_pdf_buscable(ruta_entrada: str, ruta_salida: str, dpi: int = 300, calidad_jpeg: int = 65,
                       compacto: bool = False, progreso=None, cancelar=None) -> dict:
    """
    Convierte un escaneo (PDF imagen o foto) en un PDF con texto seleccionable y
    buscable, y de paso limpio (sin sombras, derecho) y liviano. Las páginas que
    ya tenían texto digital se copian sin cambios. Con compacto=True las imágenes
    se guardan a ~200 dpi (archivo más liviano; el texto se lee igual de bien).
    Devuelve {"ruta_salida", "paginas", "paginas_ocr", "confianza_media"}.
    """
    _exigir_ocr()
    extension = os.path.splitext(ruta_entrada)[1].lower()
    if extension not in EXTENSIONES_SOPORTADAS:
        raise ValueError("Tipo de archivo no soportado.")

    nuevo = fitz.open()
    paginas_ocr = 0
    confianzas = []

    def _agregar_imagen(gris: np.ndarray):
        nonlocal paginas_ocr
        palabras, confianza = _leer_pagina_limpia(gris)
        alto, ancho = gris.shape[:2]
        escala = 72.0 / dpi
        pagina_pdf = nuevo.new_page(width=ancho * escala, height=alto * escala)
        para_guardar = cv2.resize(gris, None, fx=0.67, fy=0.67, interpolation=cv2.INTER_AREA) if compacto else gris
        ok, buffer = cv2.imencode(".jpg", para_guardar, [cv2.IMWRITE_JPEG_QUALITY, calidad_jpeg])
        pagina_pdf.insert_image(pagina_pdf.rect, stream=buffer.tobytes())
        _agregar_texto_invisible(pagina_pdf, palabras, escala)
        paginas_ocr += 1
        if confianza is not None:
            confianzas.append(confianza)

    try:
        if extension == ".pdf":
            with fitz.open(ruta_entrada) as origen:
                total = len(origen)
                for i in range(total):
                    if cancelar and cancelar():
                        raise OcrCancelado()
                    if progreso:
                        progreso(i + 1, total)
                    pagina = origen[i]
                    if len(pagina.get_text().strip()) >= MIN_CARACTERES_TEXTO_DIGITAL:
                        nuevo.insert_pdf(origen, from_page=i, to_page=i)
                        continue
                    _agregar_imagen(preparar_imagen(_pagina_pdf_a_gris(pagina, dpi), es_foto=False))
        else:
            imagenes = _cargar_imagenes(ruta_entrada)
            for i, img in enumerate(imagenes):
                if cancelar and cancelar():
                    raise OcrCancelado()
                if progreso:
                    progreso(i + 1, len(imagenes))
                _agregar_imagen(preparar_imagen(img, es_foto=True))
        nuevo.save(ruta_salida, garbage=3, deflate=True)
        total_paginas = len(nuevo)
    finally:
        nuevo.close()

    return {"ruta_salida": ruta_salida, "paginas": total_paginas, "paginas_ocr": paginas_ocr,
            "confianza_media": round(sum(confianzas) / len(confianzas), 1) if confianzas else None}
