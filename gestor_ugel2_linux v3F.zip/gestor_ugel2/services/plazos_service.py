"""
plazos_service.py
------------------
Control de Plazos ("Semáforo"): calcula cuántos días han pasado desde
la fecha de ingreso de cada expediente hasta hoy.

Reglas:
- Por defecto se cuentan DÍAS HÁBILES (LPAG): se descuentan sábados,
  domingos, feriados nacionales y los días no laborables/feriados
  locales que estén activos (ver dias_habiles_service.py). El día de
  ingreso no cuenta.
- Opcionalmente se puede usar el modo DÍAS CALENDARIO (cuenta todos
  los días, de corrido). En ambos casos el resultado trae las dos
  cifras (dias_calendario y dias_habiles).
- Opcionalmente se indica un plazo legal en días hábiles (por ejemplo
  30): entonces cada fila trae la fecha de vencimiento y los días
  hábiles que restan (negativo = ya venció).
- Si el estado del expediente es "ATENDIDO" (sin distinguir mayúsculas
  ni espacios de más), los días transcurridos quedan en blanco: el
  expediente ya se resolvió, así que el conteo se detiene ahí.
- Semáforo:
    Verde   -> 0 a 7 días
    Amarillo -> 8 a 15 días
    Rojo    -> más de 15 días
  Los umbrales se aplican a los días del modo elegido (hábiles por
  defecto). Un expediente "ATENDIDO" no lleva color.

No modifica el Excel original: solo lo lee.
"""

import os
from datetime import datetime

import openpyxl

from services.dias_habiles_service import Calendario

COLUMNAS_CLAVE = {
    "EXPEDIENTE": "expediente",
    "N_EXPEDIENTE": "expediente",
    "NRO_EXPEDIENTE": "expediente",
    "DNI": "dni",
    "NOMBRE": "nombre",
    "FECHA_INGRESO": "fecha_ingreso",
    "FECHA": "fecha_ingreso",
    "ESTADO": "estado",
}

VERDE = "verde"
AMARILLO = "amarillo"
ROJO = "rojo"


def _detectar_columnas(hoja) -> dict:
    """Ubica en qué columna está cada campo clave, leyendo la primera fila."""
    columnas = {}
    primera_fila = next(hoja.iter_rows(min_row=1, max_row=1), [])
    for celda in primera_fila:
        if celda.value is None:
            continue
        texto = str(celda.value).strip().upper()
        if texto in COLUMNAS_CLAVE:
            clave = COLUMNAS_CLAVE[texto]
            # Si ya se encontró una columna para esta clave, no la pisa
            # (por ejemplo, si el Excel tuviera tanto FECHA como
            # FECHA_INGRESO, se respeta la primera que aparezca).
            columnas.setdefault(clave, celda.column - 1)
    return columnas


def _parsear_fecha(valor):
    """Convierte un valor de celda en un objeto datetime, o None si no se puede interpretar."""
    if valor is None:
        return None
    if isinstance(valor, datetime):
        return valor
    texto = str(valor).strip()
    formatos = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d")
    for formato in formatos:
        try:
            return datetime.strptime(texto, formato)
        except ValueError:
            continue
    return None


def _es_atendido(valor_estado) -> bool:
    if valor_estado is None:
        return False
    return str(valor_estado).strip().upper() == "ATENDIDO"


def _clasificar(dias: int) -> str:
    if dias <= 7:
        return VERDE
    if dias <= 15:
        return AMARILLO
    return ROJO


MODO_HABILES = "habiles"
MODO_CALENDARIO = "calendario"


def calcular_plazos(ruta_excel: str, hoja: str, modo: str = MODO_HABILES,
                    plazo_legal: int = None, calendario: Calendario = None,
                    hoy: datetime = None) -> dict:
    """
    Lee la hoja indicada y calcula, para cada fila, los días
    transcurridos desde la fecha de ingreso hasta hoy, y el color de
    semáforo correspondiente.

    Devuelve {"error": "..."} si falta la columna de fecha, o si no
    se pudo abrir el archivo. En caso contrario, devuelve:
        {"filas": [ {...}, ... ], "columnas_detectadas": {...}}

    Cada fila del resultado trae:
        numero_fila, expediente, dni, nombre, fecha_ingreso (texto),
        estado, dias_transcurridos (días del modo elegido), dias_calendario,
        dias_habiles, fecha_vencimiento (texto dd/mm/aaaa o ""),
        dias_restantes (hábiles, negativo = vencido, o None), color,
        observacion (texto si algo no se pudo calcular)
    """
    try:
        libro = openpyxl.load_workbook(ruta_excel, read_only=True, data_only=True)
    except Exception as error:
        return {"error": f"No se pudo abrir el archivo: {error}"}

    if hoja not in libro.sheetnames:
        libro.close()
        return {"error": f"La hoja \"{hoja}\" no existe en este archivo."}

    hoja_activa = libro[hoja]
    columnas = _detectar_columnas(hoja_activa)

    if "fecha_ingreso" not in columnas:
        libro.close()
        return {
            "error": (
                "No se encontró una columna de fecha de ingreso. "
                "Usa el encabezado FECHA_INGRESO o FECHA en la primera fila."
            )
        }

    hoy = hoy or datetime.now()
    calendario = calendario or Calendario()
    por_habiles = modo != MODO_CALENDARIO
    filas_resultado = []

    for numero_fila, fila in enumerate(hoja_activa.iter_rows(min_row=2, values_only=True), start=2):
        if fila is None or all(v is None for v in fila):
            continue

        def obtener(campo):
            idx = columnas.get(campo)
            if idx is None or idx >= len(fila):
                return None
            return fila[idx]

        expediente = obtener("expediente")
        dni = obtener("dni")
        nombre = obtener("nombre")
        estado_valor = obtener("estado")
        fecha_valor = obtener("fecha_ingreso")
        fecha_ingreso = _parsear_fecha(fecha_valor)

        dias = None
        dias_cal = None
        dias_hab = None
        vencimiento = ""
        restantes = None
        color = None
        observacion = ""

        if _es_atendido(estado_valor):
            observacion = "Atendido (conteo detenido)"
        elif fecha_ingreso is None:
            observacion = "Fecha de ingreso no reconocida"
        else:
            diferencia = (hoy.date() - fecha_ingreso.date()).days
            if diferencia < 0:
                observacion = "La fecha de ingreso está en el futuro: revisar el dato"
            else:
                dias_cal = diferencia
                dias_hab = calendario.contar_habiles(fecha_ingreso.date(), hoy.date())
                dias = dias_hab if por_habiles else dias_cal
                color = _clasificar(dias)
                if plazo_legal:
                    fecha_venc = calendario.sumar_habiles(fecha_ingreso.date(), plazo_legal)
                    vencimiento = fecha_venc.strftime("%d/%m/%Y")
                    restantes = calendario.restar_habiles_entre(hoy.date(), fecha_venc)
                    if restantes < 0:
                        observacion = f"VENCIDO hace {-restantes} día(s) hábil(es)"

        filas_resultado.append({
            "numero_fila": numero_fila,
            "expediente": expediente,
            "dni": dni,
            "nombre": nombre,
            "fecha_ingreso": fecha_valor,
            "estado": estado_valor,
            "dias_transcurridos": dias,
            "dias_calendario": dias_cal,
            "dias_habiles": dias_hab,
            "fecha_vencimiento": vencimiento,
            "dias_restantes": restantes,
            "color": color,
            "observacion": observacion,
        })

    libro.close()
    return {"filas": filas_resultado, "columnas_detectadas": columnas,
            "modo": "habiles" if por_habiles else "calendario", "plazo_legal": plazo_legal}
