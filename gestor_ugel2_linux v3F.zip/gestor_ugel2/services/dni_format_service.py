"""
dni_format_service.py
-----------------------
Protege los DNI/RUC de una columna para que Excel nunca les borre el
cero inicial (por ejemplo, que "01234567" no se convierta en 1234567).

El método correcto (comprobado) es escribir el valor como texto puro y
poner el formato de la celda en "@" (Texto). El truco del apóstrofe
(') solo funciona cuando tú lo escribes a mano dentro de Excel; hecho
por código, el apóstrofe queda como un carácter visible más dentro del
valor, y el formato de la celda se queda en "General" — es decir, no
protege nada. Por eso este módulo NO usa apóstrofes.

Seguridad: esta función NUNCA modifica tu archivo original. Siempre
guarda el resultado en un archivo nuevo. Si en algún momento se agrega
una opción para sobrescribir el original, primero se hace un respaldo
automático (ver backup_service.py).
"""

import os
from datetime import datetime

import openpyxl


def proteger_columna_como_texto(ruta_excel: str, hoja: str, nombre_columna: str, ruta_salida: str = None) -> dict:
    """
    Abre el Excel, ubica la columna por su encabezado (por ejemplo,
    "DNI" o "RUC"), y para cada fila:
      - Si el valor es un número (Excel lo interpretó como número,
        perdiendo el cero inicial), lo vuelve a armar como texto,
        rellenando con ceros a la izquierda según la longitud esperada
        (8 dígitos para DNI, 11 para RUC — detectado automáticamente
        por el valor más común en esa columna, o puedes indicarlo tú).
      - Aplica el formato de celda "@" (Texto) para que, de ahí en
        adelante, Excel no lo vuelva a convertir en número.

    Guarda el resultado en ruta_salida (si no se indica, agrega
    "_protegido" al nombre original) y NUNCA toca el archivo original.

    Devuelve un resumen: cuántas celdas se corrigieron y la ruta final.
    """
    libro = openpyxl.load_workbook(ruta_excel, data_only=True)  # sin read_only: aquí sí necesitamos escribir
    if hoja not in libro.sheetnames:
        libro.close()
        return {"error": f"La hoja \"{hoja}\" no existe en este archivo."}

    hoja_activa = libro[hoja]

    columna_indice = None
    for celda in next(hoja_activa.iter_rows(min_row=1, max_row=1), []):
        if celda.value is not None and str(celda.value).strip().upper() == nombre_columna.strip().upper():
            columna_indice = celda.column
            break

    if columna_indice is None:
        libro.close()
        return {"error": f"No se encontró la columna \"{nombre_columna}\" en la primera fila."}

    # Detectar la longitud esperada (8 para DNI, 11 para RUC) a partir
    # del valor más largo ya existente como texto en esa columna, para
    # no adivinar a ciegas si la oficina usa otro tipo de código.
    longitudes_vistas = []
    for fila in hoja_activa.iter_rows(min_row=2):
        valor = fila[columna_indice - 1].value
        if valor is None:
            continue
        texto = str(valor)
        if texto.endswith(".0"):
            texto = texto[:-2]
        if texto.isdigit():
            longitudes_vistas.append(len(texto))
    longitud_objetivo = max(longitudes_vistas) if longitudes_vistas else 8

    corregidos = 0
    total_con_dato = 0

    for fila in hoja_activa.iter_rows(min_row=2):
        celda = fila[columna_indice - 1]
        if celda.value is None:
            continue
        total_con_dato += 1

        valor_original = celda.value
        texto = str(valor_original)
        if texto.endswith(".0"):
            texto = texto[:-2]
        texto = texto.strip()

        if not texto.isdigit():
            continue  # no es un código numérico; no se toca (no se adivina)

        texto_relleno = texto.zfill(longitud_objetivo)

        # Solo cuenta como "corregido" si de verdad cambió algo
        # (el valor estaba como número, o le faltaban ceros).
        if str(valor_original) != texto_relleno or celda.number_format != "@":
            corregidos += 1

        celda.value = texto_relleno
        celda.number_format = "@"

    if ruta_salida is None:
        base, ext = os.path.splitext(ruta_excel)
        ruta_salida = f"{base}_protegido{ext}"

    libro.save(ruta_salida)
    libro.close()

    return {
        "ruta_salida": ruta_salida,
        "columna": nombre_columna,
        "longitud_objetivo": longitud_objetivo,
        "celdas_con_dato": total_con_dato,
        "celdas_corregidas": corregidos,
    }
