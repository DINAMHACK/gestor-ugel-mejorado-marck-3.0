"""
catalogo_sbn_service.py
------------------------
Validador del Catálogo Nacional de Bienes Muebles del Estado (SBN) / SIGA.

Estructura del Código Patrimonial de 12 dígitos:
    GG CC FFFF IIII
    ├──────────┤ └── 4 dígitos finales: ítem / correlativo del bien
    └ 8 dígitos = código del CATÁLOGO (Grupo 2 + Clase 2 + Familia 4),
      por ejemplo 74640592 = ARMARIO DE MADERA.

Un código solo es aceptado por SIGA-MP/SBN si sus primeros 8 dígitos
existen en el catálogo oficial. Este módulo compara contra una lista
local (datos/catalogo_sbn.csv) que la persona IMPORTA desde el archivo
oficial (Excel, CSV o PDF) con el botón "Importar catálogo SBN".

IMPORTANTE: el programa no trae el catálogo incluido (la SBN lo actualiza
con fascículos nuevos). Mientras no se importe, la validación se limita a
la forma (12 dígitos) y avisa que el catálogo no está cargado. Si se
importa solo una parte, los códigos no encontrados se marcan como
"catálogo parcial": pueden existir en la parte que falta.
"""

import csv
import os
import re

import openpyxl

from utils.paths import carpeta_base

RUTA_CATALOGO = os.path.join(carpeta_base(), "datos", "catalogo_sbn.csv")
UMBRAL_CATALOGO_COMPLETO = 1000  # menos códigos que esto = se considera parcial

_cache = {"mtime": None, "datos": {}}


def _cargar() -> dict:
    if not os.path.exists(RUTA_CATALOGO):
        return {}
    mtime = os.path.getmtime(RUTA_CATALOGO)
    if _cache["mtime"] == mtime:
        return _cache["datos"]
    datos = {}
    with open(RUTA_CATALOGO, "r", encoding="utf-8-sig", newline="") as f:
        for fila in csv.reader(f):
            if len(fila) >= 2 and re.fullmatch(r"\d{8}", fila[0].strip()):
                datos[fila[0].strip()] = fila[1].strip()
    _cache["mtime"], _cache["datos"] = mtime, datos
    return datos


def estado_catalogo() -> dict:
    """{"cargado": bool, "cantidad": n, "parcial": bool, "mensaje": str}"""
    n = len(_cargar())
    if n == 0:
        return {"cargado": False, "cantidad": 0, "parcial": False,
                "mensaje": "Catálogo SBN no cargado: solo se valida que el código tenga 12 dígitos."}
    parcial = n < UMBRAL_CATALOGO_COMPLETO
    texto = f"Catálogo SBN cargado: {n:,} códigos".replace(",", ".")
    if parcial:
        texto += " (parcial: un código \"no encontrado\" podría existir en la parte que falta)"
    return {"cargado": True, "cantidad": n, "parcial": parcial, "mensaje": texto}


def _extraer_pares_de_fila(celdas) -> list:
    """De una fila de tabla saca (código_8, denominación) si hay un código de 8+ dígitos."""
    textos = [str(c).strip() for c in celdas if c is not None and str(c).strip()]
    for i, t in enumerate(textos):
        limpio = re.sub(r"[\s\-.]", "", t)
        if re.fullmatch(r"\d{8}(\d{4})?", limpio):
            resto = [x for j, x in enumerate(textos) if j != i and not re.fullmatch(r"[\d\s\-.]+", x)]
            denominacion = max(resto, key=len) if resto else ""
            return [(limpio[:8], denominacion.upper())]
    return []


def _leer_origen(ruta: str) -> list:
    extension = os.path.splitext(ruta)[1].lower()
    pares = []
    if extension in (".xlsx", ".xlsm"):
        libro = openpyxl.load_workbook(ruta, read_only=True, data_only=True)
        for hoja in libro.worksheets:
            for fila in hoja.iter_rows(values_only=True):
                pares += _extraer_pares_de_fila(fila)
        libro.close()
    elif extension in (".csv", ".txt"):
        with open(ruta, "r", encoding="utf-8-sig", errors="replace", newline="") as f:
            muestra = f.read(4096)
            f.seek(0)
            try:
                dialecto = csv.Sniffer().sniff(muestra, delimiters=",;\t|")
            except csv.Error:
                dialecto = csv.excel
            for fila in csv.reader(f, dialecto):
                pares += _extraer_pares_de_fila(fila)
    elif extension == ".pdf":
        import pdfplumber
        patron = re.compile(r"^\s*(\d{8})\s+(.{3,})$")
        with pdfplumber.open(ruta) as pdf:
            for pagina in pdf.pages:
                for linea in (pagina.extract_text() or "").splitlines():
                    m = patron.match(linea)
                    if m:
                        pares.append((m.group(1), m.group(2).strip().upper()))
    else:
        raise ValueError("Formato no soportado. Usa Excel (.xlsx), CSV o PDF.")
    return pares


def importar_catalogo(ruta_origen: str, reemplazar: bool = False) -> dict:
    """
    Agrega (o reemplaza) códigos del catálogo desde un archivo oficial.
    Devuelve {"leidos", "nuevos", "total"} o {"error": "..."}.
    """
    try:
        pares = _leer_origen(ruta_origen)
    except Exception as error:
        return {"error": f"No se pudo leer el archivo: {error}"}
    if not pares:
        return {"error": ("No se encontraron códigos de catálogo (8 dígitos) en el archivo. "
                          "Si es un PDF escaneado (imagen), primero conviértelo a PDF buscable "
                          "en Herramientas PDF → Leer escaneados (OCR).")}

    actuales = {} if reemplazar else dict(_cargar())
    antes = len(actuales)
    for codigo, denominacion in pares:
        if codigo not in actuales or (denominacion and not actuales[codigo]):
            actuales[codigo] = denominacion

    os.makedirs(os.path.dirname(RUTA_CATALOGO), exist_ok=True)
    with open(RUTA_CATALOGO, "w", encoding="utf-8-sig", newline="") as f:
        escritor = csv.writer(f)
        escritor.writerow(["codigo", "denominacion"])
        for codigo in sorted(actuales):
            escritor.writerow([codigo, actuales[codigo]])
    _cache["mtime"] = None
    return {"leidos": len(pares), "nuevos": len(actuales) - antes, "total": len(actuales)}


def validar_codigo(codigo12: str) -> dict:
    """
    Valida un código ya limpio de 12 dígitos.
    estado: "OK" | "NO_ENCONTRADO" | "SIN_CATALOGO".
    Devuelve también catalogo (8 dígitos), correlativo (4), denominacion y detalle.
    """
    catalogo = _cargar()
    base, correlativo = codigo12[:8], codigo12[8:]
    resultado = {"catalogo": base, "correlativo": correlativo, "denominacion": "",
                 "estado": "SIN_CATALOGO", "detalle": "Catálogo no cargado"}
    if not catalogo:
        return resultado
    if base in catalogo:
        resultado.update(estado="OK", denominacion=catalogo[base], detalle="")
        if correlativo == "0000":
            resultado["detalle"] = "Correlativo 0000: revisar"
        return resultado

    resultado["estado"] = "NO_ENCONTRADO"
    if not any(c.startswith(base[:2]) for c in catalogo):
        resultado["detalle"] = f"El grupo {base[:2]} no existe en el catálogo"
    elif not any(c.startswith(base[:4]) for c in catalogo):
        resultado["detalle"] = f"La clase {base[:4]} no existe en el catálogo"
    elif not any(c.startswith(base[:4]) and c[4:8] == base[4:8] for c in catalogo):
        resultado["detalle"] = "La familia/ítem no existe en el catálogo"
    return resultado
