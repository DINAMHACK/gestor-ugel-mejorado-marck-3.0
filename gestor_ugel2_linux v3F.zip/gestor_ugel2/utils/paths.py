"""
paths.py
--------
Resuelve la carpeta base del programa de forma robusta, sin importar
si se ejecuta con "python main.py" o como un .exe empaquetado con
PyInstaller. Esto evita que carpetas como reports/, backups/ o temp/
terminen creándose en un lugar inesperado según desde dónde se abra
el programa (por ejemplo, con un acceso directo cuya carpeta de
inicio sea distinta a la del proyecto).
"""

import os
import sys


def carpeta_base() -> str:
    """
    Carpeta donde vive el programa:
    - Si se ejecuta empaquetado (.exe con PyInstaller), es la carpeta
      donde está el .exe.
    - Si se ejecuta con "python main.py", es la carpeta raíz del
      proyecto (donde está main.py).
    """
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    # Este archivo vive en gestor_ugel/utils/paths.py -> subir un nivel
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def ruta_absoluta(relativa: str) -> str:
    """
    Convierte una ruta relativa (como las que se guardan en
    settings.json, por ejemplo "reports" o "backups") en una ruta
    absoluta anclada a la carpeta del programa. Si ya es una ruta
    absoluta (por ejemplo, una carpeta que el usuario eligió con el
    selector de carpetas), la deja tal cual.
    """
    if not relativa:
        return relativa
    if os.path.isabs(relativa):
        return relativa
    return os.path.join(carpeta_base(), relativa)
