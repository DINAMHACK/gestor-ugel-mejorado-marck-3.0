"""
helpers.py
----------
Funciones auxiliares de uso general: hash de archivos (para detectar
duplicados reales, no solo por nombre), formato de tamaños, y limpieza
de nombres de archivo.
"""

import hashlib
import os
import re
import unicodedata


def calcular_hash_archivo(ruta: str, bloque: int = 65536) -> str:
    """Calcula el hash SHA-256 de un archivo (para detectar duplicados exactos)."""
    sha256 = hashlib.sha256()
    with open(ruta, "rb") as f:
        for fragmento in iter(lambda: f.read(bloque), b""):
            sha256.update(fragmento)
    return sha256.hexdigest()


def tamano_legible(bytes_size: int) -> str:
    """Convierte bytes a un texto legible (KB, MB, GB)."""
    tamano = float(bytes_size)
    for unidad in ("B", "KB", "MB", "GB"):
        if tamano < 1024:
            return f"{tamano:.1f} {unidad}"
        tamano /= 1024
    return f"{tamano:.1f} TB"


def nombre_archivo_seguro(nombre: str) -> str:
    """Elimina caracteres problemáticos de un nombre de archivo propuesto."""
    nombre = nombre.strip()
    nombre = re.sub(r'[<>:"/\\|?*]', "_", nombre)
    return nombre


ESPACIOS_INVISIBLES = ("\u00a0", "\u200b", "\t")


def limpiar_texto_oculto(valor) -> str:
    """
    Limpia un valor de celda de Excel de caracteres invisibles que
    suelen venir de plataformas del Estado (espacio de no separación
    \\xa0, espacio de ancho cero, tabulaciones), colapsa espacios
    dobles, y recorta bordes. Conserva tildes, ñ y puntuación normal:
    esto NO es para nombres de archivo (nombre_archivo_seguro ya
    existe para eso), es para el CONTENIDO de texto que se compara,
    busca o separa.

    Importante: str.strip() de Python ya elimina \\xa0 al inicio/final
    por sí solo (se probó explícitamente). El problema real que esto
    soluciona es el espacio invisible que queda EN MEDIO del texto
    (por ejemplo, "JUAN\\xa0PEREZ"), que rompe comparaciones y
    búsquedas exactas aunque el DNI y los strip() normales no se vean
    afectados.
    """
    if valor is None:
        return ""

    texto = str(valor)

    if texto.endswith(".0") and texto[:-2].isdigit():
        texto = texto[:-2]

    for espacio_raro in ESPACIOS_INVISIBLES:
        texto = texto.replace(espacio_raro, " ")

    texto = "".join(c for c in texto if unicodedata.category(c)[0] != "C")
    texto = re.sub(r" {2,}", " ", texto)

    return texto.strip()


def listar_archivos(carpeta: str, extensiones=None) -> list:
    """Lista archivos de una carpeta (no subcarpetas), filtrando por extensión si se indica."""
    resultado = []
    if not os.path.isdir(carpeta):
        return resultado
    for nombre in os.listdir(carpeta):
        ruta = os.path.join(carpeta, nombre)
        if not os.path.isfile(ruta):
            continue
        if extensiones:
            _, ext = os.path.splitext(nombre)
            if ext.lower() not in extensiones:
                continue
        resultado.append(ruta)
    return resultado
