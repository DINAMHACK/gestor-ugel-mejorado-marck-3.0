"""
logger.py
---------
Registro de actividad muy simple: qué hizo la aplicación y cuándo.
Esto es solo una bitácora de trabajo (para que tú sepas qué procesaste),
no un mecanismo de seguridad ni de control de acceso.
"""

import os
from datetime import datetime

from utils.paths import carpeta_base

LOG_PATH = os.path.join(carpeta_base(), "temp", "actividad.log")


def registrar(mensaje: str) -> None:
    """Agrega una línea con fecha/hora al archivo de actividad."""
    os.makedirs(os.path.dirname(LOG_PATH), exist_ok=True)
    marca = datetime.now().strftime("%d/%m/%Y %H:%M")
    linea = f"{marca}\n{mensaje}\n\n"
    with open(LOG_PATH, "a", encoding="utf-8") as f:
        f.write(linea)


def leer_actividad(ultimas: int = 50) -> str:
    """Devuelve las últimas líneas del log de actividad (texto plano)."""
    if not os.path.exists(LOG_PATH):
        return "(Sin actividad registrada todavía)"
    with open(LOG_PATH, "r", encoding="utf-8") as f:
        contenido = f.read()
    bloques = [b for b in contenido.split("\n\n") if b.strip()]
    return "\n\n".join(bloques[-ultimas:])
