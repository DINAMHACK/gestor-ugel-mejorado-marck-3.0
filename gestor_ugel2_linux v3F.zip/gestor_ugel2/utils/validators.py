"""
validators.py
-------------
Funciones puras de validación, reutilizadas por el módulo Excel y por el
validador general. No adivinan ni corrigen datos por su cuenta: solo
indican si un valor cumple la regla o no.
"""

import re
from datetime import datetime

DNI_REGEX = re.compile(r"^\d{8}$")
DNI_REGEX_ANTIGUO = re.compile(r"^\d{7}$")


def es_dni_valido(valor) -> bool:
    """DNI: exactamente 8 dígitos numéricos, sin espacios ni letras."""
    if valor is None:
        return False
    texto = str(valor).strip()
    return bool(DNI_REGEX.match(texto))


def es_dni_posible_formato_antiguo(valor) -> bool:
    """
    Un DNI de exactamente 7 dígitos no es automáticamente un error: en
    el Perú, algunos documentos muy antiguos (de personas mayores,
    como docentes cesantes) tienen 7 dígitos porque se emitieron antes
    de que la numeración llegara a 8. PERO tampoco se puede aceptar
    a ciegas como válido: un DNI real de 8 dígitos al que el
    digitador le faltó un número se ve exactamente igual. Por eso esto
    NO reemplaza a es_dni_valido(): sirve para marcar el caso como un
    AVISO a revisar, no como un error ni como un válido silencioso.
    """
    if valor is None:
        return False
    texto = str(valor).strip()
    return bool(DNI_REGEX_ANTIGUO.match(texto))


def es_texto_no_vacio(valor) -> bool:
    """Campo de texto (por ejemplo NOMBRE) que no debe estar vacío."""
    if valor is None:
        return False
    return len(str(valor).strip()) > 0


def es_tipo_documento_valido(valor, tipos_validos) -> bool:
    """El tipo de documento debe estar dentro de la lista configurada."""
    if valor is None:
        return False
    return str(valor).strip().upper() in {t.upper() for t in tipos_validos}


def es_fecha_valida(valor) -> bool:
    """Acepta fechas en formato DD/MM/AAAA o como fecha nativa de Excel."""
    if valor is None:
        return False
    if isinstance(valor, datetime):
        return True
    texto = str(valor).strip()
    formatos = ("%d/%m/%Y", "%d-%m-%Y", "%Y-%m-%d")
    for formato in formatos:
        try:
            datetime.strptime(texto, formato)
            return True
        except ValueError:
            continue
    return False


def es_estado_valido(valor, estados_validos) -> bool:
    """El estado debe estar dentro de la lista configurada."""
    if valor is None:
        return False
    return str(valor).strip().upper() in {e.upper() for e in estados_validos}


def normalizar_dni(valor) -> str:
    """Devuelve el DNI como texto limpio, sin decimales ni espacios."""
    texto = str(valor).strip()
    if texto.endswith(".0"):
        texto = texto[:-2]
    return texto
