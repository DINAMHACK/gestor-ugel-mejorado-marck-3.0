"""
main.py
-------
Punto de entrada de Gestor Documental UGEL.

La aplicación abre directamente la ventana principal: no existe
pantalla de usuario/contraseña ni ningún control de acceso, ya que se
trata de una herramienta de uso local y personal.

Toda la información se queda en archivos Excel (.xlsx): no se usa
ninguna base de datos, para que el formato sea siempre el mismo que
usa el resto de la oficina.
"""

import os
import sys

# Permite ejecutar "python main.py" desde cualquier ubicación
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.config_manager import cargar_config
from ui.main_window import VentanaPrincipal


def main():
    config = cargar_config()

    app = VentanaPrincipal(config)
    app.mainloop()


if __name__ == "__main__":
    main()
