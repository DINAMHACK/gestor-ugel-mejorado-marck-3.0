@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   Gestor Documental UGEL
echo ============================================
echo.

where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: no se encontro Python instalado, o no quedo agregado al PATH.
    echo.
    echo Instala Python desde https://www.python.org/downloads/
    echo y marca la casilla "Add Python.exe to PATH" durante la instalacion.
    echo.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\activate.bat" (
    echo Creando el entorno del programa por primera vez...
    python -m venv .venv
    if errorlevel 1 (
        echo.
        echo ERROR: no se pudo crear el entorno virtual.
        pause
        exit /b 1
    )
)

call ".venv\Scripts\activate.bat"

if not exist ".venv\instalado.ok" (
    echo.
    echo Instalando dependencias por primera vez...
    echo Esto puede tardar varios minutos y descargar unos 100-150 MB.
    echo Solo pasa una vez. No cierres esta ventana.
    echo.

    python -m pip install --upgrade pip >nul
    pip install -r requirements.txt
    if errorlevel 1 (
        echo.
        echo ERROR: no se pudieron instalar las dependencias.
        echo Revisa tu conexion a internet y vuelve a abrir este archivo para reintentar.
        echo Si el problema sigue, copia el mensaje de arriba tal cual y comunicalo.
        echo.
        pause
        exit /b 1
    )

    echo ok > ".venv\instalado.ok"
    echo.
    echo Instalacion completa.
    echo.
)

echo Abriendo Gestor Documental UGEL...
echo (Puedes minimizar esta ventana negra; el programa se abre aparte)
echo.

python main.py

if errorlevel 1 (
    echo.
    echo ============================================
    echo El programa se cerro con un error.
    echo Copia todo el mensaje de arriba tal cual y comunicalo.
    echo ============================================
    pause
)

endlocal
