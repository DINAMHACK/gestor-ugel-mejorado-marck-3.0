#!/usr/bin/env bash
# Iniciar_GestorUGEL.sh
# ----------------------
# Abre Gestor Documental UGEL en Linux Mint / Ubuntu y derivados.
# Se puede usar con doble clic (acceso directo del Escritorio): los avisos,
# el progreso y los pedidos de contraseña salen en ventanas gráficas, sin
# necesidad de escribir comandos.
#
# La primera vez prepara el entorno e instala lo necesario (necesita internet).
# Si se agregan funciones nuevas con librerías nuevas, las instala solo.

cd "$(dirname "$(readlink -f "$0")")" || exit 1

TITULO="Gestor Documental UGEL"
LOG="temp/arranque.log"
mkdir -p temp

# ---------- Avisos gráficos (con respaldo en texto) ----------
tiene_ventanas() { [ -n "$DISPLAY$WAYLAND_DISPLAY" ] && command -v zenity >/dev/null 2>&1; }

aviso_error() {  # $1 = mensaje
    echo "ERROR: $1"
    if tiene_ventanas; then zenity --error --no-markup --title="$TITULO" --width=460 --text="$1" 2>/dev/null; fi
}
aviso_info() {
    echo "$1"
    if tiene_ventanas; then zenity --info --no-markup --title="$TITULO" --width=460 --text="$1" 2>/dev/null; fi
}
preguntar() {  # devuelve 0 si la persona acepta
    if tiene_ventanas; then zenity --question --no-markup --title="$TITULO" --width=460 --text="$1" 2>/dev/null; return $?; fi
    read -r -p "$1 [s/N]: " r; [ "$r" = "s" ] || [ "$r" = "S" ]
}

# pkexec muestra la ventana gráfica de contraseña de Linux
instalar_paquetes_sistema() {  # $@ = paquetes apt
    if ! command -v pkexec >/dev/null 2>&1; then return 1; fi
    pkexec /bin/sh -c "export DEBIAN_FRONTEND=noninteractive; apt-get update -qq || true; apt-get install -y $*"
}

# ---------- Python 3.10+ ----------
if ! command -v python3 >/dev/null 2>&1; then
    aviso_error "No se encontró Python 3. Abre el Gestor de software de Linux Mint e instala \"python3\"."
    exit 1
fi
if [ "$(python3 -c 'import sys; print(1 if sys.version_info >= (3, 10) else 0)')" != "1" ]; then
    aviso_error "Se requiere Python 3.10 o superior. Actualiza Linux Mint a una versión reciente (21 o más)."
    exit 1
fi

# ---------- tkinter y venv (ventanas del programa) ----------
if ! python3 -c "import tkinter" >/dev/null 2>&1 || ! python3 -c "import venv, ensurepip" >/dev/null 2>&1; then
    if preguntar "Falta un componente de Linux para mostrar las ventanas del programa (python3-tk). ¿Instalarlo ahora? Se pedirá tu contraseña."; then
        instalar_paquetes_sistema python3-tk python3-venv python3-pip || true
    fi
    if ! python3 -c "import tkinter" >/dev/null 2>&1; then
        aviso_error "No se pudo instalar el componente python3-tk. Instálalo desde el Gestor de software (busca \"python3-tk\") y vuelve a abrir el programa."
        exit 1
    fi
fi

# ---------- Entorno virtual ----------
if [ ! -f ".venv/bin/activate" ]; then
    python3 -m venv .venv >>"$LOG" 2>&1 || { aviso_error "No se pudo crear el entorno del programa. Revisa $LOG"; exit 1; }
fi
# shellcheck disable=SC1091
source ".venv/bin/activate"

# ---------- Dependencias (se reinstalan solas si cambió requirements.txt) ----------
HUELLA_ACTUAL="$(sha256sum requirements.txt | cut -d' ' -f1)"
HUELLA_GUARDADA="$(cat .venv/instalado.ok 2>/dev/null)"
if [ "$HUELLA_ACTUAL" != "$HUELLA_GUARDADA" ]; then
    aviso_info "Se van a instalar o actualizar las librerías del programa (necesita internet y puede tardar varios minutos). Al aceptar, aparecerá una barra de progreso. No cierres el programa."
    python -m pip install --upgrade pip >>"$LOG" 2>&1
    if tiene_ventanas; then
        ( pip install -r requirements.txt 2>&1 | tee -a "$LOG" | while IFS= read -r linea; do echo "# ${linea:0:70}"; done ) \
            | zenity --progress --pulsate --auto-close --no-cancel --title="$TITULO" --width=460 \
                     --text="Instalando librerías..." 2>/dev/null
        python -c "import customtkinter, openpyxl, pymupdf, pdfplumber, pdf2docx, cv2, numpy" >>"$LOG" 2>&1
        ESTADO=$?
    else
        pip install -r requirements.txt >>"$LOG" 2>&1
        ESTADO=$?
    fi
    if [ "$ESTADO" -ne 0 ]; then
        aviso_error "No se pudieron instalar las librerías. Revisa tu conexión a internet y vuelve a abrir el programa. Detalle en: $LOG"
        exit 1
    fi
    echo "$HUELLA_ACTUAL" > .venv/instalado.ok
fi

# ---------- Aviso (una sola vez) si falta el motor OCR ----------
if ! command -v tesseract >/dev/null 2>&1 && [ ! -f temp/ocr_avisado.ok ]; then
    touch temp/ocr_avisado.ok
    aviso_info "Para leer documentos ESCANEADOS y fotos (OCR) hace falta instalar un componente. Puedes hacerlo cuando quieras con el botón \"Instalar motor OCR\" dentro del programa (pestaña Herramientas PDF → Leer escaneados)."
fi

# ---------- Abrir el programa ----------
python main.py >>"$LOG" 2>&1
CODIGO=$?
if [ "$CODIGO" -ne 0 ]; then
    aviso_error "El programa se cerró con un error. Envía el archivo $LOG para revisarlo."
    exit "$CODIGO"
fi
