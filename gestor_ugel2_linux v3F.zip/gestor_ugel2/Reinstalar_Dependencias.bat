@echo off
setlocal
cd /d "%~dp0"

echo ============================================
echo   Reinstalar Gestor Documental UGEL
echo ============================================
echo.
echo Esto va a borrar el entorno actual (.venv) y volver a instalar
echo todo desde cero. Usalo solo si algo quedo mal instalado.
echo.
set /p CONFIRMAR=Escribe SI y presiona Enter para continuar: 

if /i not "%CONFIRMAR%"=="SI" (
    echo Cancelado. No se hizo ningun cambio.
    pause
    exit /b 0
)

if exist ".venv" (
    echo Borrando entorno anterior...
    rmdir /s /q ".venv"
)

where python >nul 2>&1
if errorlevel 1 (
    echo ERROR: no se encontro Python instalado, o no quedo agregado al PATH.
    pause
    exit /b 1
)

python -m venv .venv
if errorlevel 1 (
    echo.
    echo ERROR: no se pudo crear el entorno virtual.
    pause
    exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip >nul
pip install -r requirements.txt

if errorlevel 1 (
    echo.
    echo ERROR: no se pudieron instalar las dependencias.
    echo Revisa tu conexion a internet e intenta de nuevo.
    pause
    exit /b 1
)

echo ok > ".venv\instalado.ok"
echo.
echo Listo. Ya puedes usar "Iniciar_GestorUGEL.bat" normalmente.
pause
endlocal
