"""
config_manager.py
------------------
Carga y guarda la configuración de la aplicación (config/settings.json).
No incluye ningún dato de usuario/contraseña: la aplicación no tiene
pantalla de acceso, se abre directamente en la ventana principal.
"""

import json
import os

from utils.paths import carpeta_base, ruta_absoluta

SETTINGS_PATH = os.path.join(carpeta_base(), "config", "settings.json")

DEFAULTS = {
    "nombre_app": "Gestor Documental UGEL",
    "version": "1.1",
    "carpeta_trabajo": "",
    "carpeta_busqueda_excel": "",
    "carpeta_reportes": "reports",
    "carpeta_backups": "backups",
    "carpeta_temp": "temp",
    "columnas_excel_esperadas": ["DNI", "NOMBRE", "DOCUMENTO", "FECHA", "ESTADO"],
    "tipos_documento_validos": ["CONSTANCIA", "BOLETA", "CERTIFICADO", "TICKET"],
    "estados_validos": ["PENDIENTE", "PROCESADO", "OBSERVADO"],
    "tema": "system",
    "color_tema": "blue",
}


def cargar_config() -> dict:
    """Lee settings.json. Si no existe o está dañado, crea uno con valores por defecto."""
    if not os.path.exists(SETTINGS_PATH):
        guardar_config(DEFAULTS)
        return dict(DEFAULTS)

    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        # completa cualquier clave faltante sin perder lo ya guardado
        for clave, valor in DEFAULTS.items():
            data.setdefault(clave, valor)
        return data
    except (json.JSONDecodeError, OSError):
        guardar_config(DEFAULTS)
        return dict(DEFAULTS)


def guardar_config(config: dict) -> None:
    """Guarda el diccionario de configuración en settings.json."""
    os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=4, ensure_ascii=False)


def obtener_ruta(config: dict, clave: str, por_defecto: str) -> str:
    """
    Devuelve la carpeta configurada (por ejemplo, "carpeta_reportes")
    como una ruta ABSOLUTA, anclada a la carpeta del programa si en
    settings.json quedó guardada como ruta relativa ("reports").
    Así, sin importar desde dónde se abra la aplicación, las carpetas
    de trabajo siempre se crean en el mismo lugar.
    """
    valor = config.get(clave) or por_defecto
    return ruta_absoluta(valor)
