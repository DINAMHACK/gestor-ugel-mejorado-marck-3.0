# Gestor Documental UGEL — Local (v1.1)

Aplicación de escritorio para preparar, validar y organizar documentos
(Excel, PDF, archivos) **antes** de usarlos manualmente en el sistema
oficial de la UGEL.

Es **local-first** y **100% Excel**: toda la información de control vive
en tus mismos archivos .xlsx (los mismos que usa el resto de la oficina).
No usa ninguna base de datos, no usa internet, no se conecta a
servidores externos, y no tiene usuario ni contraseña — se abre directo,
porque es una herramienta de uso exclusivamente personal en un equipo
que solo usas tú.

---

## 1. Requisitos

### Windows 10 u 11
- Python 3.10 o superior instalado ([python.org](https://www.python.org/downloads/)).
  Al instalar, marca la casilla **"Add Python to PATH"**.

### Linux (Linux Mint / Ubuntu y derivados)
- Python 3.10 o superior (ya viene instalado en Linux Mint).
- El módulo de interfaz gráfica `tkinter`, que a veces no viene
  instalado por defecto. Instálalo (junto con `venv`) con:
  ```
  sudo apt update
  sudo apt install python3-venv python3-tk
  ```

## 2. Instalación

### En Windows
**Método recomendado:** haz doble clic en `Iniciar_GestorUGEL.bat`. La
primera vez se prepara solo (tarda unos minutos); las siguientes veces
abre directo. No hace falta escribir ningún comando.

Si prefieres hacerlo a mano por comandos, o el `.bat` no te funciona
por algún motivo, revisa `MANUAL_INSTALACION_WINDOWS.docx`. En resumen:

```
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

### En Linux Mint (y derivados de Ubuntu) — sin terminal
1. Clic derecho en el .zip → **Extraer aquí**.
2. Clic derecho en `Iniciar_GestorUGEL.sh`, `Crear_Acceso_Directo.sh` y `Reinstalar_Dependencias.sh` →
   **Propiedades → Permisos → Permitir ejecutar el archivo como un programa**.
3. Doble clic en `Crear_Acceso_Directo.sh` (elige **Ejecutar**): crea el icono en el Escritorio y en el menú.
4. Doble clic en el icono. La primera vez muestra una barra de progreso mientras instala las librerías.

Detalle completo, con la instalación del motor OCR: `MANUAL_INSTALACION_LINUX.pdf`.
Si cambia `requirements.txt`, el programa reinstala solo lo nuevo al abrir.
Si algo queda mal instalado: `Reinstalar_Dependencias.sh`.

**Si vienes de Windows:** el código en sí no cambia entre sistemas
(mismos `.py`, mismo `requirements.txt`); solo cambian los scripts de
arranque, porque Windows y Linux activan el entorno virtual de forma
distinta. Si copiaste tu carpeta completa desde Windows (incluyendo tu
`.venv` viejo), bórralo antes de continuar — un entorno virtual de
Windows no funciona en Linux:
```
rm -rf .venv
```
Además, si en **Configuración** habías guardado alguna carpeta (carpeta
de trabajo o carpeta de Excel de control) usando el explorador de
Windows, esas rutas (con letra de unidad, como `C:\...`) no existen en
Linux. Vuelve a seleccionarlas desde la pantalla de Configuración una
vez migrado.

La instalación puede tardar varios minutos y descargar unos 100-150 MB,
porque la conversión de PDF a Word y el OCR usan una librería de imágenes
(OpenCV). Es normal.

## 3. Estructura del proyecto

```
gestor_ugel/
├── main.py                 <- punto de entrada
├── requirements.txt
├── config/                 <- configuración (carpetas de trabajo, tema)
├── services/                <- lógica: Excel, PDF, archivos, búsqueda, respaldo
├── ui/                       <- pantallas (CustomTkinter)
├── datos/                    <- días no laborables (JSON) y catálogo SBN importado (CSV)
├── utils/                    <- validadores y funciones auxiliares
├── reports/                  <- reportes generados (XLSX, CSV, TXT)
├── backups/                  <- copias de seguridad de tus Excel de control
└── temp/                     <- registro de actividad
```

No existe carpeta `database/`: no se usa SQLite ni ninguna otra base de
datos. Todo el control queda en tus archivos Excel.

## 4. Módulos incluidos en esta versión

- **Excel**: detecta columnas (DNI, NOMBRE, DOCUMENTO, FECHA, ESTADO)
  sin importar el orden; valida cada fila; detecta DNI duplicados.
- **PDF**: unir, dividir, rotar, extraer páginas, comprimir, y convertir
  a Word (.docx editable). **Nuevo (v1.1) — OCR local** para PDFs escaneados
  y fotos PNG/JPG tipo CamScanner (Tesseract en español; endereza la hoja,
  quita sombras, corrige giros): pestaña *Leer escaneados (OCR)* (texto,
  PDF buscable, Word), *Extraer Datos a Excel* (con hoja *Índice por DNI*
  y columna *Revisar* para lecturas dudosas) y *PDF a Word* con OCR. El motor
  se instala desde el propio programa con un botón (ventana gráfica de
  contraseña, sin terminal).
- **Archivos**: listar, detectar duplicados por contenido, detectar
  nombres problemáticos, renombrar por correspondencia manual, organizar
  por tipo, buscar, y **renombrar en lote desde un Excel** (con vista
  previa editable antes de aplicar — nunca renombra a ciegas).
- **Buscar**: busca un DNI o nombre directamente dentro de todos los
  Excel de una carpeta (sin base de datos), con filtro opcional por
  rango de años, y una **alerta en caliente**: desde el 4to carácter
  que escribas, busca solo y avisa si ese DNI ya tiene registros,
  antes de que termines de digitarlo en Excel o SISGEDO.
- **Herramientas Excel (nuevo)**: "Proteger DNI/RUC" (corrige el cero
  inicial que Excel borra, protegiendo la columna como texto),
  "Separar Apellidos y Nombres" (separa "APELLIDOS, NOMBRES" en 3
  columnas, reconociendo apellidos compuestos como "DE LA CRUZ") y
  "Fusionar con plantilla" (coloca datos dentro de una plantilla
  oficial con logo/formato, sin tocar celdas combinadas ni fórmulas).
  Todas SIEMPRE generan un archivo nuevo — nunca modifican el original.
- **Validar documentos**: junta el Excel y la carpeta de archivos en un
  solo resumen (correctos / observados) con el detalle de cada problema.
- **Control de Plazos (Semáforo)**: por defecto cuenta **días hábiles**
  (LPAG: sin sábados, domingos, feriados nacionales ni días no laborables
  activos; el día de ingreso no cuenta) desde la fecha de ingreso hasta
  hoy — 🟢 0-7, 🟡 8-15, 🔴 más de 15. Opción de días calendario, plazo
  legal con fecha de vencimiento (30 días hábiles precargado) y pantalla
  *Feriados y días no laborables* para editar la lista. El 27 de
  diciembre (Lambayeque) viene desmarcado hasta confirmar la norma local.
  Un expediente ATENDIDO detiene el conteo.
- **Copiar fila limpia (SISGEDO)**: dentro de "Excel", copia una fila
  al portapapeles sin espacios dobles, tabulaciones invisibles ni el
  ".0" que Excel le pega a un DNI numérico — lista para pegar en un
  sistema web oficial. No quita tildes ni la "ñ" (esos sí deben
  quedar correctos en un formulario web).
- **Código Patrimonial + Catálogo SBN (v1.1)**: además de dejar los 12
  dígitos, valida que los 8 primeros existan en el Catálogo Nacional de
  Bienes Muebles que se importa con *Importar catálogo SBN...* (Excel, CSV
  o PDF con texto). El programa NO trae el catálogo incluido; sin él solo
  valida el largo y lo avisa.
- **Reportes**: genera y lista reportes en XLSX, CSV y TXT; permite
  respaldar tus Excel de control con un clic.
- **Configuración**: carpetas de trabajo y apariencia (sin usuario ni
  contraseña).

Los tipos de documento y estados válidos se configuran en
`config/settings.json` (`tipos_documento_validos`, `estados_validos`),
para adaptarlos al Excel real de la UGEL cuando lo conozcas.

## 5. Sobre el renombrado desde Excel

El módulo "Renombrar desde Excel" empareja, **en orden**, las filas del
Excel con los PDFs de la carpeta (fila 1 → primer PDF, fila 2 → segundo
PDF...). Esto solo tiene sentido si escaneaste en ese mismo orden. Por
eso, antes de aplicar cualquier cambio, el programa te muestra una vista
previa donde puedes desmarcar o corregir cualquier fila. El programa
nunca renombra nada sin que tú confirmes la lista final.

## 6. Datos de prueba

Antes de usar el programa con información real, pruébalo con datos
100% ficticios, para confirmar que detecta lo que esperas antes de
confiar en él con expedientes reales.

## 7. Empaquetar como ejecutable (opcional, más adelante)

En Windows genera un `.exe`; en Linux, PyInstaller genera un binario
Linux (sin extensión) — cada sistema debe empaquetar el suyo, no es
un archivo que se pueda copiar de uno a otro.

```
pip install pyinstaller
pyinstaller --noconfirm --windowed --name GestorUGEL main.py
```

En Windows esto generará `dist/GestorUGEL/GestorUGEL.exe`; en Linux,
`dist/GestorUGEL/GestorUGEL`. Pruébalo primero en un entorno limpio
antes de usarlo para trabajo real.
